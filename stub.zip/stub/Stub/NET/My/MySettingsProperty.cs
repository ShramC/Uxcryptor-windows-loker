﻿using System;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace NET.My
{
	// Token: 0x0200005D RID: 93
	[DebuggerNonUserCode]
	[CompilerGenerated]
	[StandardModule]
	[HideModuleName]
	internal sealed class MySettingsProperty
	{
		// Token: 0x1700002B RID: 43
		// (get) Token: 0x06000410 RID: 1040 RVA: 0x00002DBE File Offset: 0x00000FBE
		[HelpKeyword("My.Settings")]
		internal static MySettings Settings
		{
			get
			{
				return MySettings.Default;
			}
		}
	}
}
