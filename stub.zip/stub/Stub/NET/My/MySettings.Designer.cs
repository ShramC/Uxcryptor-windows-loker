﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Configuration;
using System.Runtime.CompilerServices;
using System.Threading;
using Microsoft.VisualBasic.ApplicationServices;
using Microsoft.VisualBasic.CompilerServices;
using ns0;

namespace NET.My
{
	// Token: 0x0200005B RID: 91
	[EditorBrowsable(EditorBrowsableState.Advanced)]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "17.2.0.0")]
	[CompilerGenerated]
	internal sealed partial class MySettings : ApplicationSettingsBase
	{
		// Token: 0x1700002A RID: 42
		// (get) Token: 0x0600040C RID: 1036 RVA: 0x0001AFE0 File Offset: 0x000191E0
		public static MySettings Default
		{
			get
			{
				bool flag = !MySettings.addedHandler;
				if (flag)
				{
					object obj = MySettings.addedHandlerLockObject;
					ObjectFlowControl.CheckForSyncLockOnValueType(obj);
					bool flag2 = false;
					try
					{
						Monitor.Enter(obj, ref flag2);
						bool flag3 = !MySettings.addedHandler;
						if (flag3)
						{
							WindowsFormsApplicationBase form0_ = Class1.Form0_0;
							ShutdownEventHandler obj2;
							if ((obj2 = MySettings.<>O.<0>__AutoSaveSettings) == null)
							{
								obj2 = (MySettings.<>O.<0>__AutoSaveSettings = new ShutdownEventHandler(MySettings.AutoSaveSettings));
							}
							form0_.Shutdown += obj2;
							MySettings.addedHandler = true;
						}
					}
					finally
					{
						bool flag4 = flag2;
						if (flag4)
						{
							Monitor.Exit(obj);
						}
					}
				}
				return MySettings.defaultInstance;
			}
		}

		// Token: 0x0600040E RID: 1038 RVA: 0x0001B080 File Offset: 0x00019280
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		private static void AutoSaveSettings(object sender, EventArgs e)
		{
			bool saveMySettingsOnExit = Class1.Form0_0.SaveMySettingsOnExit;
			if (saveMySettingsOnExit)
			{
				MySettingsProperty.Settings.Save();
			}
		}

		// Token: 0x040000E9 RID: 233
		private static MySettings defaultInstance = (MySettings)SettingsBase.Synchronized(new MySettings());

		// Token: 0x040000EA RID: 234
		private static bool addedHandler;

		// Token: 0x040000EB RID: 235
		private static object addedHandlerLockObject = RuntimeHelpers.GetObjectValue(new object());
	}
}
