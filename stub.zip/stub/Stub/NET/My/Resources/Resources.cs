﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;

namespace NET.My.Resources
{
	// Token: 0x0200005E RID: 94
	[CompilerGenerated]
	[HideModuleName]
	[DebuggerNonUserCode]
	[StandardModule]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "17.0.0.0")]
	internal sealed class Resources
	{
		// Token: 0x1700002C RID: 44
		// (get) Token: 0x06000412 RID: 1042 RVA: 0x0001B0AC File Offset: 0x000192AC
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				bool flag = Resources.resourceManager_0 == null;
				if (flag)
				{
					ResourceManager resourceManager = new ResourceManager("NET.Resources", typeof(Resources).Assembly);
					Resources.resourceManager_0 = resourceManager;
				}
				return Resources.resourceManager_0;
			}
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x06000413 RID: 1043 RVA: 0x0001B0F4 File Offset: 0x000192F4
		// (set) Token: 0x06000414 RID: 1044 RVA: 0x00002DC5 File Offset: 0x00000FC5
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.cultureInfo_0;
			}
			set
			{
				Resources.cultureInfo_0 = value;
			}
		}

		// Token: 0x040000ED RID: 237
		private static ResourceManager resourceManager_0;

		// Token: 0x040000EE RID: 238
		private static CultureInfo cultureInfo_0;
	}
}
