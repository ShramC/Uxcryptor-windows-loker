﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;

namespace ns0
{
	// Token: 0x02000016 RID: 22
	internal class Class11
	{
		// Token: 0x0600002E RID: 46 RVA: 0x00003210 File Offset: 0x00001410
		internal static object[] smethod_0()
		{
			return new object[1];
		}

		// Token: 0x0600002F RID: 47 RVA: 0x00003228 File Offset: 0x00001428
		internal static object[] smethod_1<T>(int int_2, object object_1, object object_2, ref T gparam_0)
		{
			object obj = Class11.object_0;
			lock (obj)
			{
				bool flag2 = !Class11.bool_0;
				if (flag2)
				{
					Class11.bool_0 = true;
					Class11.smethod_4();
				}
			}
			Class11.Class17 @class = null;
			bool flag3 = Class11.class17_0[int_2] != null;
			if (flag3)
			{
				@class = Class11.class17_0[int_2];
			}
			else
			{
				Class11.binaryReader_0.BaseStream.Position = (long)Class11.int_0[int_2];
				@class = new Class11.Class17();
				Module module = typeof(Class11).Module;
				int metadataToken = Class11.smethod_6(Class11.binaryReader_0);
				int num = Class11.smethod_6(Class11.binaryReader_0);
				int num2 = Class11.smethod_6(Class11.binaryReader_0);
				int num3 = Class11.smethod_6(Class11.binaryReader_0);
				@class.object_0 = module.ResolveMethod(metadataToken);
				ParameterInfo[] parameters = ((MethodBase)@class.object_0).GetParameters();
				@class.class13_0 = new Class11.Class13[parameters.Length];
				for (int i = 0; i < parameters.Length; i++)
				{
					Type type = parameters[i].ParameterType;
					Class11.Class13 class2 = new Class11.Class13();
					class2.bool_0 = type.IsByRef;
					class2.int_0 = i;
					@class.class13_0[i] = class2;
					bool isByRef = type.IsByRef;
					if (isByRef)
					{
						type = type.GetElementType();
					}
					Class11.Enum1 enum1_ = (!(type == typeof(string))) ? ((!(type == typeof(byte))) ? ((type == typeof(sbyte)) ? ((Class11.Enum1)1) : ((!(type == typeof(short))) ? ((!(type == typeof(ushort))) ? ((!(type == typeof(int))) ? ((!(type == typeof(uint))) ? ((!(type == typeof(long))) ? ((!(type == typeof(ulong))) ? ((!(type == typeof(float))) ? ((!(type == typeof(double))) ? ((!(type == typeof(bool))) ? ((!(type == typeof(IntPtr))) ? ((!(type == typeof(UIntPtr))) ? ((type == typeof(char)) ? ((Class11.Enum1)15) : ((Class11.Enum1)0)) : ((Class11.Enum1)13)) : ((Class11.Enum1)12)) : ((Class11.Enum1)11)) : ((Class11.Enum1)10)) : ((Class11.Enum1)9)) : ((Class11.Enum1)8)) : ((Class11.Enum1)7)) : ((Class11.Enum1)6)) : ((Class11.Enum1)5)) : ((Class11.Enum1)4)) : ((Class11.Enum1)3))) : ((Class11.Enum1)2)) : ((Class11.Enum1)14);
					class2.enum1_0 = enum1_;
				}
				@class.list_1 = new List<Class11.Class14>(num);
				for (int j = 0; j < num; j++)
				{
					int num4 = Class11.smethod_6(Class11.binaryReader_0);
					Class11.Class14 class3 = new Class11.Class14();
					class3.type_0 = null;
					bool flag4 = num4 >= 0 && num4 < 50;
					if (flag4)
					{
						class3.enum1_0 = (Class11.Enum1)(num4 & 31);
						class3.bool_0 = ((num4 & 32) > 0);
					}
					class3.int_0 = j;
					@class.list_1.Add(class3);
				}
				@class.list_2 = new List<Class11.Class15>(num2);
				for (int k = 0; k < num2; k++)
				{
					int num5 = Class11.smethod_6(Class11.binaryReader_0);
					int num6 = Class11.smethod_6(Class11.binaryReader_0);
					Class11.Class15 class4 = new Class11.Class15();
					class4.int_0 = num5;
					class4.int_1 = num6;
					Class11.Class16 class5 = class4.class16_0 = new Class11.Class16();
					num5 = Class11.smethod_6(Class11.binaryReader_0);
					num6 = Class11.smethod_6(Class11.binaryReader_0);
					int num7 = Class11.smethod_6(Class11.binaryReader_0);
					class5.int_0 = num5;
					class5.int_1 = num6;
					class5.int_3 = num7;
					int num8 = num7;
					int num9 = num8;
					if (num9 != 0)
					{
						if (num9 != 1)
						{
							Class11.smethod_6(Class11.binaryReader_0);
						}
						else
						{
							class5.int_2 = Class11.smethod_6(Class11.binaryReader_0);
						}
					}
					else
					{
						class5.type_0 = module.ResolveType(Class11.smethod_6(Class11.binaryReader_0));
					}
					@class.list_2.Add(class4);
				}
				@class.list_2.Sort((Class11.Class15 x, Class11.Class15 y) => x.class16_0.int_0.CompareTo(y.class16_0.int_0));
				@class.list_0 = new List<Class11.Class12>(num3);
				for (int l = 0; l < num3; l++)
				{
					Class11.Class12 class6 = new Class11.Class12();
					byte b = (byte)(class6.enum3_0 = (Class11.Enum3)Class11.binaryReader_0.ReadByte());
					bool flag5 = b < 176;
					if (!flag5)
					{
						throw new Exception();
					}
					int num10 = (int)Class11.byte_0[(int)b];
					bool flag6 = num10 == 0;
					if (flag6)
					{
						class6.object_0 = null;
					}
					else
					{
						object obj2;
						switch (num10)
						{
						case 1:
							obj2 = Class11.smethod_6(Class11.binaryReader_0);
							break;
						case 2:
							obj2 = Class11.binaryReader_0.ReadInt64();
							break;
						case 3:
							obj2 = Class11.binaryReader_0.ReadSingle();
							break;
						case 4:
							obj2 = Class11.binaryReader_0.ReadDouble();
							break;
						case 5:
						{
							int num11 = Class11.smethod_6(Class11.binaryReader_0);
							int[] array = new int[num11];
							for (int m = 0; m < num11; m++)
							{
								array[m] = Class11.smethod_6(Class11.binaryReader_0);
							}
							obj2 = array;
							break;
						}
						default:
							throw new Exception();
						}
						class6.object_0 = obj2;
					}
					@class.list_0.Add(class6);
				}
				Class11.class17_0[int_2] = @class;
			}
			Class11.Class20 class7 = new Class11.Class20();
			class7.class17_0 = @class;
			ParameterInfo[] parameters2 = ((MethodBase)@class.object_0).GetParameters();
			bool flag7 = false;
			int num12 = 0;
			bool flag8 = @class.object_0 is MethodInfo && ((MethodInfo)@class.object_0).ReturnType != typeof(void);
			if (flag8)
			{
				flag7 = true;
			}
			bool isStatic = ((MethodBase)@class.object_0).IsStatic;
			if (isStatic)
			{
				class7.class22_0 = new Class11.Class22[parameters2.Length];
				for (int n = 0; n < parameters2.Length; n++)
				{
					Type parameterType = parameters2[n].ParameterType;
					class7.class22_0[n] = Class11.Class22.smethod_1(parameterType, ((object[])object_1)[n]);
					bool isByRef2 = parameterType.IsByRef;
					if (isByRef2)
					{
						num12++;
					}
				}
			}
			else
			{
				class7.class22_0 = new Class11.Class22[parameters2.Length + 1];
				bool isValueType = ((MemberInfo)@class.object_0).DeclaringType.IsValueType;
				if (isValueType)
				{
					class7.class22_0[0] = new Class11.Class33(new Class11.Class34(object_2), ((MemberInfo)@class.object_0).DeclaringType);
				}
				else
				{
					class7.class22_0[0] = new Class11.Class34(object_2);
				}
				for (int num13 = 0; num13 < parameters2.Length; num13++)
				{
					Type parameterType2 = parameters2[num13].ParameterType;
					bool isByRef3 = parameterType2.IsByRef;
					if (isByRef3)
					{
						class7.class22_0[num13 + 1] = Class11.Class22.smethod_1(parameterType2, ((object[])object_1)[num13]);
						num12++;
					}
					else
					{
						class7.class22_0[num13 + 1] = Class11.Class22.smethod_1(parameterType2, ((object[])object_1)[num13]);
					}
				}
			}
			class7.class22_1 = new Class11.Class22[@class.list_1.Count];
			for (int num14 = 0; num14 < @class.list_1.Count; num14++)
			{
				Class11.Class14 class8 = @class.list_1[num14];
				switch (class8.enum1_0)
				{
				case (Class11.Enum1)0:
					class7.class22_1[num14] = null;
					break;
				case (Class11.Enum1)1:
				case (Class11.Enum1)2:
				case (Class11.Enum1)3:
				case (Class11.Enum1)4:
				case (Class11.Enum1)5:
				case (Class11.Enum1)6:
				case (Class11.Enum1)11:
				case (Class11.Enum1)15:
					class7.class22_1[num14] = new Class11.Class24(0, class8.enum1_0);
					break;
				case (Class11.Enum1)7:
				case (Class11.Enum1)8:
					class7.class22_1[num14] = new Class11.Class25(0L, class8.enum1_0);
					break;
				case (Class11.Enum1)9:
				case (Class11.Enum1)10:
					class7.class22_1[num14] = new Class11.Class27(0.0, class8.enum1_0);
					break;
				case (Class11.Enum1)12:
					class7.class22_1[num14] = new Class11.Class26(IntPtr.Zero);
					break;
				case (Class11.Enum1)13:
					class7.class22_1[num14] = new Class11.Class26(UIntPtr.Zero);
					break;
				case (Class11.Enum1)14:
					class7.class22_1[num14] = null;
					break;
				case (Class11.Enum1)16:
					class7.class22_1[num14] = new Class11.Class34(null);
					break;
				}
			}
			try
			{
				class7.method_0();
			}
			finally
			{
				class7.method_1();
			}
			int num15 = 0;
			bool flag9 = flag7;
			if (flag9)
			{
				num15 = 1;
			}
			num15 += num12;
			object[] array2 = new object[num15];
			bool flag10 = flag7;
			if (flag10)
			{
				array2[0] = null;
			}
			bool flag11 = @class.object_0 is MethodInfo;
			if (flag11)
			{
				MethodInfo methodInfo = (MethodInfo)@class.object_0;
				bool flag12 = methodInfo.ReturnType != typeof(void) && class7.class22_2 != null;
				if (flag12)
				{
					array2[0] = class7.class22_2.vmethod_4(methodInfo.ReturnType);
				}
			}
			bool flag13 = num12 > 0;
			if (flag13)
			{
				int num16 = 0;
				bool flag14 = flag7;
				if (flag14)
				{
					num16++;
				}
				for (int num17 = 0; num17 < parameters2.Length; num17++)
				{
					Type type2 = parameters2[num17].ParameterType;
					bool flag15 = !type2.IsByRef;
					if (!flag15)
					{
						type2 = type2.GetElementType();
						bool flag16 = class7.class22_0[num17] != null;
						if (flag16)
						{
							bool isStatic2 = ((MethodBase)@class.object_0).IsStatic;
							if (isStatic2)
							{
								array2[num16] = class7.class22_0[num17].vmethod_4(type2);
							}
							else
							{
								array2[num16] = class7.class22_0[num17 + 1].vmethod_4(type2);
							}
						}
						else
						{
							array2[num16] = null;
						}
						num16++;
					}
				}
			}
			bool flag17 = !((MethodBase)@class.object_0).IsStatic && ((MemberInfo)@class.object_0).DeclaringType.IsValueType;
			if (flag17)
			{
				gparam_0 = (T)((object)class7.class22_0[0].vmethod_4(((MemberInfo)@class.object_0).DeclaringType));
			}
			return array2;
		}

		// Token: 0x06000030 RID: 48 RVA: 0x00003D44 File Offset: 0x00001F44
		internal static object[] smethod_2(int int_2, object object_1, object object_2)
		{
			return Class11.smethod_1<int>(int_2, object_1, object_2, ref Class11.int_1);
		}

		// Token: 0x06000031 RID: 49 RVA: 0x00003D64 File Offset: 0x00001F64
		internal static object[] smethod_3<T>(int int_2, object object_1, ref T gparam_0)
		{
			return Class11.smethod_1<T>(int_2, object_1, gparam_0, ref gparam_0);
		}

		// Token: 0x06000032 RID: 50 RVA: 0x00003D8C File Offset: 0x00001F8C
		internal static void smethod_4()
		{
			bool flag = Class11.int_0 == null;
			if (flag)
			{
				BinaryReader binaryReader = new BinaryReader(typeof(Class11).Assembly.GetManifestResourceStream("p\u008cd\u009f\u009au\u008f\u008et\u008d\u0088jy\u0088\u0086re4.b2v\u009d5d\u0090\u0099b7\u008d\u0094\u008c\u009f8\u0091j\u009c"));
				binaryReader.BaseStream.Position = 0L;
				byte[] byte_ = binaryReader.ReadBytes((int)binaryReader.BaseStream.Length);
				binaryReader.Close();
				Class11.smethod_5(byte_);
			}
		}

		// Token: 0x06000033 RID: 51 RVA: 0x00003DF8 File Offset: 0x00001FF8
		internal static void smethod_5(byte[] byte_1)
		{
			Class11.binaryReader_0 = new BinaryReader(new MemoryStream(byte_1));
			Class11.byte_0 = new byte[255];
			int num = Class11.smethod_6(Class11.binaryReader_0);
			for (int i = 0; i < num; i++)
			{
				int num2 = (int)Class11.binaryReader_0.ReadByte();
				Class11.byte_0[num2] = Class11.binaryReader_0.ReadByte();
			}
			num = Class11.smethod_6(Class11.binaryReader_0);
			Class11.list_0 = new List<string>(num);
			for (int j = 0; j < num; j++)
			{
				Class11.list_0.Add(Encoding.Unicode.GetString(Class11.binaryReader_0.ReadBytes(Class11.smethod_6(Class11.binaryReader_0))));
			}
			num = Class11.smethod_6(Class11.binaryReader_0);
			Class11.class17_0 = new Class11.Class17[num];
			Class11.int_0 = new int[num];
			for (int k = 0; k < num; k++)
			{
				Class11.class17_0[k] = null;
				Class11.int_0[k] = Class11.smethod_6(Class11.binaryReader_0);
			}
			int num3 = (int)Class11.binaryReader_0.BaseStream.Position;
			for (int l = 0; l < num; l++)
			{
				int num4 = Class11.int_0[l];
				Class11.int_0[l] = num3;
				num3 += num4;
			}
		}

		// Token: 0x06000034 RID: 52 RVA: 0x00003F4C File Offset: 0x0000214C
		internal static int smethod_6(BinaryReader binaryReader_1)
		{
			bool flag = false;
			uint num = (uint)binaryReader_1.ReadByte();
			uint num2 = 0U | (num & 63U);
			bool flag2 = (num & 64U) > 0U;
			if (flag2)
			{
				flag = true;
			}
			bool flag3 = num < 128U;
			int result;
			if (flag3)
			{
				bool flag4 = !flag;
				if (flag4)
				{
					result = (int)num2;
				}
				else
				{
					result = (int)(~(int)num2);
				}
			}
			else
			{
				int num3 = 0;
				for (;;)
				{
					uint num4 = (uint)binaryReader_1.ReadByte();
					num2 |= (num4 & 127U) << 7 * num3 + 6;
					bool flag5 = num4 < 128U;
					if (flag5)
					{
						break;
					}
					num3++;
				}
				bool flag6 = !flag;
				if (flag6)
				{
					result = (int)num2;
				}
				else
				{
					result = (int)(~(int)num2);
				}
			}
			return result;
		}

		// Token: 0x04000011 RID: 17
		internal static Class11.Class17[] class17_0 = null;

		// Token: 0x04000012 RID: 18
		internal static int[] int_0 = null;

		// Token: 0x04000013 RID: 19
		internal static List<string> list_0;

		// Token: 0x04000014 RID: 20
		private static BinaryReader binaryReader_0;

		// Token: 0x04000015 RID: 21
		private static byte[] byte_0;

		// Token: 0x04000016 RID: 22
		private static bool bool_0 = false;

		// Token: 0x04000017 RID: 23
		private static object object_0 = 1;

		// Token: 0x04000018 RID: 24
		private static int int_1;

		// Token: 0x02000017 RID: 23
		[StructLayout(LayoutKind.Explicit)]
		public struct Struct1
		{
			// Token: 0x04000019 RID: 25
			[FieldOffset(0)]
			public byte byte_0;

			// Token: 0x0400001A RID: 26
			[FieldOffset(0)]
			public sbyte sbyte_0;

			// Token: 0x0400001B RID: 27
			[FieldOffset(0)]
			public ushort ushort_0;

			// Token: 0x0400001C RID: 28
			[FieldOffset(0)]
			public short short_0;

			// Token: 0x0400001D RID: 29
			[FieldOffset(0)]
			public uint uint_0;

			// Token: 0x0400001E RID: 30
			[FieldOffset(0)]
			public int int_0;
		}

		// Token: 0x02000018 RID: 24
		private class Class24 : Class11.Class23
		{
			// Token: 0x06000037 RID: 55 RVA: 0x00002300 File Offset: 0x00000500
			internal override void vmethod_10(Class11.Class22 class22_0)
			{
				this.struct1_0 = ((Class11.Class24)class22_0).struct1_0;
				this.enum1_0 = ((Class11.Class24)class22_0).enum1_0;
			}

			// Token: 0x06000038 RID: 56 RVA: 0x00002325 File Offset: 0x00000525
			internal override void vmethod_2(Class11.Class22 class22_0)
			{
				this.vmethod_10(class22_0);
			}

			// Token: 0x06000039 RID: 57 RVA: 0x00003FF4 File Offset: 0x000021F4
			public Class24(bool bool_0)
			{
				this.enum4_0 = (Class11.Enum4)1;
				bool flag = !bool_0;
				if (flag)
				{
					this.struct1_0.int_0 = 0;
				}
				else
				{
					this.struct1_0.int_0 = 1;
				}
				this.enum1_0 = (Class11.Enum1)11;
			}

			// Token: 0x0600003A RID: 58 RVA: 0x00002330 File Offset: 0x00000530
			public Class24(Class11.Class24 class24_0)
			{
				this.enum4_0 = class24_0.enum4_0;
				this.struct1_0.int_0 = class24_0.struct1_0.int_0;
				this.enum1_0 = class24_0.enum1_0;
			}

			// Token: 0x0600003B RID: 59 RVA: 0x00004040 File Offset: 0x00002240
			public override Class11.Class23 vmethod_74()
			{
				return new Class11.Class24(this);
			}

			// Token: 0x0600003C RID: 60 RVA: 0x00002368 File Offset: 0x00000568
			public Class24(int int_0)
			{
				this.enum4_0 = (Class11.Enum4)1;
				this.struct1_0.int_0 = int_0;
				this.enum1_0 = (Class11.Enum1)5;
			}

			// Token: 0x0600003D RID: 61 RVA: 0x0000238C File Offset: 0x0000058C
			public Class24(uint uint_0)
			{
				this.enum4_0 = (Class11.Enum4)1;
				this.struct1_0.uint_0 = uint_0;
				this.enum1_0 = (Class11.Enum1)6;
			}

			// Token: 0x0600003E RID: 62 RVA: 0x000023B0 File Offset: 0x000005B0
			public Class24(int int_0, Class11.Enum1 enum1_1)
			{
				this.enum4_0 = (Class11.Enum4)1;
				this.struct1_0.int_0 = int_0;
				this.enum1_0 = enum1_1;
			}

			// Token: 0x0600003F RID: 63 RVA: 0x000023D4 File Offset: 0x000005D4
			public Class24(uint uint_0, Class11.Enum1 enum1_1)
			{
				this.enum4_0 = (Class11.Enum4)1;
				this.struct1_0.uint_0 = uint_0;
				this.enum1_0 = enum1_1;
			}

			// Token: 0x06000040 RID: 64 RVA: 0x00004058 File Offset: 0x00002258
			public override bool vmethod_11()
			{
				Class11.Enum1 @enum = this.enum1_0;
				Class11.Enum1 enum2 = @enum;
				switch (enum2)
				{
				case (Class11.Enum1)1:
				case (Class11.Enum1)3:
				case (Class11.Enum1)5:
				case (Class11.Enum1)7:
					goto IL_4F;
				case (Class11.Enum1)2:
				case (Class11.Enum1)4:
				case (Class11.Enum1)6:
					break;
				default:
					if (enum2 == (Class11.Enum1)11 || enum2 == (Class11.Enum1)15)
					{
						goto IL_4F;
					}
					break;
				}
				return this.struct1_0.uint_0 == 0U;
				IL_4F:
				return this.struct1_0.int_0 == 0;
			}

			// Token: 0x06000041 RID: 65 RVA: 0x000040C8 File Offset: 0x000022C8
			public override bool vmethod_12()
			{
				return !this.vmethod_11();
			}

			// Token: 0x06000042 RID: 66 RVA: 0x000040E4 File Offset: 0x000022E4
			public override Class11.Class22 vmethod_13(Class11.Enum1 enum1_1)
			{
				if (!true)
				{
				}
				Class11.Class23 result;
				switch (enum1_1)
				{
				case (Class11.Enum1)1:
					result = this.vmethod_15();
					goto IL_B9;
				case (Class11.Enum1)2:
					result = this.vmethod_16();
					goto IL_B9;
				case (Class11.Enum1)3:
					result = this.vmethod_17();
					goto IL_B9;
				case (Class11.Enum1)4:
					result = this.vmethod_18();
					goto IL_B9;
				case (Class11.Enum1)5:
					result = this.vmethod_19();
					goto IL_B9;
				case (Class11.Enum1)6:
					result = this.vmethod_20();
					goto IL_B9;
				case (Class11.Enum1)11:
					result = this.vmethod_14();
					goto IL_B9;
				case (Class11.Enum1)15:
					result = this.method_7();
					goto IL_B9;
				case (Class11.Enum1)16:
					result = this.vmethod_74();
					goto IL_B9;
				}
				throw new Exception(((Class11.Enum5)4).ToString());
				IL_B9:
				if (!true)
				{
				}
				return result;
			}

			// Token: 0x06000043 RID: 67 RVA: 0x000041BC File Offset: 0x000023BC
			internal override object vmethod_4(Type type_0)
			{
				bool flag = type_0 != null && type_0.IsByRef;
				if (flag)
				{
					type_0 = type_0.GetElementType();
				}
				bool flag2 = !(type_0 == null) && !(type_0 == typeof(object));
				object result;
				if (flag2)
				{
					bool flag3 = type_0 == typeof(int);
					if (flag3)
					{
						result = this.struct1_0.int_0;
					}
					else
					{
						bool flag4 = !(type_0 == typeof(uint));
						if (flag4)
						{
							bool flag5 = !(type_0 == typeof(short));
							if (flag5)
							{
								bool flag6 = !(type_0 == typeof(ushort));
								if (flag6)
								{
									bool flag7 = type_0 == typeof(byte);
									if (flag7)
									{
										result = this.struct1_0.byte_0;
									}
									else
									{
										bool flag8 = !(type_0 == typeof(sbyte));
										if (flag8)
										{
											bool flag9 = !(type_0 == typeof(bool));
											if (flag9)
											{
												bool flag10 = !(type_0 == typeof(long));
												if (flag10)
												{
													bool flag11 = !(type_0 == typeof(ulong));
													if (flag11)
													{
														bool flag12 = type_0 == typeof(char);
														if (flag12)
														{
															result = (char)this.struct1_0.int_0;
														}
														else
														{
															bool flag13 = type_0 == typeof(IntPtr);
															if (flag13)
															{
																result = new IntPtr(this.struct1_0.int_0);
															}
															else
															{
																bool flag14 = !(type_0 == typeof(UIntPtr));
																if (flag14)
																{
																	bool flag15 = !type_0.IsEnum;
																	if (flag15)
																	{
																		throw new Class11.Exception1();
																	}
																	result = this.method_6(type_0);
																}
																else
																{
																	result = new UIntPtr(this.struct1_0.uint_0);
																}
															}
														}
													}
													else
													{
														result = (ulong)this.struct1_0.uint_0;
													}
												}
												else
												{
													result = (long)this.struct1_0.int_0;
												}
											}
											else
											{
												result = !this.vmethod_11();
											}
										}
										else
										{
											result = this.struct1_0.sbyte_0;
										}
									}
								}
								else
								{
									result = this.struct1_0.ushort_0;
								}
							}
							else
							{
								result = this.struct1_0.short_0;
							}
						}
						else
						{
							result = this.struct1_0.uint_0;
						}
					}
				}
				else
				{
					Class11.Enum1 @enum = this.enum1_0;
					if (!true)
					{
					}
					object obj;
					switch (@enum)
					{
					case (Class11.Enum1)1:
						obj = this.struct1_0.sbyte_0;
						goto IL_40B;
					case (Class11.Enum1)2:
						obj = this.struct1_0.byte_0;
						goto IL_40B;
					case (Class11.Enum1)3:
						obj = this.struct1_0.short_0;
						goto IL_40B;
					case (Class11.Enum1)4:
						obj = this.struct1_0.ushort_0;
						goto IL_40B;
					case (Class11.Enum1)5:
						obj = this.struct1_0.int_0;
						goto IL_40B;
					case (Class11.Enum1)6:
						obj = this.struct1_0.uint_0;
						goto IL_40B;
					case (Class11.Enum1)7:
						obj = (long)this.struct1_0.int_0;
						goto IL_40B;
					case (Class11.Enum1)8:
						obj = (ulong)this.struct1_0.uint_0;
						goto IL_40B;
					case (Class11.Enum1)11:
						obj = this.vmethod_12();
						goto IL_40B;
					case (Class11.Enum1)15:
						obj = (char)this.struct1_0.int_0;
						goto IL_40B;
					}
					obj = this.struct1_0.int_0;
					IL_40B:
					if (!true)
					{
					}
					object obj2 = obj;
					result = obj2;
				}
				return result;
			}

			// Token: 0x06000044 RID: 68 RVA: 0x000045E8 File Offset: 0x000027E8
			internal object method_6(Type type_0)
			{
				Type underlyingType = Enum.GetUnderlyingType(type_0);
				bool flag = underlyingType == typeof(int);
				object result;
				if (flag)
				{
					result = Enum.ToObject(type_0, this.struct1_0.int_0);
				}
				else
				{
					bool flag2 = underlyingType == typeof(uint);
					if (flag2)
					{
						result = Enum.ToObject(type_0, this.struct1_0.uint_0);
					}
					else
					{
						bool flag3 = !(underlyingType == typeof(short));
						if (flag3)
						{
							bool flag4 = underlyingType == typeof(ushort);
							if (flag4)
							{
								result = Enum.ToObject(type_0, this.struct1_0.ushort_0);
							}
							else
							{
								bool flag5 = underlyingType == typeof(byte);
								if (flag5)
								{
									result = Enum.ToObject(type_0, this.struct1_0.byte_0);
								}
								else
								{
									bool flag6 = underlyingType == typeof(sbyte);
									if (flag6)
									{
										result = Enum.ToObject(type_0, this.struct1_0.sbyte_0);
									}
									else
									{
										bool flag7 = underlyingType == typeof(long);
										if (flag7)
										{
											result = Enum.ToObject(type_0, (long)this.struct1_0.int_0);
										}
										else
										{
											bool flag8 = underlyingType == typeof(ulong);
											if (flag8)
											{
												result = Enum.ToObject(type_0, (ulong)this.struct1_0.uint_0);
											}
											else
											{
												bool flag9 = underlyingType == typeof(char);
												if (flag9)
												{
													result = Enum.ToObject(type_0, (ushort)this.struct1_0.int_0);
												}
												else
												{
													result = Enum.ToObject(type_0, this.struct1_0.int_0);
												}
											}
										}
									}
								}
							}
						}
						else
						{
							result = Enum.ToObject(type_0, this.struct1_0.short_0);
						}
					}
				}
				return result;
			}

			// Token: 0x06000045 RID: 69 RVA: 0x000047AC File Offset: 0x000029AC
			public override Class11.Class24 vmethod_14()
			{
				return new Class11.Class24((!this.vmethod_11()) ? 1 : 0);
			}

			// Token: 0x06000046 RID: 70 RVA: 0x000047D0 File Offset: 0x000029D0
			internal override bool vmethod_7()
			{
				return this.vmethod_12();
			}

			// Token: 0x06000047 RID: 71 RVA: 0x000047E8 File Offset: 0x000029E8
			public override Class11.Class24 vmethod_15()
			{
				return new Class11.Class24((int)this.struct1_0.sbyte_0, (Class11.Enum1)1);
			}

			// Token: 0x06000048 RID: 72 RVA: 0x0000480C File Offset: 0x00002A0C
			public Class11.Class24 method_7()
			{
				return new Class11.Class24(this.struct1_0.int_0, (Class11.Enum1)15);
			}

			// Token: 0x06000049 RID: 73 RVA: 0x00004830 File Offset: 0x00002A30
			public override Class11.Class24 vmethod_16()
			{
				return new Class11.Class24((uint)this.struct1_0.byte_0, (Class11.Enum1)2);
			}

			// Token: 0x0600004A RID: 74 RVA: 0x00004854 File Offset: 0x00002A54
			public override Class11.Class24 vmethod_17()
			{
				return new Class11.Class24((int)this.struct1_0.short_0, (Class11.Enum1)3);
			}

			// Token: 0x0600004B RID: 75 RVA: 0x00004878 File Offset: 0x00002A78
			public override Class11.Class24 vmethod_18()
			{
				return new Class11.Class24((uint)this.struct1_0.ushort_0, (Class11.Enum1)4);
			}

			// Token: 0x0600004C RID: 76 RVA: 0x0000489C File Offset: 0x00002A9C
			public override Class11.Class24 vmethod_19()
			{
				return new Class11.Class24(this.struct1_0.int_0, (Class11.Enum1)5);
			}

			// Token: 0x0600004D RID: 77 RVA: 0x000048C0 File Offset: 0x00002AC0
			public override Class11.Class24 vmethod_20()
			{
				return new Class11.Class24(this.struct1_0.uint_0, (Class11.Enum1)6);
			}

			// Token: 0x0600004E RID: 78 RVA: 0x000048E4 File Offset: 0x00002AE4
			public override Class11.Class25 vmethod_21()
			{
				return new Class11.Class25((long)this.struct1_0.int_0, (Class11.Enum1)7);
			}

			// Token: 0x0600004F RID: 79 RVA: 0x00004908 File Offset: 0x00002B08
			public override Class11.Class25 vmethod_22()
			{
				return new Class11.Class25((ulong)this.struct1_0.uint_0, (Class11.Enum1)8);
			}

			// Token: 0x06000050 RID: 80 RVA: 0x0000492C File Offset: 0x00002B2C
			public override Class11.Class24 vmethod_23()
			{
				return this.vmethod_15();
			}

			// Token: 0x06000051 RID: 81 RVA: 0x00004944 File Offset: 0x00002B44
			public override Class11.Class24 vmethod_24()
			{
				return this.vmethod_17();
			}

			// Token: 0x06000052 RID: 82 RVA: 0x0000495C File Offset: 0x00002B5C
			public override Class11.Class24 vmethod_25()
			{
				return this.vmethod_19();
			}

			// Token: 0x06000053 RID: 83 RVA: 0x00004974 File Offset: 0x00002B74
			public override Class11.Class25 vmethod_26()
			{
				return this.vmethod_21();
			}

			// Token: 0x06000054 RID: 84 RVA: 0x0000498C File Offset: 0x00002B8C
			public override Class11.Class24 vmethod_27()
			{
				return this.vmethod_16();
			}

			// Token: 0x06000055 RID: 85 RVA: 0x000049A4 File Offset: 0x00002BA4
			public override Class11.Class24 vmethod_28()
			{
				return this.vmethod_18();
			}

			// Token: 0x06000056 RID: 86 RVA: 0x000049BC File Offset: 0x00002BBC
			public override Class11.Class24 vmethod_29()
			{
				return this.vmethod_20();
			}

			// Token: 0x06000057 RID: 87 RVA: 0x000049D4 File Offset: 0x00002BD4
			public override Class11.Class25 vmethod_30()
			{
				return this.vmethod_22();
			}

			// Token: 0x06000058 RID: 88 RVA: 0x000049EC File Offset: 0x00002BEC
			public override Class11.Class24 vmethod_31()
			{
				return new Class11.Class24((int)(checked((sbyte)this.struct1_0.int_0)), (Class11.Enum1)1);
			}

			// Token: 0x06000059 RID: 89 RVA: 0x00004A10 File Offset: 0x00002C10
			public override Class11.Class24 vmethod_32()
			{
				return new Class11.Class24((int)(checked((sbyte)this.struct1_0.uint_0)), (Class11.Enum1)1);
			}

			// Token: 0x0600005A RID: 90 RVA: 0x00004A34 File Offset: 0x00002C34
			public override Class11.Class24 vmethod_33()
			{
				return new Class11.Class24((int)(checked((short)this.struct1_0.int_0)), (Class11.Enum1)3);
			}

			// Token: 0x0600005B RID: 91 RVA: 0x00004A58 File Offset: 0x00002C58
			public override Class11.Class24 vmethod_34()
			{
				return new Class11.Class24((int)(checked((short)this.struct1_0.uint_0)), (Class11.Enum1)3);
			}

			// Token: 0x0600005C RID: 92 RVA: 0x0000489C File Offset: 0x00002A9C
			public override Class11.Class24 vmethod_35()
			{
				return new Class11.Class24(this.struct1_0.int_0, (Class11.Enum1)5);
			}

			// Token: 0x0600005D RID: 93 RVA: 0x00004A7C File Offset: 0x00002C7C
			public override Class11.Class24 vmethod_36()
			{
				return new Class11.Class24(checked((int)this.struct1_0.uint_0), (Class11.Enum1)5);
			}

			// Token: 0x0600005E RID: 94 RVA: 0x000048E4 File Offset: 0x00002AE4
			public override Class11.Class25 vmethod_37()
			{
				return new Class11.Class25((long)this.struct1_0.int_0, (Class11.Enum1)7);
			}

			// Token: 0x0600005F RID: 95 RVA: 0x00004AA0 File Offset: 0x00002CA0
			public override Class11.Class25 vmethod_38()
			{
				return new Class11.Class25((long)((ulong)this.struct1_0.uint_0), (Class11.Enum1)7);
			}

			// Token: 0x06000060 RID: 96 RVA: 0x00004AC4 File Offset: 0x00002CC4
			public override Class11.Class24 vmethod_39()
			{
				return new Class11.Class24((int)(checked((byte)this.struct1_0.int_0)), (Class11.Enum1)2);
			}

			// Token: 0x06000061 RID: 97 RVA: 0x00004AE8 File Offset: 0x00002CE8
			public override Class11.Class24 vmethod_40()
			{
				return new Class11.Class24((int)(checked((byte)this.struct1_0.uint_0)), (Class11.Enum1)2);
			}

			// Token: 0x06000062 RID: 98 RVA: 0x00004B0C File Offset: 0x00002D0C
			public override Class11.Class24 vmethod_41()
			{
				return new Class11.Class24((int)(checked((ushort)this.struct1_0.int_0)), (Class11.Enum1)4);
			}

			// Token: 0x06000063 RID: 99 RVA: 0x00004B30 File Offset: 0x00002D30
			public override Class11.Class24 vmethod_42()
			{
				return new Class11.Class24((int)(checked((ushort)this.struct1_0.uint_0)), (Class11.Enum1)4);
			}

			// Token: 0x06000064 RID: 100 RVA: 0x00004B54 File Offset: 0x00002D54
			public override Class11.Class24 vmethod_43()
			{
				return new Class11.Class24(checked((uint)this.struct1_0.int_0), (Class11.Enum1)6);
			}

			// Token: 0x06000065 RID: 101 RVA: 0x000048C0 File Offset: 0x00002AC0
			public override Class11.Class24 vmethod_44()
			{
				return new Class11.Class24(this.struct1_0.uint_0, (Class11.Enum1)6);
			}

			// Token: 0x06000066 RID: 102 RVA: 0x00004B78 File Offset: 0x00002D78
			public override Class11.Class25 vmethod_45()
			{
				return new Class11.Class25(checked((ulong)this.struct1_0.int_0), (Class11.Enum1)8);
			}

			// Token: 0x06000067 RID: 103 RVA: 0x00004908 File Offset: 0x00002B08
			public override Class11.Class25 vmethod_46()
			{
				return new Class11.Class25((ulong)this.struct1_0.uint_0, (Class11.Enum1)8);
			}

			// Token: 0x06000068 RID: 104 RVA: 0x00004B9C File Offset: 0x00002D9C
			public override Class11.Class27 vmethod_47()
			{
				return new Class11.Class27((float)this.struct1_0.int_0);
			}

			// Token: 0x06000069 RID: 105 RVA: 0x00004BC0 File Offset: 0x00002DC0
			public override Class11.Class27 vmethod_48()
			{
				return new Class11.Class27((double)this.struct1_0.int_0);
			}

			// Token: 0x0600006A RID: 106 RVA: 0x00004BE4 File Offset: 0x00002DE4
			public override Class11.Class27 vmethod_49()
			{
				return new Class11.Class27(this.struct1_0.uint_0);
			}

			// Token: 0x0600006B RID: 107 RVA: 0x00004C08 File Offset: 0x00002E08
			public override Class11.Class26 vmethod_50()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_26().struct2_0.long_0);
				}
				else
				{
					result = new Class11.Class26((long)this.vmethod_25().struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x0600006C RID: 108 RVA: 0x00004C58 File Offset: 0x00002E58
			public override Class11.Class26 vmethod_51()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_30().struct2_0.ulong_0);
				}
				else
				{
					result = new Class11.Class26((ulong)this.vmethod_29().struct1_0.uint_0);
				}
				return result;
			}

			// Token: 0x0600006D RID: 109 RVA: 0x00004CA8 File Offset: 0x00002EA8
			public override Class11.Class26 vmethod_52()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_37().struct2_0.long_0);
				}
				else
				{
					result = new Class11.Class26((long)this.vmethod_35().struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x0600006E RID: 110 RVA: 0x00004CF8 File Offset: 0x00002EF8
			public override Class11.Class26 vmethod_53()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_45().struct2_0.ulong_0);
				}
				else
				{
					result = new Class11.Class26((ulong)this.vmethod_43().struct1_0.uint_0);
				}
				return result;
			}

			// Token: 0x0600006F RID: 111 RVA: 0x00004D48 File Offset: 0x00002F48
			public override Class11.Class26 vmethod_54()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_38().struct2_0.long_0);
				}
				else
				{
					result = new Class11.Class26((long)this.vmethod_36().struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x06000070 RID: 112 RVA: 0x00004D98 File Offset: 0x00002F98
			public override Class11.Class26 vmethod_55()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_46().struct2_0.ulong_0);
				}
				else
				{
					result = new Class11.Class26((ulong)this.vmethod_44().struct1_0.uint_0);
				}
				return result;
			}

			// Token: 0x06000071 RID: 113 RVA: 0x00004DE8 File Offset: 0x00002FE8
			public override Class11.Class22 vmethod_56()
			{
				Class11.Enum1 @enum = this.enum1_0;
				Class11.Enum1 enum2 = @enum;
				switch (enum2)
				{
				case (Class11.Enum1)1:
				case (Class11.Enum1)3:
				case (Class11.Enum1)5:
					goto IL_4E;
				case (Class11.Enum1)2:
				case (Class11.Enum1)4:
					break;
				default:
					if (enum2 == (Class11.Enum1)11 || enum2 == (Class11.Enum1)15)
					{
						goto IL_4E;
					}
					break;
				}
				return new Class11.Class24((int)(0UL - (ulong)this.struct1_0.uint_0));
				IL_4E:
				return new Class11.Class24(-this.struct1_0.int_0);
			}

			// Token: 0x06000072 RID: 114 RVA: 0x00004E58 File Offset: 0x00003058
			public override Class11.Class22 vmethod_57(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_57(this);
				}
				else
				{
					result = new Class11.Class24(this.struct1_0.int_0 + ((Class11.Class24)class22_0).struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x06000073 RID: 115 RVA: 0x00004ED0 File Offset: 0x000030D0
			public override Class11.Class22 vmethod_58(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_58(this);
				}
				else
				{
					result = new Class11.Class24(checked(this.struct1_0.int_0 + ((Class11.Class24)class22_0).struct1_0.int_0));
				}
				return result;
			}

			// Token: 0x06000074 RID: 116 RVA: 0x00004F48 File Offset: 0x00003148
			public override Class11.Class22 vmethod_59(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_59(this);
				}
				else
				{
					result = new Class11.Class24(checked(this.struct1_0.uint_0 + ((Class11.Class24)class22_0).struct1_0.uint_0));
				}
				return result;
			}

			// Token: 0x06000075 RID: 117 RVA: 0x00004FC0 File Offset: 0x000031C0
			public override Class11.Class22 vmethod_60(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					result = new Class11.Class24(this.struct1_0.int_0 - ((Class11.Class24)class22_0).struct1_0.int_0);
				}
				else
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).method_8(this);
				}
				return result;
			}

			// Token: 0x06000076 RID: 118 RVA: 0x00005038 File Offset: 0x00003238
			public override Class11.Class22 vmethod_61(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).method_9(this);
				}
				else
				{
					result = new Class11.Class24(checked(this.struct1_0.int_0 - ((Class11.Class24)class22_0).struct1_0.int_0));
				}
				return result;
			}

			// Token: 0x06000077 RID: 119 RVA: 0x000050B0 File Offset: 0x000032B0
			public override Class11.Class22 vmethod_62(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).method_10(this);
				}
				else
				{
					result = new Class11.Class24(checked(this.struct1_0.uint_0 - ((Class11.Class24)class22_0).struct1_0.uint_0));
				}
				return result;
			}

			// Token: 0x06000078 RID: 120 RVA: 0x00005128 File Offset: 0x00003328
			public override Class11.Class22 vmethod_63(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					result = new Class11.Class24(this.struct1_0.int_0 * ((Class11.Class24)class22_0).struct1_0.int_0);
				}
				else
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_63(this);
				}
				return result;
			}

			// Token: 0x06000079 RID: 121 RVA: 0x000051A0 File Offset: 0x000033A0
			public override Class11.Class22 vmethod_64(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					result = new Class11.Class24(checked(this.struct1_0.int_0 * ((Class11.Class24)class22_0).struct1_0.int_0));
				}
				else
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_64(this);
				}
				return result;
			}

			// Token: 0x0600007A RID: 122 RVA: 0x00005218 File Offset: 0x00003418
			public override Class11.Class22 vmethod_65(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_65(this);
				}
				else
				{
					result = new Class11.Class24(checked(this.struct1_0.uint_0 * ((Class11.Class24)class22_0).struct1_0.uint_0));
				}
				return result;
			}

			// Token: 0x0600007B RID: 123 RVA: 0x00005290 File Offset: 0x00003490
			public override Class11.Class22 vmethod_66(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).method_11(this);
				}
				else
				{
					result = new Class11.Class24(this.struct1_0.int_0 / ((Class11.Class24)class22_0).struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x0600007C RID: 124 RVA: 0x00005308 File Offset: 0x00003508
			public override Class11.Class22 vmethod_67(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					result = new Class11.Class24(this.struct1_0.uint_0 / ((Class11.Class24)class22_0).struct1_0.uint_0);
				}
				else
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).method_12(this);
				}
				return result;
			}

			// Token: 0x0600007D RID: 125 RVA: 0x00005380 File Offset: 0x00003580
			public override Class11.Class22 vmethod_68(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					result = new Class11.Class24(this.struct1_0.int_0 % ((Class11.Class24)class22_0).struct1_0.int_0);
				}
				else
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).method_13(this);
				}
				return result;
			}

			// Token: 0x0600007E RID: 126 RVA: 0x000053F8 File Offset: 0x000035F8
			public override Class11.Class22 vmethod_69(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).method_14(this);
				}
				else
				{
					result = new Class11.Class24(this.struct1_0.uint_0 % ((Class11.Class24)class22_0).struct1_0.uint_0);
				}
				return result;
			}

			// Token: 0x0600007F RID: 127 RVA: 0x00005470 File Offset: 0x00003670
			public override Class11.Class22 vmethod_70(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					result = new Class11.Class24(this.struct1_0.int_0 & ((Class11.Class24)class22_0).struct1_0.int_0);
				}
				else
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_70(this);
				}
				return result;
			}

			// Token: 0x06000080 RID: 128 RVA: 0x000054E8 File Offset: 0x000036E8
			public override Class11.Class22 vmethod_71(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_71(this);
				}
				else
				{
					result = new Class11.Class24(this.struct1_0.int_0 | ((Class11.Class24)class22_0).struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x06000081 RID: 129 RVA: 0x00005560 File Offset: 0x00003760
			public override Class11.Class22 vmethod_72()
			{
				return new Class11.Class24(~this.struct1_0.int_0);
			}

			// Token: 0x06000082 RID: 130 RVA: 0x00005584 File Offset: 0x00003784
			public override Class11.Class22 vmethod_73(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_73(this);
				}
				else
				{
					result = new Class11.Class24(this.struct1_0.int_0 ^ ((Class11.Class24)class22_0).struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x06000083 RID: 131 RVA: 0x000055FC File Offset: 0x000037FC
			public override Class11.Class22 vmethod_75(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).method_17(this);
				}
				else
				{
					result = new Class11.Class24(this.struct1_0.int_0 << ((Class11.Class24)class22_0).struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x06000084 RID: 132 RVA: 0x00005678 File Offset: 0x00003878
			public override Class11.Class22 vmethod_76(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					result = new Class11.Class24(this.struct1_0.int_0 >> ((Class11.Class24)class22_0).struct1_0.int_0);
				}
				else
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).method_16(this);
				}
				return result;
			}

			// Token: 0x06000085 RID: 133 RVA: 0x000056F0 File Offset: 0x000038F0
			public override Class11.Class22 vmethod_77(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					result = new Class11.Class24(this.struct1_0.uint_0 >> ((Class11.Class24)class22_0).struct1_0.int_0);
				}
				else
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).method_15(this);
				}
				return result;
			}

			// Token: 0x06000086 RID: 134 RVA: 0x00005768 File Offset: 0x00003968
			public override string ToString()
			{
				Class11.Enum1 @enum = this.enum1_0;
				Class11.Enum1 enum2 = @enum;
				switch (enum2)
				{
				case (Class11.Enum1)1:
				case (Class11.Enum1)3:
				case (Class11.Enum1)5:
					goto IL_42;
				case (Class11.Enum1)2:
				case (Class11.Enum1)4:
					break;
				default:
					if (enum2 == (Class11.Enum1)11)
					{
						goto IL_42;
					}
					break;
				}
				return this.struct1_0.uint_0.ToString();
				IL_42:
				return this.struct1_0.int_0.ToString();
			}

			// Token: 0x06000087 RID: 135 RVA: 0x000057CC File Offset: 0x000039CC
			internal override Class11.Class22 vmethod_8()
			{
				return this;
			}

			// Token: 0x06000088 RID: 136 RVA: 0x000057E0 File Offset: 0x000039E0
			internal override bool vmethod_9()
			{
				return true;
			}

			// Token: 0x06000089 RID: 137 RVA: 0x000057F4 File Offset: 0x000039F4
			internal override bool vmethod_5(Class11.Class22 class22_0)
			{
				bool flag = !class22_0.method_0();
				bool result;
				if (flag)
				{
					bool flag2 = class22_0.vmethod_0();
					if (flag2)
					{
						result = ((Class11.Class28)class22_0).vmethod_5(this);
					}
					else
					{
						Class11.Class22 @class = class22_0.vmethod_8();
						bool flag3 = @class.vmethod_9();
						if (flag3)
						{
							bool flag4 = @class.method_3();
							if (flag4)
							{
								result = false;
							}
							else
							{
								bool flag5 = !@class.method_1();
								if (flag5)
								{
									result = ((Class11.Class26)@class).vmethod_5(this);
								}
								else
								{
									result = (this.struct1_0.int_0 == ((Class11.Class24)@class).struct1_0.int_0);
								}
							}
						}
						else
						{
							result = false;
						}
					}
				}
				else
				{
					result = ((Class11.Class34)class22_0).vmethod_5(this);
				}
				return result;
			}

			// Token: 0x0600008A RID: 138 RVA: 0x000058A8 File Offset: 0x00003AA8
			private static Class11.Class23 smethod_4(Class11.Class22 class22_0)
			{
				Class11.Class23 @class = class22_0 as Class11.Class23;
				bool flag = @class == null && class22_0.vmethod_0();
				if (flag)
				{
					@class = (class22_0.vmethod_8() as Class11.Class23);
				}
				return @class;
			}

			// Token: 0x0600008B RID: 139 RVA: 0x000058E0 File Offset: 0x00003AE0
			internal override bool vmethod_6(Class11.Class22 class22_0)
			{
				bool flag = !class22_0.method_0();
				bool result;
				if (flag)
				{
					bool flag2 = class22_0.vmethod_0();
					if (flag2)
					{
						result = ((Class11.Class28)class22_0).vmethod_6(this);
					}
					else
					{
						Class11.Class22 @class = class22_0.vmethod_8();
						bool flag3 = @class.vmethod_9();
						if (flag3)
						{
							bool flag4 = !@class.method_3();
							if (flag4)
							{
								bool flag5 = @class.method_1();
								if (flag5)
								{
									result = (this.struct1_0.uint_0 != ((Class11.Class24)@class).struct1_0.uint_0);
								}
								else
								{
									result = ((Class11.Class26)@class).vmethod_6(this);
								}
							}
							else
							{
								result = false;
							}
						}
						else
						{
							result = false;
						}
					}
				}
				else
				{
					result = false;
				}
				return result;
			}

			// Token: 0x0600008C RID: 140 RVA: 0x0000598C File Offset: 0x00003B8C
			public override bool vmethod_78(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				bool result;
				if (flag2)
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_82(this);
				}
				else
				{
					result = (this.struct1_0.int_0 >= ((Class11.Class24)class22_0).struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x0600008D RID: 141 RVA: 0x00005A04 File Offset: 0x00003C04
			public override bool vmethod_79(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				bool result;
				if (flag2)
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_83(this);
				}
				else
				{
					result = (this.struct1_0.uint_0 >= ((Class11.Class24)class22_0).struct1_0.uint_0);
				}
				return result;
			}

			// Token: 0x0600008E RID: 142 RVA: 0x00005A7C File Offset: 0x00003C7C
			public override bool vmethod_80(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				bool result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_84(this);
				}
				else
				{
					result = (this.struct1_0.int_0 > ((Class11.Class24)class22_0).struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x0600008F RID: 143 RVA: 0x00005AF0 File Offset: 0x00003CF0
			public override bool vmethod_81(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				bool result;
				if (flag2)
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_85(this);
				}
				else
				{
					result = (this.struct1_0.uint_0 > ((Class11.Class24)class22_0).struct1_0.uint_0);
				}
				return result;
			}

			// Token: 0x06000090 RID: 144 RVA: 0x00005B64 File Offset: 0x00003D64
			public override bool vmethod_82(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				bool result;
				if (flag2)
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_78(this);
				}
				else
				{
					result = (this.struct1_0.int_0 <= ((Class11.Class24)class22_0).struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x06000091 RID: 145 RVA: 0x00005BDC File Offset: 0x00003DDC
			public override bool vmethod_83(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				bool result;
				if (flag2)
				{
					result = (this.struct1_0.uint_0 <= ((Class11.Class24)class22_0).struct1_0.uint_0);
				}
				else
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_79(this);
				}
				return result;
			}

			// Token: 0x06000092 RID: 146 RVA: 0x00005C50 File Offset: 0x00003E50
			public override bool vmethod_84(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				bool result;
				if (flag2)
				{
					result = (this.struct1_0.int_0 < ((Class11.Class24)class22_0).struct1_0.int_0);
				}
				else
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_80(this);
				}
				return result;
			}

			// Token: 0x06000093 RID: 147 RVA: 0x00005CC4 File Offset: 0x00003EC4
			public override bool vmethod_85(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				bool result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					result = ((Class11.Class26)class22_0).vmethod_81(this);
				}
				else
				{
					result = (this.struct1_0.uint_0 < ((Class11.Class24)class22_0).struct1_0.uint_0);
				}
				return result;
			}

			// Token: 0x0400001F RID: 31
			public Class11.Struct1 struct1_0;

			// Token: 0x04000020 RID: 32
			public Class11.Enum1 enum1_0;
		}

		// Token: 0x02000019 RID: 25
		[StructLayout(LayoutKind.Explicit)]
		private struct Struct2
		{
			// Token: 0x04000021 RID: 33
			[FieldOffset(0)]
			public byte byte_0;

			// Token: 0x04000022 RID: 34
			[FieldOffset(0)]
			public sbyte sbyte_0;

			// Token: 0x04000023 RID: 35
			[FieldOffset(0)]
			public ushort ushort_0;

			// Token: 0x04000024 RID: 36
			[FieldOffset(0)]
			public short short_0;

			// Token: 0x04000025 RID: 37
			[FieldOffset(0)]
			public uint uint_0;

			// Token: 0x04000026 RID: 38
			[FieldOffset(0)]
			public int int_0;

			// Token: 0x04000027 RID: 39
			[FieldOffset(0)]
			public ulong ulong_0;

			// Token: 0x04000028 RID: 40
			[FieldOffset(0)]
			public long long_0;
		}

		// Token: 0x0200001A RID: 26
		private class Class25 : Class11.Class23
		{
			// Token: 0x06000094 RID: 148 RVA: 0x000023F8 File Offset: 0x000005F8
			internal override void vmethod_10(Class11.Class22 class22_0)
			{
				this.struct2_0 = ((Class11.Class25)class22_0).struct2_0;
				this.enum1_0 = ((Class11.Class25)class22_0).enum1_0;
			}

			// Token: 0x06000095 RID: 149 RVA: 0x00002325 File Offset: 0x00000525
			internal override void vmethod_2(Class11.Class22 class22_0)
			{
				this.vmethod_10(class22_0);
			}

			// Token: 0x06000096 RID: 150 RVA: 0x0000241D File Offset: 0x0000061D
			public Class25(long long_0)
			{
				this.enum4_0 = (Class11.Enum4)2;
				this.struct2_0.long_0 = long_0;
				this.enum1_0 = (Class11.Enum1)7;
			}

			// Token: 0x06000097 RID: 151 RVA: 0x00002441 File Offset: 0x00000641
			public Class25(Class11.Class25 class25_0)
			{
				this.enum4_0 = class25_0.enum4_0;
				this.struct2_0.long_0 = class25_0.struct2_0.long_0;
				this.enum1_0 = class25_0.enum1_0;
			}

			// Token: 0x06000098 RID: 152 RVA: 0x00005D38 File Offset: 0x00003F38
			public override Class11.Class23 vmethod_74()
			{
				return new Class11.Class25(this);
			}

			// Token: 0x06000099 RID: 153 RVA: 0x00002479 File Offset: 0x00000679
			public Class25(long long_0, Class11.Enum1 enum1_1)
			{
				this.enum4_0 = (Class11.Enum4)2;
				this.struct2_0.long_0 = long_0;
				this.enum1_0 = enum1_1;
			}

			// Token: 0x0600009A RID: 154 RVA: 0x0000249D File Offset: 0x0000069D
			public Class25(ulong ulong_0)
			{
				this.enum4_0 = (Class11.Enum4)2;
				this.struct2_0.ulong_0 = ulong_0;
				this.enum1_0 = (Class11.Enum1)8;
			}

			// Token: 0x0600009B RID: 155 RVA: 0x000024C1 File Offset: 0x000006C1
			public Class25(ulong ulong_0, Class11.Enum1 enum1_1)
			{
				this.enum4_0 = (Class11.Enum4)2;
				this.struct2_0.ulong_0 = ulong_0;
				this.enum1_0 = enum1_1;
			}

			// Token: 0x0600009C RID: 156 RVA: 0x00005D50 File Offset: 0x00003F50
			public override bool vmethod_11()
			{
				bool flag = this.enum1_0 == (Class11.Enum1)7;
				bool result;
				if (flag)
				{
					result = (this.struct2_0.long_0 == 0L);
				}
				else
				{
					result = (this.struct2_0.ulong_0 == 0UL);
				}
				return result;
			}

			// Token: 0x0600009D RID: 157 RVA: 0x000040C8 File Offset: 0x000022C8
			public override bool vmethod_12()
			{
				return !this.vmethod_11();
			}

			// Token: 0x0600009E RID: 158 RVA: 0x00005D94 File Offset: 0x00003F94
			public override Class11.Class22 vmethod_13(Class11.Enum1 enum1_1)
			{
				if (!true)
				{
				}
				Class11.Class23 result;
				switch (enum1_1)
				{
				case (Class11.Enum1)1:
					result = this.vmethod_15();
					goto IL_CB;
				case (Class11.Enum1)2:
					result = this.vmethod_16();
					goto IL_CB;
				case (Class11.Enum1)3:
					result = this.vmethod_17();
					goto IL_CB;
				case (Class11.Enum1)4:
					result = this.vmethod_18();
					goto IL_CB;
				case (Class11.Enum1)5:
					result = this.vmethod_19();
					goto IL_CB;
				case (Class11.Enum1)6:
					result = this.vmethod_20();
					goto IL_CB;
				case (Class11.Enum1)7:
					result = this.vmethod_21();
					goto IL_CB;
				case (Class11.Enum1)8:
					result = this.vmethod_22();
					goto IL_CB;
				case (Class11.Enum1)11:
					result = this.vmethod_14();
					goto IL_CB;
				case (Class11.Enum1)15:
					result = this.method_7();
					goto IL_CB;
				case (Class11.Enum1)16:
					result = this.vmethod_74();
					goto IL_CB;
				}
				throw new Exception(((Class11.Enum5)4).ToString());
				IL_CB:
				if (!true)
				{
				}
				return result;
			}

			// Token: 0x0600009F RID: 159 RVA: 0x00005E80 File Offset: 0x00004080
			internal override object vmethod_4(Type type_0)
			{
				bool flag = type_0 != null && type_0.IsByRef;
				if (flag)
				{
					type_0 = type_0.GetElementType();
				}
				bool flag2 = !(type_0 == null) && !(type_0 == typeof(object));
				object result;
				if (flag2)
				{
					bool flag3 = type_0 == typeof(int);
					if (flag3)
					{
						result = this.struct2_0.int_0;
					}
					else
					{
						bool flag4 = !(type_0 == typeof(uint));
						if (flag4)
						{
							bool flag5 = !(type_0 == typeof(short));
							if (flag5)
							{
								bool flag6 = !(type_0 == typeof(ushort));
								if (flag6)
								{
									bool flag7 = !(type_0 == typeof(byte));
									if (flag7)
									{
										bool flag8 = !(type_0 == typeof(sbyte));
										if (flag8)
										{
											bool flag9 = !(type_0 == typeof(bool));
											if (flag9)
											{
												bool flag10 = !(type_0 == typeof(long));
												if (flag10)
												{
													bool flag11 = !(type_0 == typeof(ulong));
													if (flag11)
													{
														bool flag12 = type_0 == typeof(char);
														if (flag12)
														{
															result = (char)this.struct2_0.long_0;
														}
														else
														{
															bool flag13 = !type_0.IsEnum;
															if (flag13)
															{
																throw new Class11.Exception1();
															}
															result = this.method_6(type_0);
														}
													}
													else
													{
														result = this.struct2_0.ulong_0;
													}
												}
												else
												{
													result = this.struct2_0.long_0;
												}
											}
											else
											{
												result = !this.vmethod_11();
											}
										}
										else
										{
											result = this.struct2_0.sbyte_0;
										}
									}
									else
									{
										result = this.struct2_0.byte_0;
									}
								}
								else
								{
									result = this.struct2_0.ushort_0;
								}
							}
							else
							{
								result = this.struct2_0.short_0;
							}
						}
						else
						{
							result = this.struct2_0.uint_0;
						}
					}
				}
				else
				{
					Class11.Enum1 @enum = this.enum1_0;
					if (!true)
					{
					}
					object obj;
					switch (@enum)
					{
					case (Class11.Enum1)1:
						obj = this.struct2_0.sbyte_0;
						goto IL_3A1;
					case (Class11.Enum1)2:
						obj = this.struct2_0.byte_0;
						goto IL_3A1;
					case (Class11.Enum1)3:
						obj = this.struct2_0.short_0;
						goto IL_3A1;
					case (Class11.Enum1)4:
						obj = this.struct2_0.ushort_0;
						goto IL_3A1;
					case (Class11.Enum1)5:
						obj = this.struct2_0.int_0;
						goto IL_3A1;
					case (Class11.Enum1)6:
						obj = this.struct2_0.uint_0;
						goto IL_3A1;
					case (Class11.Enum1)7:
						obj = this.struct2_0.long_0;
						goto IL_3A1;
					case (Class11.Enum1)8:
						obj = this.struct2_0.ulong_0;
						goto IL_3A1;
					case (Class11.Enum1)11:
						obj = this.vmethod_12();
						goto IL_3A1;
					case (Class11.Enum1)15:
						obj = (char)this.struct2_0.int_0;
						goto IL_3A1;
					}
					obj = this.struct2_0.long_0;
					IL_3A1:
					if (!true)
					{
					}
					object obj2 = obj;
					result = obj2;
				}
				return result;
			}

			// Token: 0x060000A0 RID: 160 RVA: 0x00006244 File Offset: 0x00004444
			internal object method_6(Type type_0)
			{
				Type underlyingType = Enum.GetUnderlyingType(type_0);
				bool flag = !(underlyingType == typeof(int));
				object result;
				if (flag)
				{
					bool flag2 = !(underlyingType == typeof(uint));
					if (flag2)
					{
						bool flag3 = !(underlyingType == typeof(short));
						if (flag3)
						{
							bool flag4 = underlyingType == typeof(ushort);
							if (flag4)
							{
								result = Enum.ToObject(type_0, this.struct2_0.ushort_0);
							}
							else
							{
								bool flag5 = !(underlyingType == typeof(byte));
								if (flag5)
								{
									bool flag6 = !(underlyingType == typeof(sbyte));
									if (flag6)
									{
										bool flag7 = !(underlyingType == typeof(long));
										if (flag7)
										{
											bool flag8 = !(underlyingType == typeof(ulong));
											if (flag8)
											{
												bool flag9 = !(underlyingType == typeof(char));
												if (flag9)
												{
													result = Enum.ToObject(type_0, this.struct2_0.long_0);
												}
												else
												{
													result = Enum.ToObject(type_0, (ushort)this.struct2_0.int_0);
												}
											}
											else
											{
												result = Enum.ToObject(type_0, this.struct2_0.ulong_0);
											}
										}
										else
										{
											result = Enum.ToObject(type_0, this.struct2_0.long_0);
										}
									}
									else
									{
										result = Enum.ToObject(type_0, this.struct2_0.sbyte_0);
									}
								}
								else
								{
									result = Enum.ToObject(type_0, this.struct2_0.byte_0);
								}
							}
						}
						else
						{
							result = Enum.ToObject(type_0, this.struct2_0.short_0);
						}
					}
					else
					{
						result = Enum.ToObject(type_0, this.struct2_0.uint_0);
					}
				}
				else
				{
					result = Enum.ToObject(type_0, this.struct2_0.int_0);
				}
				return result;
			}

			// Token: 0x060000A1 RID: 161 RVA: 0x000047AC File Offset: 0x000029AC
			public override Class11.Class24 vmethod_14()
			{
				return new Class11.Class24((!this.vmethod_11()) ? 1 : 0);
			}

			// Token: 0x060000A2 RID: 162 RVA: 0x000047D0 File Offset: 0x000029D0
			internal override bool vmethod_7()
			{
				return this.vmethod_12();
			}

			// Token: 0x060000A3 RID: 163 RVA: 0x00006428 File Offset: 0x00004628
			public Class11.Class24 method_7()
			{
				return new Class11.Class24((int)this.struct2_0.sbyte_0, (Class11.Enum1)15);
			}

			// Token: 0x060000A4 RID: 164 RVA: 0x0000644C File Offset: 0x0000464C
			public override Class11.Class24 vmethod_15()
			{
				return new Class11.Class24((int)this.struct2_0.sbyte_0, (Class11.Enum1)1);
			}

			// Token: 0x060000A5 RID: 165 RVA: 0x00006470 File Offset: 0x00004670
			public override Class11.Class24 vmethod_16()
			{
				return new Class11.Class24((uint)this.struct2_0.byte_0, (Class11.Enum1)2);
			}

			// Token: 0x060000A6 RID: 166 RVA: 0x00006494 File Offset: 0x00004694
			public override Class11.Class24 vmethod_17()
			{
				return new Class11.Class24((int)this.struct2_0.short_0, (Class11.Enum1)3);
			}

			// Token: 0x060000A7 RID: 167 RVA: 0x000064B8 File Offset: 0x000046B8
			public override Class11.Class24 vmethod_18()
			{
				return new Class11.Class24((uint)this.struct2_0.ushort_0, (Class11.Enum1)4);
			}

			// Token: 0x060000A8 RID: 168 RVA: 0x000064DC File Offset: 0x000046DC
			public override Class11.Class24 vmethod_19()
			{
				return new Class11.Class24(this.struct2_0.int_0, (Class11.Enum1)5);
			}

			// Token: 0x060000A9 RID: 169 RVA: 0x00006500 File Offset: 0x00004700
			public override Class11.Class24 vmethod_20()
			{
				return new Class11.Class24(this.struct2_0.uint_0, (Class11.Enum1)6);
			}

			// Token: 0x060000AA RID: 170 RVA: 0x00006524 File Offset: 0x00004724
			public override Class11.Class25 vmethod_21()
			{
				return new Class11.Class25(this.struct2_0.long_0, (Class11.Enum1)7);
			}

			// Token: 0x060000AB RID: 171 RVA: 0x00006548 File Offset: 0x00004748
			public override Class11.Class25 vmethod_22()
			{
				return new Class11.Class25(this.struct2_0.ulong_0, (Class11.Enum1)8);
			}

			// Token: 0x060000AC RID: 172 RVA: 0x0000492C File Offset: 0x00002B2C
			public override Class11.Class24 vmethod_23()
			{
				return this.vmethod_15();
			}

			// Token: 0x060000AD RID: 173 RVA: 0x00004944 File Offset: 0x00002B44
			public override Class11.Class24 vmethod_24()
			{
				return this.vmethod_17();
			}

			// Token: 0x060000AE RID: 174 RVA: 0x0000495C File Offset: 0x00002B5C
			public override Class11.Class24 vmethod_25()
			{
				return this.vmethod_19();
			}

			// Token: 0x060000AF RID: 175 RVA: 0x00004974 File Offset: 0x00002B74
			public override Class11.Class25 vmethod_26()
			{
				return this.vmethod_21();
			}

			// Token: 0x060000B0 RID: 176 RVA: 0x0000498C File Offset: 0x00002B8C
			public override Class11.Class24 vmethod_27()
			{
				return this.vmethod_16();
			}

			// Token: 0x060000B1 RID: 177 RVA: 0x000049A4 File Offset: 0x00002BA4
			public override Class11.Class24 vmethod_28()
			{
				return this.vmethod_18();
			}

			// Token: 0x060000B2 RID: 178 RVA: 0x000049BC File Offset: 0x00002BBC
			public override Class11.Class24 vmethod_29()
			{
				return this.vmethod_20();
			}

			// Token: 0x060000B3 RID: 179 RVA: 0x000049D4 File Offset: 0x00002BD4
			public override Class11.Class25 vmethod_30()
			{
				return this.vmethod_22();
			}

			// Token: 0x060000B4 RID: 180 RVA: 0x0000656C File Offset: 0x0000476C
			public override Class11.Class24 vmethod_31()
			{
				return new Class11.Class24((int)(checked((sbyte)this.struct2_0.long_0)), (Class11.Enum1)1);
			}

			// Token: 0x060000B5 RID: 181 RVA: 0x00006590 File Offset: 0x00004790
			public override Class11.Class24 vmethod_32()
			{
				return new Class11.Class24((int)(checked((sbyte)this.struct2_0.ulong_0)), (Class11.Enum1)1);
			}

			// Token: 0x060000B6 RID: 182 RVA: 0x000065B4 File Offset: 0x000047B4
			public override Class11.Class24 vmethod_33()
			{
				return new Class11.Class24((int)(checked((short)this.struct2_0.long_0)), (Class11.Enum1)3);
			}

			// Token: 0x060000B7 RID: 183 RVA: 0x000065D8 File Offset: 0x000047D8
			public override Class11.Class24 vmethod_34()
			{
				return new Class11.Class24((int)(checked((short)this.struct2_0.ulong_0)), (Class11.Enum1)3);
			}

			// Token: 0x060000B8 RID: 184 RVA: 0x000065FC File Offset: 0x000047FC
			public override Class11.Class24 vmethod_35()
			{
				return new Class11.Class24(checked((int)this.struct2_0.long_0), (Class11.Enum1)5);
			}

			// Token: 0x060000B9 RID: 185 RVA: 0x00006620 File Offset: 0x00004820
			public override Class11.Class24 vmethod_36()
			{
				return new Class11.Class24(checked((int)this.struct2_0.ulong_0), (Class11.Enum1)5);
			}

			// Token: 0x060000BA RID: 186 RVA: 0x00006524 File Offset: 0x00004724
			public override Class11.Class25 vmethod_37()
			{
				return new Class11.Class25(this.struct2_0.long_0, (Class11.Enum1)7);
			}

			// Token: 0x060000BB RID: 187 RVA: 0x00006644 File Offset: 0x00004844
			public override Class11.Class25 vmethod_38()
			{
				return new Class11.Class25(checked((long)this.struct2_0.ulong_0), (Class11.Enum1)7);
			}

			// Token: 0x060000BC RID: 188 RVA: 0x00006668 File Offset: 0x00004868
			public override Class11.Class24 vmethod_39()
			{
				return new Class11.Class24((int)(checked((byte)this.struct2_0.long_0)), (Class11.Enum1)2);
			}

			// Token: 0x060000BD RID: 189 RVA: 0x0000668C File Offset: 0x0000488C
			public override Class11.Class24 vmethod_40()
			{
				return new Class11.Class24((int)(checked((byte)this.struct2_0.ulong_0)), (Class11.Enum1)2);
			}

			// Token: 0x060000BE RID: 190 RVA: 0x000066B0 File Offset: 0x000048B0
			public override Class11.Class24 vmethod_41()
			{
				return new Class11.Class24((int)(checked((ushort)this.struct2_0.long_0)), (Class11.Enum1)4);
			}

			// Token: 0x060000BF RID: 191 RVA: 0x000066D4 File Offset: 0x000048D4
			public override Class11.Class24 vmethod_42()
			{
				return new Class11.Class24((int)(checked((ushort)this.struct2_0.ulong_0)), (Class11.Enum1)4);
			}

			// Token: 0x060000C0 RID: 192 RVA: 0x000066F8 File Offset: 0x000048F8
			public override Class11.Class24 vmethod_43()
			{
				return new Class11.Class24(checked((uint)this.struct2_0.long_0), (Class11.Enum1)6);
			}

			// Token: 0x060000C1 RID: 193 RVA: 0x0000671C File Offset: 0x0000491C
			public override Class11.Class24 vmethod_44()
			{
				return new Class11.Class24(checked((uint)this.struct2_0.ulong_0), (Class11.Enum1)6);
			}

			// Token: 0x060000C2 RID: 194 RVA: 0x00006740 File Offset: 0x00004940
			public override Class11.Class25 vmethod_45()
			{
				return new Class11.Class25(checked((ulong)this.struct2_0.long_0), (Class11.Enum1)8);
			}

			// Token: 0x060000C3 RID: 195 RVA: 0x00006548 File Offset: 0x00004748
			public override Class11.Class25 vmethod_46()
			{
				return new Class11.Class25(this.struct2_0.ulong_0, (Class11.Enum1)8);
			}

			// Token: 0x060000C4 RID: 196 RVA: 0x00006764 File Offset: 0x00004964
			public override Class11.Class27 vmethod_47()
			{
				return new Class11.Class27((float)this.struct2_0.long_0);
			}

			// Token: 0x060000C5 RID: 197 RVA: 0x00006788 File Offset: 0x00004988
			public override Class11.Class27 vmethod_48()
			{
				return new Class11.Class27((double)this.struct2_0.long_0);
			}

			// Token: 0x060000C6 RID: 198 RVA: 0x000067AC File Offset: 0x000049AC
			public override Class11.Class27 vmethod_49()
			{
				return new Class11.Class27(this.struct2_0.ulong_0);
			}

			// Token: 0x060000C7 RID: 199 RVA: 0x00004C08 File Offset: 0x00002E08
			public override Class11.Class26 vmethod_50()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_26().struct2_0.long_0);
				}
				else
				{
					result = new Class11.Class26((long)this.vmethod_25().struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x060000C8 RID: 200 RVA: 0x00004C58 File Offset: 0x00002E58
			public override Class11.Class26 vmethod_51()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_30().struct2_0.ulong_0);
				}
				else
				{
					result = new Class11.Class26((ulong)this.vmethod_29().struct1_0.uint_0);
				}
				return result;
			}

			// Token: 0x060000C9 RID: 201 RVA: 0x00004CA8 File Offset: 0x00002EA8
			public override Class11.Class26 vmethod_52()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_37().struct2_0.long_0);
				}
				else
				{
					result = new Class11.Class26((long)this.vmethod_35().struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x060000CA RID: 202 RVA: 0x00004CF8 File Offset: 0x00002EF8
			public override Class11.Class26 vmethod_53()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_45().struct2_0.ulong_0);
				}
				else
				{
					result = new Class11.Class26((ulong)this.vmethod_43().struct1_0.uint_0);
				}
				return result;
			}

			// Token: 0x060000CB RID: 203 RVA: 0x00004D48 File Offset: 0x00002F48
			public override Class11.Class26 vmethod_54()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_38().struct2_0.long_0);
				}
				else
				{
					result = new Class11.Class26((long)this.vmethod_36().struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x060000CC RID: 204 RVA: 0x000067D0 File Offset: 0x000049D0
			public override Class11.Class26 vmethod_55()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.struct2_0.ulong_0);
				}
				else
				{
					result = new Class11.Class26((ulong)(checked((uint)this.struct2_0.ulong_0)));
				}
				return result;
			}

			// Token: 0x060000CD RID: 205 RVA: 0x00006814 File Offset: 0x00004A14
			public override Class11.Class22 vmethod_56()
			{
				return new Class11.Class25(-this.struct2_0.long_0);
			}

			// Token: 0x060000CE RID: 206 RVA: 0x00006838 File Offset: 0x00004A38
			public override Class11.Class22 vmethod_57(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class25(this.struct2_0.long_0 + ((Class11.Class25)class22_0).struct2_0.long_0);
			}

			// Token: 0x060000CF RID: 207 RVA: 0x00006894 File Offset: 0x00004A94
			public override Class11.Class22 vmethod_58(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class25(checked(this.struct2_0.long_0 + ((Class11.Class25)class22_0).struct2_0.long_0));
			}

			// Token: 0x060000D0 RID: 208 RVA: 0x000068F0 File Offset: 0x00004AF0
			public override Class11.Class22 vmethod_59(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class25(checked(this.struct2_0.ulong_0 + ((Class11.Class25)class22_0).struct2_0.ulong_0));
			}

			// Token: 0x060000D1 RID: 209 RVA: 0x0000694C File Offset: 0x00004B4C
			public override Class11.Class22 vmethod_60(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class25(this.struct2_0.long_0 - ((Class11.Class25)class22_0).struct2_0.long_0);
			}

			// Token: 0x060000D2 RID: 210 RVA: 0x000069A8 File Offset: 0x00004BA8
			public override Class11.Class22 vmethod_61(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class25(checked(this.struct2_0.long_0 - ((Class11.Class25)class22_0).struct2_0.long_0));
			}

			// Token: 0x060000D3 RID: 211 RVA: 0x00006A04 File Offset: 0x00004C04
			public override Class11.Class22 vmethod_62(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class25(checked(this.struct2_0.ulong_0 - ((Class11.Class25)class22_0).struct2_0.ulong_0));
			}

			// Token: 0x060000D4 RID: 212 RVA: 0x00006A60 File Offset: 0x00004C60
			public override Class11.Class22 vmethod_63(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class25(this.struct2_0.long_0 * ((Class11.Class25)class22_0).struct2_0.long_0);
			}

			// Token: 0x060000D5 RID: 213 RVA: 0x00006ABC File Offset: 0x00004CBC
			public override Class11.Class22 vmethod_64(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class25(checked(this.struct2_0.long_0 * ((Class11.Class25)class22_0).struct2_0.long_0));
			}

			// Token: 0x060000D6 RID: 214 RVA: 0x00006B18 File Offset: 0x00004D18
			public override Class11.Class22 vmethod_65(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class25(checked(this.struct2_0.ulong_0 * ((Class11.Class25)class22_0).struct2_0.ulong_0));
			}

			// Token: 0x060000D7 RID: 215 RVA: 0x00006B74 File Offset: 0x00004D74
			public override Class11.Class22 vmethod_66(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class25(this.struct2_0.long_0 / ((Class11.Class25)class22_0).struct2_0.long_0);
			}

			// Token: 0x060000D8 RID: 216 RVA: 0x00006BD0 File Offset: 0x00004DD0
			public override Class11.Class22 vmethod_67(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class25(this.struct2_0.ulong_0 / ((Class11.Class25)class22_0).struct2_0.ulong_0);
			}

			// Token: 0x060000D9 RID: 217 RVA: 0x00006C2C File Offset: 0x00004E2C
			public override Class11.Class22 vmethod_68(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class25(this.struct2_0.long_0 % ((Class11.Class25)class22_0).struct2_0.long_0);
			}

			// Token: 0x060000DA RID: 218 RVA: 0x00006C88 File Offset: 0x00004E88
			public override Class11.Class22 vmethod_69(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class25(this.struct2_0.ulong_0 % ((Class11.Class25)class22_0).struct2_0.ulong_0);
			}

			// Token: 0x060000DB RID: 219 RVA: 0x00006CE4 File Offset: 0x00004EE4
			public override Class11.Class22 vmethod_70(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class25(this.struct2_0.long_0 & ((Class11.Class25)class22_0).struct2_0.long_0);
			}

			// Token: 0x060000DC RID: 220 RVA: 0x00006D40 File Offset: 0x00004F40
			public override Class11.Class22 vmethod_71(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class25(this.struct2_0.long_0 | ((Class11.Class25)class22_0).struct2_0.long_0);
			}

			// Token: 0x060000DD RID: 221 RVA: 0x00006D9C File Offset: 0x00004F9C
			public override Class11.Class22 vmethod_72()
			{
				return new Class11.Class25(~this.struct2_0.long_0);
			}

			// Token: 0x060000DE RID: 222 RVA: 0x00006DC0 File Offset: 0x00004FC0
			public override Class11.Class22 vmethod_73(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class25(this.struct2_0.long_0 ^ ((Class11.Class25)class22_0).struct2_0.long_0);
			}

			// Token: 0x060000DF RID: 223 RVA: 0x00006E1C File Offset: 0x0000501C
			public override Class11.Class22 vmethod_75(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = !class22_0.vmethod_3();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = new Class11.Class25(this.struct2_0.long_0 << ((Class11.Class23)class22_0).vmethod_19().struct1_0.int_0);
				}
				else
				{
					result = new Class11.Class25(this.struct2_0.long_0 << ((Class11.Class25)class22_0).struct2_0.int_0);
				}
				return result;
			}

			// Token: 0x060000E0 RID: 224 RVA: 0x00006EB4 File Offset: 0x000050B4
			public override Class11.Class22 vmethod_76(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_3();
				Class11.Class22 result;
				if (flag2)
				{
					result = new Class11.Class25(this.struct2_0.long_0 >> ((Class11.Class25)class22_0).struct2_0.int_0);
				}
				else
				{
					bool flag3 = !class22_0.vmethod_3();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					result = new Class11.Class25(this.struct2_0.long_0 >> ((Class11.Class23)class22_0).vmethod_19().struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x060000E1 RID: 225 RVA: 0x00006F4C File Offset: 0x0000514C
			public override Class11.Class22 vmethod_77(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.vmethod_3();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					result = new Class11.Class25(this.struct2_0.ulong_0 >> ((Class11.Class23)class22_0).vmethod_19().struct1_0.int_0);
				}
				else
				{
					result = new Class11.Class25(this.struct2_0.ulong_0 >> ((Class11.Class25)class22_0).struct2_0.int_0);
				}
				return result;
			}

			// Token: 0x060000E2 RID: 226 RVA: 0x00006FE4 File Offset: 0x000051E4
			public override string ToString()
			{
				bool flag = this.enum1_0 == (Class11.Enum1)7;
				string result;
				if (flag)
				{
					result = this.struct2_0.long_0.ToString();
				}
				else
				{
					result = this.struct2_0.ulong_0.ToString();
				}
				return result;
			}

			// Token: 0x060000E3 RID: 227 RVA: 0x000057CC File Offset: 0x000039CC
			internal override Class11.Class22 vmethod_8()
			{
				return this;
			}

			// Token: 0x060000E4 RID: 228 RVA: 0x000057E0 File Offset: 0x000039E0
			internal override bool vmethod_9()
			{
				return true;
			}

			// Token: 0x060000E5 RID: 229 RVA: 0x00007028 File Offset: 0x00005228
			internal override bool vmethod_5(Class11.Class22 class22_0)
			{
				bool flag = class22_0.method_0();
				bool result;
				if (flag)
				{
					result = ((Class11.Class34)class22_0).vmethod_5(this);
				}
				else
				{
					bool flag2 = class22_0.vmethod_0();
					if (flag2)
					{
						result = ((Class11.Class28)class22_0).vmethod_5(this);
					}
					else
					{
						Class11.Class22 @class = class22_0.vmethod_8();
						bool flag3 = !@class.method_3();
						result = (!flag3 && this.struct2_0.long_0 == ((Class11.Class25)@class).struct2_0.long_0);
					}
				}
				return result;
			}

			// Token: 0x060000E6 RID: 230 RVA: 0x000058A8 File Offset: 0x00003AA8
			private static Class11.Class23 smethod_4(Class11.Class22 class22_0)
			{
				Class11.Class23 @class = class22_0 as Class11.Class23;
				bool flag = @class == null && class22_0.vmethod_0();
				if (flag)
				{
					@class = (class22_0.vmethod_8() as Class11.Class23);
				}
				return @class;
			}

			// Token: 0x060000E7 RID: 231 RVA: 0x000070A8 File Offset: 0x000052A8
			internal override bool vmethod_6(Class11.Class22 class22_0)
			{
				bool flag = class22_0.method_0();
				bool result;
				if (flag)
				{
					result = false;
				}
				else
				{
					bool flag2 = !class22_0.vmethod_0();
					if (flag2)
					{
						Class11.Class22 @class = class22_0.vmethod_8();
						bool flag3 = @class.method_3();
						result = (flag3 && this.struct2_0.ulong_0 != ((Class11.Class25)@class).struct2_0.ulong_0);
					}
					else
					{
						result = ((Class11.Class28)class22_0).vmethod_6(this);
					}
				}
				return result;
			}

			// Token: 0x060000E8 RID: 232 RVA: 0x00007120 File Offset: 0x00005320
			public override bool vmethod_78(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return this.struct2_0.long_0 >= ((Class11.Class25)class22_0).struct2_0.long_0;
			}

			// Token: 0x060000E9 RID: 233 RVA: 0x0000717C File Offset: 0x0000537C
			public override bool vmethod_79(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return this.struct2_0.ulong_0 >= ((Class11.Class25)class22_0).struct2_0.ulong_0;
			}

			// Token: 0x060000EA RID: 234 RVA: 0x000071D8 File Offset: 0x000053D8
			public override bool vmethod_80(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return this.struct2_0.long_0 > ((Class11.Class25)class22_0).struct2_0.long_0;
			}

			// Token: 0x060000EB RID: 235 RVA: 0x00007230 File Offset: 0x00005430
			public override bool vmethod_81(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return this.struct2_0.ulong_0 > ((Class11.Class25)class22_0).struct2_0.ulong_0;
			}

			// Token: 0x060000EC RID: 236 RVA: 0x00007288 File Offset: 0x00005488
			public override bool vmethod_82(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return this.struct2_0.long_0 <= ((Class11.Class25)class22_0).struct2_0.long_0;
			}

			// Token: 0x060000ED RID: 237 RVA: 0x000072E4 File Offset: 0x000054E4
			public override bool vmethod_83(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return this.struct2_0.ulong_0 <= ((Class11.Class25)class22_0).struct2_0.ulong_0;
			}

			// Token: 0x060000EE RID: 238 RVA: 0x00007340 File Offset: 0x00005540
			public override bool vmethod_84(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return this.struct2_0.long_0 < ((Class11.Class25)class22_0).struct2_0.long_0;
			}

			// Token: 0x060000EF RID: 239 RVA: 0x00007398 File Offset: 0x00005598
			public override bool vmethod_85(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_3();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return this.struct2_0.ulong_0 < ((Class11.Class25)class22_0).struct2_0.ulong_0;
			}

			// Token: 0x04000029 RID: 41
			public Class11.Struct2 struct2_0;

			// Token: 0x0400002A RID: 42
			public Class11.Enum1 enum1_0;
		}

		// Token: 0x0200001B RID: 27
		private class Class26 : Class11.Class23
		{
			// Token: 0x060000F0 RID: 240 RVA: 0x000073F0 File Offset: 0x000055F0
			internal void method_6(Class11.Class22 class22_0)
			{
				bool flag = !class22_0.method_2();
				if (flag)
				{
					this.vmethod_10(class22_0);
				}
				else
				{
					this.object_0 = ((Class11.Class26)class22_0).object_0;
					this.enum1_0 = ((Class11.Class26)class22_0).enum1_0;
				}
			}

			// Token: 0x060000F1 RID: 241 RVA: 0x00007438 File Offset: 0x00005638
			internal unsafe override void vmethod_10(Class11.Class22 class22_0)
			{
				bool flag = !class22_0.method_2();
				if (flag)
				{
					object obj = class22_0.vmethod_4(null);
					bool flag2 = obj == null;
					if (!flag2)
					{
						IntPtr value = (IntPtr.Size != 8) ? new IntPtr(((Class11.Class24)this.object_0).struct1_0.int_0) : new IntPtr(((Class11.Class25)this.object_0).struct2_0.long_0);
						Type type = obj.GetType();
						bool flag3 = type == typeof(string);
						if (!flag3)
						{
							bool flag4 = type == typeof(byte);
							if (flag4)
							{
								*(byte*)((void*)value) = (byte)obj;
							}
							else
							{
								bool flag5 = type == typeof(sbyte);
								if (flag5)
								{
									*(byte*)((void*)value) = (byte)((sbyte)obj);
								}
								else
								{
									bool flag6 = !(type == typeof(short));
									if (flag6)
									{
										bool flag7 = type == typeof(ushort);
										if (flag7)
										{
											*(short*)((void*)value) = (short)((ushort)obj);
										}
										else
										{
											bool flag8 = type == typeof(int);
											if (flag8)
											{
												*(int*)((void*)value) = (int)obj;
											}
											else
											{
												bool flag9 = type == typeof(uint);
												if (flag9)
												{
													*(int*)((void*)value) = (int)((uint)obj);
												}
												else
												{
													bool flag10 = type == typeof(long);
													if (flag10)
													{
														*(long*)((void*)value) = (long)obj;
													}
													else
													{
														bool flag11 = !(type == typeof(ulong));
														if (flag11)
														{
															bool flag12 = !(type == typeof(float));
															if (flag12)
															{
																bool flag13 = !(type == typeof(double));
																if (flag13)
																{
																	bool flag14 = !(type == typeof(bool));
																	if (flag14)
																	{
																		bool flag15 = !(type == typeof(IntPtr));
																		if (flag15)
																		{
																			bool flag16 = !(type == typeof(UIntPtr));
																			if (flag16)
																			{
																				bool flag17 = !(type == typeof(char));
																				if (flag17)
																				{
																					throw new Class11.Exception1();
																				}
																				*(short*)((void*)value) = (short)((char)obj);
																			}
																			else
																			{
																				*(IntPtr*)((void*)value) = (IntPtr)((UIntPtr)obj);
																			}
																		}
																		else
																		{
																			*(IntPtr*)((void*)value) = (IntPtr)obj;
																		}
																	}
																	else
																	{
																		*(byte*)((void*)value) = (((bool)obj) ? 1 : 0);
																	}
																}
																else
																{
																	*(double*)((void*)value) = (double)obj;
																}
															}
															else
															{
																*(float*)((void*)value) = (float)obj;
															}
														}
														else
														{
															*(long*)((void*)value) = (long)((ulong)obj);
														}
													}
												}
											}
										}
									}
									else
									{
										*(short*)((void*)value) = (short)obj;
									}
								}
							}
						}
					}
				}
				else
				{
					bool flag18 = IntPtr.Size == 8;
					if (flag18)
					{
						IntPtr value2 = new IntPtr(((Class11.Class25)this.object_0).struct2_0.long_0);
						IntPtr intPtr = new IntPtr(((Class11.Class25)((Class11.Class26)class22_0).object_0).struct2_0.long_0);
						*(long*)((void*)value2) = intPtr.ToInt64();
					}
					else
					{
						IntPtr value3 = new IntPtr(((Class11.Class24)this.object_0).struct1_0.int_0);
						IntPtr intPtr2 = new IntPtr(((Class11.Class24)((Class11.Class26)class22_0).object_0).struct1_0.int_0);
						*(int*)((void*)value3) = intPtr2.ToInt32();
					}
				}
			}

			// Token: 0x060000F2 RID: 242 RVA: 0x00002325 File Offset: 0x00000525
			internal override void vmethod_2(Class11.Class22 class22_0)
			{
				this.vmethod_10(class22_0);
			}

			// Token: 0x060000F3 RID: 243 RVA: 0x000077F0 File Offset: 0x000059F0
			public Class26(IntPtr intptr_0)
			{
				this.enum4_0 = (Class11.Enum4)3;
				bool flag = IntPtr.Size == 8;
				if (flag)
				{
					this.object_0 = new Class11.Class25(intptr_0.ToInt64());
					this.enum1_0 = (Class11.Enum1)12;
				}
				else
				{
					this.object_0 = new Class11.Class24(intptr_0.ToInt32());
					this.enum1_0 = (Class11.Enum1)12;
				}
			}

			// Token: 0x060000F4 RID: 244 RVA: 0x00007854 File Offset: 0x00005A54
			public Class26(UIntPtr uintptr_0)
			{
				this.enum4_0 = (Class11.Enum4)3;
				bool flag = IntPtr.Size == 8;
				if (flag)
				{
					this.object_0 = new Class11.Class25(uintptr_0.ToUInt64());
					this.enum1_0 = (Class11.Enum1)12;
				}
				else
				{
					this.object_0 = new Class11.Class24(uintptr_0.ToUInt32());
					this.enum1_0 = (Class11.Enum1)12;
				}
			}

			// Token: 0x060000F5 RID: 245 RVA: 0x000078B8 File Offset: 0x00005AB8
			public Class26()
			{
				this.enum4_0 = (Class11.Enum4)3;
				bool flag = IntPtr.Size == 8;
				if (flag)
				{
					this.object_0 = new Class11.Class25(0L);
					this.enum1_0 = (Class11.Enum1)12;
				}
				else
				{
					this.object_0 = new Class11.Class24(0);
					this.enum1_0 = (Class11.Enum1)12;
				}
			}

			// Token: 0x060000F6 RID: 246 RVA: 0x00007910 File Offset: 0x00005B10
			public override Class11.Class23 vmethod_74()
			{
				return new Class11.Class26
				{
					object_0 = ((Class11.Class23)this.object_0).vmethod_74(),
					enum1_0 = this.enum1_0
				};
			}

			// Token: 0x060000F7 RID: 247 RVA: 0x0000794C File Offset: 0x00005B4C
			public Class26(long long_0)
			{
				this.enum4_0 = (Class11.Enum4)3;
				bool flag = IntPtr.Size == 8;
				if (flag)
				{
					this.object_0 = new Class11.Class25(long_0);
					this.enum1_0 = (Class11.Enum1)12;
				}
				else
				{
					this.object_0 = new Class11.Class24((int)long_0);
					this.enum1_0 = (Class11.Enum1)12;
				}
			}

			// Token: 0x060000F8 RID: 248 RVA: 0x000079A4 File Offset: 0x00005BA4
			public Class26(long long_0, Class11.Enum1 enum1_1)
			{
				this.enum4_0 = (Class11.Enum4)3;
				bool flag = IntPtr.Size == 8;
				if (flag)
				{
					this.object_0 = new Class11.Class25(long_0);
					this.enum1_0 = enum1_1;
				}
				else
				{
					this.object_0 = new Class11.Class24((int)long_0);
					this.enum1_0 = enum1_1;
				}
			}

			// Token: 0x060000F9 RID: 249 RVA: 0x000079FC File Offset: 0x00005BFC
			public Class26(ulong ulong_0)
			{
				this.enum4_0 = (Class11.Enum4)4;
				bool flag = IntPtr.Size == 8;
				if (flag)
				{
					this.object_0 = new Class11.Class25(ulong_0);
					this.enum1_0 = (Class11.Enum1)13;
				}
				else
				{
					this.object_0 = new Class11.Class24((uint)ulong_0);
					this.enum1_0 = (Class11.Enum1)13;
				}
			}

			// Token: 0x060000FA RID: 250 RVA: 0x00007A54 File Offset: 0x00005C54
			public Class26(ulong ulong_0, Class11.Enum1 enum1_1)
			{
				this.enum4_0 = (Class11.Enum4)4;
				bool flag = IntPtr.Size == 8;
				if (flag)
				{
					this.object_0 = new Class11.Class25(ulong_0);
					this.enum1_0 = enum1_1;
				}
				else
				{
					this.object_0 = new Class11.Class24((uint)ulong_0);
					this.enum1_0 = enum1_1;
				}
			}

			// Token: 0x060000FB RID: 251 RVA: 0x00007AAC File Offset: 0x00005CAC
			public override bool vmethod_11()
			{
				return ((Class11.Class23)this.object_0).vmethod_11();
			}

			// Token: 0x060000FC RID: 252 RVA: 0x000040C8 File Offset: 0x000022C8
			public override bool vmethod_12()
			{
				return !this.vmethod_11();
			}

			// Token: 0x060000FD RID: 253 RVA: 0x000047D0 File Offset: 0x000029D0
			internal override bool vmethod_7()
			{
				return this.vmethod_12();
			}

			// Token: 0x060000FE RID: 254 RVA: 0x000057E0 File Offset: 0x000039E0
			internal override bool vmethod_1()
			{
				return true;
			}

			// Token: 0x060000FF RID: 255 RVA: 0x00007AD0 File Offset: 0x00005CD0
			public override Class11.Class22 vmethod_13(Class11.Enum1 enum1_1)
			{
				if (!true)
				{
				}
				Class11.Class23 result;
				switch (enum1_1)
				{
				case (Class11.Enum1)1:
					result = this.vmethod_15();
					goto IL_CA;
				case (Class11.Enum1)2:
					result = this.vmethod_16();
					goto IL_CA;
				case (Class11.Enum1)3:
					result = this.vmethod_17();
					goto IL_CA;
				case (Class11.Enum1)4:
					result = this.vmethod_18();
					goto IL_CA;
				case (Class11.Enum1)5:
					result = this.vmethod_19();
					goto IL_CA;
				case (Class11.Enum1)6:
					result = this.vmethod_20();
					goto IL_CA;
				case (Class11.Enum1)7:
					result = this.vmethod_21();
					goto IL_CA;
				case (Class11.Enum1)8:
					result = this.vmethod_22();
					goto IL_CA;
				case (Class11.Enum1)11:
					result = this.vmethod_14();
					goto IL_CA;
				case (Class11.Enum1)12:
					result = this;
					goto IL_CA;
				case (Class11.Enum1)13:
					result = this;
					goto IL_CA;
				case (Class11.Enum1)16:
					result = this.vmethod_74();
					goto IL_CA;
				}
				throw new Exception(((Class11.Enum5)4).ToString());
				IL_CA:
				if (!true)
				{
				}
				return result;
			}

			// Token: 0x06000100 RID: 256 RVA: 0x00007BBC File Offset: 0x00005DBC
			internal IntPtr method_7()
			{
				bool flag = IntPtr.Size == 8;
				IntPtr result;
				if (flag)
				{
					result = new IntPtr(((Class11.Class25)this.object_0).struct2_0.long_0);
				}
				else
				{
					result = new IntPtr(((Class11.Class24)this.object_0).struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x06000101 RID: 257 RVA: 0x00007C14 File Offset: 0x00005E14
			internal override object vmethod_4(Type type_0)
			{
				bool flag = type_0 != null && type_0.IsByRef;
				if (flag)
				{
					type_0 = type_0.GetElementType();
				}
				bool flag2 = type_0 == typeof(IntPtr);
				object result;
				if (flag2)
				{
					bool flag3 = IntPtr.Size == 8;
					if (flag3)
					{
						result = new IntPtr(((Class11.Class25)this.object_0).struct2_0.long_0);
					}
					else
					{
						result = new IntPtr(((Class11.Class24)this.object_0).struct1_0.int_0);
					}
				}
				else
				{
					bool flag4 = !(type_0 == typeof(UIntPtr));
					if (flag4)
					{
						bool flag5 = !(type_0 == null) && !(type_0 == typeof(object));
						if (flag5)
						{
							throw new Class11.Exception1();
						}
						bool flag6 = IntPtr.Size == 8;
						if (flag6)
						{
							bool flag7 = this.enum1_0 == (Class11.Enum1)12;
							if (flag7)
							{
								result = new IntPtr(((Class11.Class25)this.object_0).struct2_0.long_0);
							}
							else
							{
								result = new UIntPtr(((Class11.Class25)this.object_0).struct2_0.ulong_0);
							}
						}
						else
						{
							bool flag8 = this.enum1_0 == (Class11.Enum1)12;
							if (flag8)
							{
								result = new IntPtr(((Class11.Class25)this.object_0).struct2_0.int_0);
							}
							else
							{
								result = new UIntPtr(((Class11.Class24)this.object_0).struct1_0.uint_0);
							}
						}
					}
					else
					{
						bool flag9 = IntPtr.Size == 8;
						if (flag9)
						{
							result = new UIntPtr(((Class11.Class25)this.object_0).struct2_0.ulong_0);
						}
						else
						{
							result = new UIntPtr(((Class11.Class24)this.object_0).struct1_0.uint_0);
						}
					}
				}
				return result;
			}

			// Token: 0x06000102 RID: 258 RVA: 0x00007E0C File Offset: 0x0000600C
			public override Class11.Class24 vmethod_14()
			{
				return ((Class11.Class23)this.object_0).vmethod_14();
			}

			// Token: 0x06000103 RID: 259 RVA: 0x00007E30 File Offset: 0x00006030
			public override Class11.Class24 vmethod_15()
			{
				return ((Class11.Class23)this.object_0).vmethod_15();
			}

			// Token: 0x06000104 RID: 260 RVA: 0x00007E54 File Offset: 0x00006054
			public override Class11.Class24 vmethod_16()
			{
				return ((Class11.Class23)this.object_0).vmethod_16();
			}

			// Token: 0x06000105 RID: 261 RVA: 0x00007E78 File Offset: 0x00006078
			public override Class11.Class24 vmethod_17()
			{
				return ((Class11.Class23)this.object_0).vmethod_17();
			}

			// Token: 0x06000106 RID: 262 RVA: 0x00007E9C File Offset: 0x0000609C
			public override Class11.Class24 vmethod_18()
			{
				return ((Class11.Class23)this.object_0).vmethod_18();
			}

			// Token: 0x06000107 RID: 263 RVA: 0x00007EC0 File Offset: 0x000060C0
			public override Class11.Class24 vmethod_19()
			{
				return ((Class11.Class23)this.object_0).vmethod_19();
			}

			// Token: 0x06000108 RID: 264 RVA: 0x00007EE4 File Offset: 0x000060E4
			public override Class11.Class24 vmethod_20()
			{
				return ((Class11.Class23)this.object_0).vmethod_20();
			}

			// Token: 0x06000109 RID: 265 RVA: 0x00007F08 File Offset: 0x00006108
			public override Class11.Class25 vmethod_21()
			{
				return ((Class11.Class23)this.object_0).vmethod_21();
			}

			// Token: 0x0600010A RID: 266 RVA: 0x00007F2C File Offset: 0x0000612C
			public override Class11.Class25 vmethod_22()
			{
				return ((Class11.Class23)this.object_0).vmethod_22();
			}

			// Token: 0x0600010B RID: 267 RVA: 0x0000492C File Offset: 0x00002B2C
			public override Class11.Class24 vmethod_23()
			{
				return this.vmethod_15();
			}

			// Token: 0x0600010C RID: 268 RVA: 0x00004944 File Offset: 0x00002B44
			public override Class11.Class24 vmethod_24()
			{
				return this.vmethod_17();
			}

			// Token: 0x0600010D RID: 269 RVA: 0x0000495C File Offset: 0x00002B5C
			public override Class11.Class24 vmethod_25()
			{
				return this.vmethod_19();
			}

			// Token: 0x0600010E RID: 270 RVA: 0x00004974 File Offset: 0x00002B74
			public override Class11.Class25 vmethod_26()
			{
				return this.vmethod_21();
			}

			// Token: 0x0600010F RID: 271 RVA: 0x0000498C File Offset: 0x00002B8C
			public override Class11.Class24 vmethod_27()
			{
				return this.vmethod_16();
			}

			// Token: 0x06000110 RID: 272 RVA: 0x000049A4 File Offset: 0x00002BA4
			public override Class11.Class24 vmethod_28()
			{
				return this.vmethod_18();
			}

			// Token: 0x06000111 RID: 273 RVA: 0x000049BC File Offset: 0x00002BBC
			public override Class11.Class24 vmethod_29()
			{
				return this.vmethod_20();
			}

			// Token: 0x06000112 RID: 274 RVA: 0x000049D4 File Offset: 0x00002BD4
			public override Class11.Class25 vmethod_30()
			{
				return this.vmethod_22();
			}

			// Token: 0x06000113 RID: 275 RVA: 0x00007F50 File Offset: 0x00006150
			public override Class11.Class24 vmethod_31()
			{
				return ((Class11.Class23)this.object_0).vmethod_31();
			}

			// Token: 0x06000114 RID: 276 RVA: 0x00007F74 File Offset: 0x00006174
			public override Class11.Class24 vmethod_32()
			{
				return ((Class11.Class23)this.object_0).vmethod_32();
			}

			// Token: 0x06000115 RID: 277 RVA: 0x00007F98 File Offset: 0x00006198
			public override Class11.Class24 vmethod_33()
			{
				return ((Class11.Class23)this.object_0).vmethod_33();
			}

			// Token: 0x06000116 RID: 278 RVA: 0x00007FBC File Offset: 0x000061BC
			public override Class11.Class24 vmethod_34()
			{
				return ((Class11.Class23)this.object_0).vmethod_34();
			}

			// Token: 0x06000117 RID: 279 RVA: 0x00007FE0 File Offset: 0x000061E0
			public override Class11.Class24 vmethod_35()
			{
				return ((Class11.Class23)this.object_0).vmethod_35();
			}

			// Token: 0x06000118 RID: 280 RVA: 0x00008004 File Offset: 0x00006204
			public override Class11.Class24 vmethod_36()
			{
				return ((Class11.Class23)this.object_0).vmethod_36();
			}

			// Token: 0x06000119 RID: 281 RVA: 0x00008028 File Offset: 0x00006228
			public override Class11.Class25 vmethod_37()
			{
				return ((Class11.Class23)this.object_0).vmethod_37();
			}

			// Token: 0x0600011A RID: 282 RVA: 0x0000804C File Offset: 0x0000624C
			public override Class11.Class25 vmethod_38()
			{
				return ((Class11.Class23)this.object_0).vmethod_38();
			}

			// Token: 0x0600011B RID: 283 RVA: 0x00008070 File Offset: 0x00006270
			public override Class11.Class24 vmethod_39()
			{
				return ((Class11.Class23)this.object_0).vmethod_39();
			}

			// Token: 0x0600011C RID: 284 RVA: 0x00008094 File Offset: 0x00006294
			public override Class11.Class24 vmethod_40()
			{
				return ((Class11.Class23)this.object_0).vmethod_40();
			}

			// Token: 0x0600011D RID: 285 RVA: 0x000080B8 File Offset: 0x000062B8
			public override Class11.Class24 vmethod_41()
			{
				return ((Class11.Class23)this.object_0).vmethod_41();
			}

			// Token: 0x0600011E RID: 286 RVA: 0x000080DC File Offset: 0x000062DC
			public override Class11.Class24 vmethod_42()
			{
				return ((Class11.Class23)this.object_0).vmethod_42();
			}

			// Token: 0x0600011F RID: 287 RVA: 0x00008100 File Offset: 0x00006300
			public override Class11.Class24 vmethod_43()
			{
				return ((Class11.Class23)this.object_0).vmethod_43();
			}

			// Token: 0x06000120 RID: 288 RVA: 0x00008124 File Offset: 0x00006324
			public override Class11.Class24 vmethod_44()
			{
				return ((Class11.Class23)this.object_0).vmethod_44();
			}

			// Token: 0x06000121 RID: 289 RVA: 0x00008148 File Offset: 0x00006348
			public override Class11.Class25 vmethod_45()
			{
				return ((Class11.Class23)this.object_0).vmethod_45();
			}

			// Token: 0x06000122 RID: 290 RVA: 0x0000816C File Offset: 0x0000636C
			public override Class11.Class25 vmethod_46()
			{
				return ((Class11.Class23)this.object_0).vmethod_46();
			}

			// Token: 0x06000123 RID: 291 RVA: 0x00008190 File Offset: 0x00006390
			public override Class11.Class27 vmethod_47()
			{
				return ((Class11.Class23)this.object_0).vmethod_47();
			}

			// Token: 0x06000124 RID: 292 RVA: 0x000081B4 File Offset: 0x000063B4
			public override Class11.Class27 vmethod_48()
			{
				return ((Class11.Class23)this.object_0).vmethod_48();
			}

			// Token: 0x06000125 RID: 293 RVA: 0x000081D8 File Offset: 0x000063D8
			public override Class11.Class27 vmethod_49()
			{
				return ((Class11.Class23)this.object_0).vmethod_49();
			}

			// Token: 0x06000126 RID: 294 RVA: 0x00004C08 File Offset: 0x00002E08
			public override Class11.Class26 vmethod_50()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_26().struct2_0.long_0);
				}
				else
				{
					result = new Class11.Class26((long)this.vmethod_25().struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x06000127 RID: 295 RVA: 0x00004C58 File Offset: 0x00002E58
			public override Class11.Class26 vmethod_51()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_30().struct2_0.ulong_0);
				}
				else
				{
					result = new Class11.Class26((ulong)this.vmethod_29().struct1_0.uint_0);
				}
				return result;
			}

			// Token: 0x06000128 RID: 296 RVA: 0x00004CA8 File Offset: 0x00002EA8
			public override Class11.Class26 vmethod_52()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_37().struct2_0.long_0);
				}
				else
				{
					result = new Class11.Class26((long)this.vmethod_35().struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x06000129 RID: 297 RVA: 0x00004CF8 File Offset: 0x00002EF8
			public override Class11.Class26 vmethod_53()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_45().struct2_0.ulong_0);
				}
				else
				{
					result = new Class11.Class26((ulong)this.vmethod_43().struct1_0.uint_0);
				}
				return result;
			}

			// Token: 0x0600012A RID: 298 RVA: 0x00004D48 File Offset: 0x00002F48
			public override Class11.Class26 vmethod_54()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_38().struct2_0.long_0);
				}
				else
				{
					result = new Class11.Class26((long)this.vmethod_36().struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x0600012B RID: 299 RVA: 0x00004D98 File Offset: 0x00002F98
			public override Class11.Class26 vmethod_55()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_46().struct2_0.ulong_0);
				}
				else
				{
					result = new Class11.Class26((ulong)this.vmethod_44().struct1_0.uint_0);
				}
				return result;
			}

			// Token: 0x0600012C RID: 300 RVA: 0x000081FC File Offset: 0x000063FC
			public override Class11.Class22 vmethod_56()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class22 result;
				if (flag)
				{
					result = new Class11.Class26(-((Class11.Class25)this.object_0).struct2_0.long_0);
				}
				else
				{
					result = new Class11.Class26((long)(-(long)((Class11.Class24)this.object_0).struct1_0.int_0));
				}
				return result;
			}

			// Token: 0x0600012D RID: 301 RVA: 0x00008258 File Offset: 0x00006458
			public override Class11.Class22 vmethod_57(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 + ((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 + ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0));
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 + ((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 + ((Class11.Class24)class22_0).struct1_0.int_0));
					}
				}
				return result;
			}

			// Token: 0x0600012E RID: 302 RVA: 0x00008378 File Offset: 0x00006578
			public override Class11.Class22 vmethod_58(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = new Class11.Class26(checked(this.vmethod_21().struct2_0.long_0 + ((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0));
					}
					else
					{
						result = new Class11.Class26((long)(checked(this.vmethod_19().struct1_0.int_0 + ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0)));
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(checked(this.vmethod_21().struct2_0.long_0 + ((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0));
					}
					else
					{
						result = new Class11.Class26((long)(checked(this.vmethod_19().struct1_0.int_0 + ((Class11.Class24)class22_0).struct1_0.int_0)));
					}
				}
				return result;
			}

			// Token: 0x0600012F RID: 303 RVA: 0x00008498 File Offset: 0x00006698
			public override Class11.Class22 vmethod_59(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = IntPtr.Size == 8;
					if (flag3)
					{
						result = new Class11.Class26(checked(this.vmethod_21().struct2_0.ulong_0 + unchecked((ulong)((Class11.Class24)class22_0).struct1_0.uint_0)));
					}
					else
					{
						result = new Class11.Class26((long)((ulong)(checked(this.vmethod_19().struct1_0.uint_0 + ((Class11.Class24)class22_0).struct1_0.uint_0))));
					}
				}
				else
				{
					bool flag4 = class22_0.method_2();
					if (!flag4)
					{
						throw new Class11.Exception1();
					}
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(checked(this.vmethod_21().struct2_0.ulong_0 + ((Class11.Class26)class22_0).vmethod_21().struct2_0.ulong_0));
					}
					else
					{
						result = new Class11.Class26((ulong)(checked(this.vmethod_19().struct1_0.uint_0 + ((Class11.Class26)class22_0).vmethod_19().struct1_0.uint_0)));
					}
				}
				return result;
			}

			// Token: 0x06000130 RID: 304 RVA: 0x000085B0 File Offset: 0x000067B0
			public override Class11.Class22 vmethod_60(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 - ((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 - ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0));
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 - ((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 - ((Class11.Class24)class22_0).struct1_0.int_0));
					}
				}
				return result;
			}

			// Token: 0x06000131 RID: 305 RVA: 0x000086D0 File Offset: 0x000068D0
			public Class11.Class22 method_8(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = new Class11.Class26(((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0 - this.vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0 - this.vmethod_19().struct1_0.int_0));
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0 - this.vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(((Class11.Class24)class22_0).struct1_0.int_0 - this.vmethod_19().struct1_0.int_0));
					}
				}
				return result;
			}

			// Token: 0x06000132 RID: 306 RVA: 0x000087F4 File Offset: 0x000069F4
			public override Class11.Class22 vmethod_61(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = new Class11.Class26(checked(this.vmethod_21().struct2_0.long_0 - ((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0));
					}
					else
					{
						result = new Class11.Class26((long)(checked(this.vmethod_19().struct1_0.int_0 - ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0)));
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(checked(this.vmethod_21().struct2_0.long_0 - ((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0));
					}
					else
					{
						result = new Class11.Class26((long)(checked(this.vmethod_19().struct1_0.int_0 - ((Class11.Class24)class22_0).struct1_0.int_0)));
					}
				}
				return result;
			}

			// Token: 0x06000133 RID: 307 RVA: 0x00008914 File Offset: 0x00006B14
			public Class11.Class22 method_9(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = IntPtr.Size == 8;
					if (flag3)
					{
						result = new Class11.Class26(checked(((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0 - this.vmethod_21().struct2_0.long_0));
					}
					else
					{
						result = new Class11.Class26((long)(checked(((Class11.Class24)class22_0).struct1_0.int_0 - this.vmethod_19().struct1_0.int_0)));
					}
				}
				else
				{
					bool flag4 = class22_0.method_2();
					if (!flag4)
					{
						throw new Class11.Exception1();
					}
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(checked(((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0 - this.vmethod_21().struct2_0.long_0));
					}
					else
					{
						result = new Class11.Class26((long)(checked(((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0 - this.vmethod_19().struct1_0.int_0)));
					}
				}
				return result;
			}

			// Token: 0x06000134 RID: 308 RVA: 0x00008A2C File Offset: 0x00006C2C
			public override Class11.Class22 vmethod_62(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = new Class11.Class26(checked(this.vmethod_21().struct2_0.ulong_0 - ((Class11.Class26)class22_0).vmethod_21().struct2_0.ulong_0));
					}
					else
					{
						result = new Class11.Class26((ulong)(checked(this.vmethod_19().struct1_0.uint_0 - ((Class11.Class26)class22_0).vmethod_19().struct1_0.uint_0)));
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(checked(this.vmethod_21().struct2_0.ulong_0 - unchecked((ulong)((Class11.Class24)class22_0).struct1_0.uint_0)));
					}
					else
					{
						result = new Class11.Class26((long)((ulong)(checked(this.vmethod_19().struct1_0.uint_0 - ((Class11.Class24)class22_0).struct1_0.uint_0))));
					}
				}
				return result;
			}

			// Token: 0x06000135 RID: 309 RVA: 0x00008B48 File Offset: 0x00006D48
			public Class11.Class22 method_10(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = new Class11.Class26(checked(((Class11.Class26)class22_0).vmethod_21().struct2_0.ulong_0 - this.vmethod_21().struct2_0.ulong_0));
					}
					else
					{
						result = new Class11.Class26((ulong)(checked(((Class11.Class26)class22_0).vmethod_19().struct1_0.uint_0 - this.vmethod_19().struct1_0.uint_0)));
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(checked(unchecked((ulong)((Class11.Class24)class22_0).struct1_0.uint_0) - this.vmethod_21().struct2_0.ulong_0));
					}
					else
					{
						result = new Class11.Class26((long)((ulong)(checked(((Class11.Class24)class22_0).struct1_0.uint_0 - this.vmethod_19().struct1_0.uint_0))));
					}
				}
				return result;
			}

			// Token: 0x06000136 RID: 310 RVA: 0x00008C68 File Offset: 0x00006E68
			public override Class11.Class22 vmethod_63(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 * ((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 * ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0));
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 * ((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 * ((Class11.Class24)class22_0).struct1_0.int_0));
					}
				}
				return result;
			}

			// Token: 0x06000137 RID: 311 RVA: 0x00008D88 File Offset: 0x00006F88
			public override Class11.Class22 vmethod_64(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = new Class11.Class26(checked(this.vmethod_21().struct2_0.long_0 * ((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0));
					}
					else
					{
						result = new Class11.Class26((long)(checked(this.vmethod_19().struct1_0.int_0 * ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0)));
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(checked(this.vmethod_21().struct2_0.long_0 * ((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0));
					}
					else
					{
						result = new Class11.Class26((long)(checked(this.vmethod_19().struct1_0.int_0 * ((Class11.Class24)class22_0).struct1_0.int_0)));
					}
				}
				return result;
			}

			// Token: 0x06000138 RID: 312 RVA: 0x00008EAC File Offset: 0x000070AC
			public override Class11.Class22 vmethod_65(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = IntPtr.Size == 8;
					if (flag3)
					{
						result = new Class11.Class26(checked(this.vmethod_21().struct2_0.ulong_0 * unchecked((ulong)((Class11.Class24)class22_0).struct1_0.uint_0)));
					}
					else
					{
						result = new Class11.Class26((long)((ulong)(checked(this.vmethod_19().struct1_0.uint_0 * ((Class11.Class24)class22_0).struct1_0.uint_0))));
					}
				}
				else
				{
					bool flag4 = !class22_0.method_2();
					if (flag4)
					{
						throw new Class11.Exception1();
					}
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(checked(this.vmethod_21().struct2_0.ulong_0 * ((Class11.Class26)class22_0).vmethod_21().struct2_0.ulong_0));
					}
					else
					{
						result = new Class11.Class26((ulong)(checked(this.vmethod_19().struct1_0.uint_0 * ((Class11.Class26)class22_0).vmethod_19().struct1_0.uint_0)));
					}
				}
				return result;
			}

			// Token: 0x06000139 RID: 313 RVA: 0x00008FC8 File Offset: 0x000071C8
			public override Class11.Class22 vmethod_66(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = IntPtr.Size == 8;
					if (flag3)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 / ((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 / ((Class11.Class24)class22_0).struct1_0.int_0));
					}
				}
				else
				{
					bool flag4 = class22_0.method_2();
					if (!flag4)
					{
						throw new Class11.Exception1();
					}
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 / ((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 / ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0));
					}
				}
				return result;
			}

			// Token: 0x0600013A RID: 314 RVA: 0x000090E0 File Offset: 0x000072E0
			public Class11.Class22 method_11(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = new Class11.Class26(((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0 / this.vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0 / this.vmethod_19().struct1_0.int_0));
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0 / this.vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(((Class11.Class24)class22_0).struct1_0.int_0 / this.vmethod_19().struct1_0.int_0));
					}
				}
				return result;
			}

			// Token: 0x0600013B RID: 315 RVA: 0x00009204 File Offset: 0x00007404
			public override Class11.Class22 vmethod_67(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = IntPtr.Size == 8;
					if (flag3)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.ulong_0 / ((Class11.Class24)class22_0).vmethod_21().struct2_0.ulong_0);
					}
					else
					{
						result = new Class11.Class26((long)((ulong)(this.vmethod_19().struct1_0.uint_0 / ((Class11.Class24)class22_0).struct1_0.uint_0)));
					}
				}
				else
				{
					bool flag4 = class22_0.method_2();
					if (!flag4)
					{
						throw new Class11.Exception1();
					}
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.ulong_0 / ((Class11.Class26)class22_0).vmethod_21().struct2_0.ulong_0);
					}
					else
					{
						result = new Class11.Class26((ulong)(this.vmethod_19().struct1_0.uint_0 / ((Class11.Class26)class22_0).vmethod_19().struct1_0.uint_0));
					}
				}
				return result;
			}

			// Token: 0x0600013C RID: 316 RVA: 0x0000931C File Offset: 0x0000751C
			public Class11.Class22 method_12(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = new Class11.Class26(((Class11.Class26)class22_0).vmethod_21().struct2_0.ulong_0 / this.vmethod_21().struct2_0.ulong_0);
					}
					else
					{
						result = new Class11.Class26((ulong)(((Class11.Class26)class22_0).vmethod_19().struct1_0.uint_0 / this.vmethod_19().struct1_0.uint_0));
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(((Class11.Class24)class22_0).vmethod_21().struct2_0.ulong_0 / this.vmethod_21().struct2_0.ulong_0);
					}
					else
					{
						result = new Class11.Class26((long)((ulong)(((Class11.Class24)class22_0).struct1_0.uint_0 / this.vmethod_19().struct1_0.uint_0)));
					}
				}
				return result;
			}

			// Token: 0x0600013D RID: 317 RVA: 0x00009440 File Offset: 0x00007640
			public override Class11.Class22 vmethod_68(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = IntPtr.Size == 8;
					if (flag3)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 % ((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 % ((Class11.Class24)class22_0).struct1_0.int_0));
					}
				}
				else
				{
					bool flag4 = class22_0.method_2();
					if (!flag4)
					{
						throw new Class11.Exception1();
					}
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 % ((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 % ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0));
					}
				}
				return result;
			}

			// Token: 0x0600013E RID: 318 RVA: 0x00009558 File Offset: 0x00007758
			public Class11.Class22 method_13(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = new Class11.Class26(((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0 % this.vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0 % this.vmethod_19().struct1_0.int_0));
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0 % this.vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(((Class11.Class24)class22_0).struct1_0.int_0 % this.vmethod_19().struct1_0.int_0));
					}
				}
				return result;
			}

			// Token: 0x0600013F RID: 319 RVA: 0x00009678 File Offset: 0x00007878
			public override Class11.Class22 vmethod_69(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.ulong_0 % ((Class11.Class26)class22_0).vmethod_21().struct2_0.ulong_0);
					}
					else
					{
						result = new Class11.Class26((ulong)(this.vmethod_19().struct1_0.uint_0 % ((Class11.Class26)class22_0).vmethod_19().struct1_0.uint_0));
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.ulong_0 % ((Class11.Class24)class22_0).vmethod_21().struct2_0.ulong_0);
					}
					else
					{
						result = new Class11.Class26((long)((ulong)(this.vmethod_19().struct1_0.uint_0 % ((Class11.Class24)class22_0).struct1_0.uint_0)));
					}
				}
				return result;
			}

			// Token: 0x06000140 RID: 320 RVA: 0x00009798 File Offset: 0x00007998
			public Class11.Class22 method_14(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = IntPtr.Size == 8;
					if (flag3)
					{
						result = new Class11.Class26(((Class11.Class24)class22_0).vmethod_21().struct2_0.ulong_0 % this.vmethod_21().struct2_0.ulong_0);
					}
					else
					{
						result = new Class11.Class26((long)((ulong)(((Class11.Class24)class22_0).struct1_0.uint_0 % this.vmethod_19().struct1_0.uint_0)));
					}
				}
				else
				{
					bool flag4 = class22_0.method_2();
					if (!flag4)
					{
						throw new Class11.Exception1();
					}
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(((Class11.Class26)class22_0).vmethod_21().struct2_0.ulong_0 % this.vmethod_21().struct2_0.ulong_0);
					}
					else
					{
						result = new Class11.Class26((ulong)(((Class11.Class26)class22_0).vmethod_19().struct1_0.uint_0 % this.vmethod_19().struct1_0.uint_0));
					}
				}
				return result;
			}

			// Token: 0x06000141 RID: 321 RVA: 0x000098B0 File Offset: 0x00007AB0
			public override Class11.Class22 vmethod_70(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = IntPtr.Size == 8;
					if (flag3)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 & ((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 & ((Class11.Class24)class22_0).struct1_0.int_0));
					}
				}
				else
				{
					bool flag4 = class22_0.method_2();
					if (!flag4)
					{
						throw new Class11.Exception1();
					}
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 & ((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 & ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0));
					}
				}
				return result;
			}

			// Token: 0x06000142 RID: 322 RVA: 0x000099C8 File Offset: 0x00007BC8
			public override Class11.Class22 vmethod_71(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = IntPtr.Size == 8;
					if (flag3)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 | ((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 | ((Class11.Class24)class22_0).struct1_0.int_0));
					}
				}
				else
				{
					bool flag4 = class22_0.method_2();
					if (!flag4)
					{
						throw new Class11.Exception1();
					}
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 | ((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 | ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0));
					}
				}
				return result;
			}

			// Token: 0x06000143 RID: 323 RVA: 0x00009AE0 File Offset: 0x00007CE0
			public override Class11.Class22 vmethod_72()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class22 result;
				if (flag)
				{
					result = new Class11.Class26(~this.vmethod_21().struct2_0.long_0);
				}
				else
				{
					result = new Class11.Class26((long)(~(long)this.vmethod_19().struct1_0.int_0));
				}
				return result;
			}

			// Token: 0x06000144 RID: 324 RVA: 0x00009B30 File Offset: 0x00007D30
			public override Class11.Class22 vmethod_73(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = IntPtr.Size == 8;
					if (flag3)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 ^ ((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 ^ ((Class11.Class24)class22_0).struct1_0.int_0));
					}
				}
				else
				{
					bool flag4 = class22_0.method_2();
					if (!flag4)
					{
						throw new Class11.Exception1();
					}
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 ^ ((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 ^ ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0));
					}
				}
				return result;
			}

			// Token: 0x06000145 RID: 325 RVA: 0x00009C48 File Offset: 0x00007E48
			public override Class11.Class22 vmethod_75(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 << ((Class11.Class26)class22_0).vmethod_21().struct2_0.int_0);
					}
					else
					{
						result = new Class11.Class26((long)((long)this.vmethod_19().struct1_0.int_0 << ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0));
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 << ((Class11.Class24)class22_0).struct1_0.int_0);
					}
					else
					{
						result = new Class11.Class26((long)((long)this.vmethod_19().struct1_0.int_0 << ((Class11.Class24)class22_0).struct1_0.int_0));
					}
				}
				return result;
			}

			// Token: 0x06000146 RID: 326 RVA: 0x00009D70 File Offset: 0x00007F70
			public override Class11.Class22 vmethod_76(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = IntPtr.Size == 8;
					if (flag3)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 >> ((Class11.Class24)class22_0).struct1_0.int_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 >> ((Class11.Class24)class22_0).struct1_0.int_0));
					}
				}
				else
				{
					bool flag4 = !class22_0.method_2();
					if (flag4)
					{
						throw new Class11.Exception1();
					}
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.long_0 >> ((Class11.Class26)class22_0).vmethod_21().struct2_0.int_0);
					}
					else
					{
						result = new Class11.Class26((long)(this.vmethod_19().struct1_0.int_0 >> ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0));
					}
				}
				return result;
			}

			// Token: 0x06000147 RID: 327 RVA: 0x00009E94 File Offset: 0x00008094
			public override Class11.Class22 vmethod_77(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.ulong_0 >> ((Class11.Class26)class22_0).vmethod_21().struct2_0.int_0);
					}
					else
					{
						result = new Class11.Class26((long)((ulong)(this.vmethod_19().struct1_0.uint_0 >> ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0)));
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = new Class11.Class26(this.vmethod_21().struct2_0.ulong_0 >> ((Class11.Class24)class22_0).struct1_0.int_0);
					}
					else
					{
						result = new Class11.Class26((long)((ulong)(this.vmethod_19().struct1_0.uint_0 >> ((Class11.Class24)class22_0).struct1_0.int_0)));
					}
				}
				return result;
			}

			// Token: 0x06000148 RID: 328 RVA: 0x00009FBC File Offset: 0x000081BC
			public Class11.Class22 method_15(Class11.Class24 class24_0)
			{
				return new Class11.Class26((long)((ulong)(class24_0.struct1_0.uint_0 >> this.vmethod_19().struct1_0.int_0)));
			}

			// Token: 0x06000149 RID: 329 RVA: 0x00009FF4 File Offset: 0x000081F4
			public Class11.Class22 method_16(Class11.Class24 class24_0)
			{
				return new Class11.Class26((long)(class24_0.struct1_0.int_0 >> this.vmethod_21().struct2_0.int_0));
			}

			// Token: 0x0600014A RID: 330 RVA: 0x0000A02C File Offset: 0x0000822C
			public Class11.Class22 method_17(Class11.Class24 class24_0)
			{
				return new Class11.Class26((long)((long)class24_0.struct1_0.int_0 << this.vmethod_21().struct2_0.int_0));
			}

			// Token: 0x0600014B RID: 331 RVA: 0x0000A064 File Offset: 0x00008264
			public override string ToString()
			{
				return this.object_0.ToString();
			}

			// Token: 0x0600014C RID: 332 RVA: 0x000057CC File Offset: 0x000039CC
			internal override Class11.Class22 vmethod_8()
			{
				return this;
			}

			// Token: 0x0600014D RID: 333 RVA: 0x000057E0 File Offset: 0x000039E0
			internal override bool vmethod_9()
			{
				return true;
			}

			// Token: 0x0600014E RID: 334 RVA: 0x0000A084 File Offset: 0x00008284
			internal override bool vmethod_5(Class11.Class22 class22_0)
			{
				bool flag = class22_0.method_0();
				bool result;
				if (flag)
				{
					result = false;
				}
				else
				{
					bool flag2 = !class22_0.vmethod_0();
					if (flag2)
					{
						Class11.Class22 @class = class22_0.vmethod_8();
						bool flag3 = !@class.vmethod_9();
						if (flag3)
						{
							result = false;
						}
						else
						{
							bool flag4 = @class.method_1();
							if (flag4)
							{
								bool flag5 = IntPtr.Size == 8;
								if (flag5)
								{
									result = (this.vmethod_21().struct2_0.long_0 == ((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0);
								}
								else
								{
									result = (this.vmethod_19().struct1_0.int_0 == ((Class11.Class24)class22_0).struct1_0.int_0);
								}
							}
							else
							{
								bool flag6 = @class.method_2();
								if (flag6)
								{
									int size = IntPtr.Size;
									result = (this.vmethod_21().struct2_0.long_0 == ((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0);
								}
								else
								{
									result = false;
								}
							}
						}
					}
					else
					{
						result = ((Class11.Class28)class22_0).vmethod_5(this);
					}
				}
				return result;
			}

			// Token: 0x0600014F RID: 335 RVA: 0x0000A190 File Offset: 0x00008390
			internal override bool vmethod_6(Class11.Class22 class22_0)
			{
				bool flag = !class22_0.method_0();
				bool result;
				if (flag)
				{
					bool flag2 = class22_0.vmethod_0();
					if (flag2)
					{
						result = ((Class11.Class28)class22_0).vmethod_6(this);
					}
					else
					{
						Class11.Class22 @class = class22_0.vmethod_8();
						bool flag3 = !@class.vmethod_9();
						if (flag3)
						{
							result = false;
						}
						else
						{
							bool flag4 = @class.method_1();
							if (flag4)
							{
								bool flag5 = IntPtr.Size == 8;
								if (flag5)
								{
									result = (this.vmethod_21().struct2_0.ulong_0 != ((Class11.Class24)class22_0).vmethod_21().struct2_0.ulong_0);
								}
								else
								{
									result = (this.vmethod_19().struct1_0.uint_0 != ((Class11.Class24)class22_0).struct1_0.uint_0);
								}
							}
							else
							{
								bool flag6 = !@class.method_2();
								if (flag6)
								{
									result = false;
								}
								else
								{
									int size = IntPtr.Size;
									result = (this.vmethod_21().struct2_0.ulong_0 != ((Class11.Class26)class22_0).vmethod_21().struct2_0.ulong_0);
								}
							}
						}
					}
				}
				else
				{
					result = false;
				}
				return result;
			}

			// Token: 0x06000150 RID: 336 RVA: 0x0000A2A8 File Offset: 0x000084A8
			public override bool vmethod_78(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				bool result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = (this.vmethod_21().struct2_0.long_0 >= ((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = (this.vmethod_19().struct1_0.int_0 >= ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0);
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = (this.vmethod_21().struct2_0.long_0 >= ((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = (this.vmethod_19().struct1_0.int_0 >= ((Class11.Class24)class22_0).struct1_0.int_0);
					}
				}
				return result;
			}

			// Token: 0x06000151 RID: 337 RVA: 0x0000A3C0 File Offset: 0x000085C0
			public override bool vmethod_79(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				bool result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = (this.vmethod_21().struct2_0.ulong_0 >= ((Class11.Class26)class22_0).vmethod_21().struct2_0.ulong_0);
					}
					else
					{
						result = (this.vmethod_19().struct1_0.uint_0 >= ((Class11.Class26)class22_0).vmethod_19().struct1_0.uint_0);
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = (this.vmethod_21().struct2_0.ulong_0 >= ((Class11.Class24)class22_0).vmethod_21().struct2_0.ulong_0);
					}
					else
					{
						result = (this.vmethod_19().struct1_0.uint_0 >= ((Class11.Class24)class22_0).struct1_0.uint_0);
					}
				}
				return result;
			}

			// Token: 0x06000152 RID: 338 RVA: 0x0000A4D8 File Offset: 0x000086D8
			public override bool vmethod_80(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				bool result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = (this.vmethod_21().struct2_0.long_0 > ((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = (this.vmethod_19().struct1_0.int_0 > ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0);
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = (this.vmethod_21().struct2_0.long_0 > ((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = (this.vmethod_19().struct1_0.int_0 > ((Class11.Class24)class22_0).struct1_0.int_0);
					}
				}
				return result;
			}

			// Token: 0x06000153 RID: 339 RVA: 0x0000A5E4 File Offset: 0x000087E4
			public override bool vmethod_81(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				bool result;
				if (flag2)
				{
					bool flag3 = IntPtr.Size == 8;
					if (flag3)
					{
						result = (this.vmethod_21().struct2_0.ulong_0 > ((Class11.Class24)class22_0).vmethod_21().struct2_0.ulong_0);
					}
					else
					{
						result = (this.vmethod_19().struct1_0.uint_0 > ((Class11.Class24)class22_0).struct1_0.uint_0);
					}
				}
				else
				{
					bool flag4 = class22_0.method_2();
					if (!flag4)
					{
						throw new Class11.Exception1();
					}
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = (this.vmethod_21().struct2_0.ulong_0 > ((Class11.Class26)class22_0).vmethod_21().struct2_0.ulong_0);
					}
					else
					{
						result = (this.vmethod_19().struct1_0.uint_0 > ((Class11.Class26)class22_0).vmethod_19().struct1_0.uint_0);
					}
				}
				return result;
			}

			// Token: 0x06000154 RID: 340 RVA: 0x0000A6E8 File Offset: 0x000088E8
			public override bool vmethod_82(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				bool result;
				if (flag2)
				{
					bool flag3 = IntPtr.Size == 8;
					if (flag3)
					{
						result = (this.vmethod_21().struct2_0.long_0 <= ((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = (this.vmethod_19().struct1_0.int_0 <= ((Class11.Class24)class22_0).struct1_0.int_0);
					}
				}
				else
				{
					bool flag4 = !class22_0.method_2();
					if (flag4)
					{
						throw new Class11.Exception1();
					}
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = (this.vmethod_21().struct2_0.long_0 <= ((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = (this.vmethod_19().struct1_0.int_0 <= ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0);
					}
				}
				return result;
			}

			// Token: 0x06000155 RID: 341 RVA: 0x0000A7FC File Offset: 0x000089FC
			public override bool vmethod_83(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				bool result;
				if (flag2)
				{
					bool flag3 = !class22_0.method_2();
					if (flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = (this.vmethod_21().struct2_0.ulong_0 <= ((Class11.Class26)class22_0).vmethod_21().struct2_0.ulong_0);
					}
					else
					{
						result = (this.vmethod_19().struct1_0.uint_0 <= ((Class11.Class26)class22_0).vmethod_19().struct1_0.uint_0);
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = (this.vmethod_21().struct2_0.ulong_0 <= ((Class11.Class24)class22_0).vmethod_21().struct2_0.ulong_0);
					}
					else
					{
						result = (this.vmethod_19().struct1_0.uint_0 <= ((Class11.Class24)class22_0).struct1_0.uint_0);
					}
				}
				return result;
			}

			// Token: 0x06000156 RID: 342 RVA: 0x0000A918 File Offset: 0x00008B18
			public override bool vmethod_84(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = class22_0.method_1();
				bool result;
				if (flag2)
				{
					bool flag3 = IntPtr.Size == 8;
					if (flag3)
					{
						result = (this.vmethod_21().struct2_0.long_0 < ((Class11.Class24)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = (this.vmethod_19().struct1_0.int_0 < ((Class11.Class24)class22_0).struct1_0.int_0);
					}
				}
				else
				{
					bool flag4 = class22_0.method_2();
					if (!flag4)
					{
						throw new Class11.Exception1();
					}
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = (this.vmethod_21().struct2_0.long_0 < ((Class11.Class26)class22_0).vmethod_21().struct2_0.long_0);
					}
					else
					{
						result = (this.vmethod_19().struct1_0.int_0 < ((Class11.Class26)class22_0).vmethod_19().struct1_0.int_0);
					}
				}
				return result;
			}

			// Token: 0x06000157 RID: 343 RVA: 0x0000AA1C File Offset: 0x00008C1C
			public override bool vmethod_85(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_1();
				bool result;
				if (flag2)
				{
					bool flag3 = class22_0.method_2();
					if (!flag3)
					{
						throw new Class11.Exception1();
					}
					bool flag4 = IntPtr.Size == 8;
					if (flag4)
					{
						result = (this.vmethod_21().struct2_0.ulong_0 < ((Class11.Class26)class22_0).vmethod_21().struct2_0.ulong_0);
					}
					else
					{
						result = (this.vmethod_19().struct1_0.uint_0 < ((Class11.Class26)class22_0).vmethod_19().struct1_0.uint_0);
					}
				}
				else
				{
					bool flag5 = IntPtr.Size == 8;
					if (flag5)
					{
						result = (this.vmethod_21().struct2_0.ulong_0 < ((Class11.Class24)class22_0).vmethod_21().struct2_0.ulong_0);
					}
					else
					{
						result = (this.vmethod_19().struct1_0.uint_0 < ((Class11.Class24)class22_0).struct1_0.uint_0);
					}
				}
				return result;
			}

			// Token: 0x0400002B RID: 43
			public object object_0;

			// Token: 0x0400002C RID: 44
			public Class11.Enum1 enum1_0;
		}

		// Token: 0x0200001C RID: 28
		private abstract class Class23 : Class11.Class22
		{
			// Token: 0x06000158 RID: 344
			public abstract bool vmethod_11();

			// Token: 0x06000159 RID: 345
			public abstract bool vmethod_12();

			// Token: 0x0600015A RID: 346
			public abstract Class11.Class22 vmethod_13(Class11.Enum1 enum1_0);

			// Token: 0x0600015B RID: 347
			public abstract Class11.Class24 vmethod_14();

			// Token: 0x0600015C RID: 348
			public abstract Class11.Class24 vmethod_15();

			// Token: 0x0600015D RID: 349
			public abstract Class11.Class24 vmethod_16();

			// Token: 0x0600015E RID: 350
			public abstract Class11.Class24 vmethod_17();

			// Token: 0x0600015F RID: 351
			public abstract Class11.Class24 vmethod_18();

			// Token: 0x06000160 RID: 352
			public abstract Class11.Class24 vmethod_19();

			// Token: 0x06000161 RID: 353
			public abstract Class11.Class24 vmethod_20();

			// Token: 0x06000162 RID: 354
			public abstract Class11.Class25 vmethod_21();

			// Token: 0x06000163 RID: 355
			public abstract Class11.Class25 vmethod_22();

			// Token: 0x06000164 RID: 356
			public abstract Class11.Class24 vmethod_23();

			// Token: 0x06000165 RID: 357
			public abstract Class11.Class24 vmethod_24();

			// Token: 0x06000166 RID: 358
			public abstract Class11.Class24 vmethod_25();

			// Token: 0x06000167 RID: 359
			public abstract Class11.Class25 vmethod_26();

			// Token: 0x06000168 RID: 360
			public abstract Class11.Class24 vmethod_27();

			// Token: 0x06000169 RID: 361
			public abstract Class11.Class24 vmethod_28();

			// Token: 0x0600016A RID: 362
			public abstract Class11.Class24 vmethod_29();

			// Token: 0x0600016B RID: 363
			public abstract Class11.Class25 vmethod_30();

			// Token: 0x0600016C RID: 364
			public abstract Class11.Class24 vmethod_31();

			// Token: 0x0600016D RID: 365
			public abstract Class11.Class24 vmethod_32();

			// Token: 0x0600016E RID: 366
			public abstract Class11.Class24 vmethod_33();

			// Token: 0x0600016F RID: 367
			public abstract Class11.Class24 vmethod_34();

			// Token: 0x06000170 RID: 368
			public abstract Class11.Class24 vmethod_35();

			// Token: 0x06000171 RID: 369
			public abstract Class11.Class24 vmethod_36();

			// Token: 0x06000172 RID: 370
			public abstract Class11.Class25 vmethod_37();

			// Token: 0x06000173 RID: 371
			public abstract Class11.Class25 vmethod_38();

			// Token: 0x06000174 RID: 372
			public abstract Class11.Class24 vmethod_39();

			// Token: 0x06000175 RID: 373
			public abstract Class11.Class24 vmethod_40();

			// Token: 0x06000176 RID: 374
			public abstract Class11.Class24 vmethod_41();

			// Token: 0x06000177 RID: 375
			public abstract Class11.Class24 vmethod_42();

			// Token: 0x06000178 RID: 376
			public abstract Class11.Class24 vmethod_43();

			// Token: 0x06000179 RID: 377
			public abstract Class11.Class24 vmethod_44();

			// Token: 0x0600017A RID: 378
			public abstract Class11.Class25 vmethod_45();

			// Token: 0x0600017B RID: 379
			public abstract Class11.Class25 vmethod_46();

			// Token: 0x0600017C RID: 380
			public abstract Class11.Class27 vmethod_47();

			// Token: 0x0600017D RID: 381
			public abstract Class11.Class27 vmethod_48();

			// Token: 0x0600017E RID: 382
			public abstract Class11.Class27 vmethod_49();

			// Token: 0x0600017F RID: 383
			public abstract Class11.Class26 vmethod_50();

			// Token: 0x06000180 RID: 384
			public abstract Class11.Class26 vmethod_51();

			// Token: 0x06000181 RID: 385
			public abstract Class11.Class26 vmethod_52();

			// Token: 0x06000182 RID: 386
			public abstract Class11.Class26 vmethod_53();

			// Token: 0x06000183 RID: 387
			public abstract Class11.Class26 vmethod_54();

			// Token: 0x06000184 RID: 388
			public abstract Class11.Class26 vmethod_55();

			// Token: 0x06000185 RID: 389
			public abstract Class11.Class22 vmethod_56();

			// Token: 0x06000186 RID: 390
			public abstract Class11.Class22 vmethod_57(Class11.Class22 class22_0);

			// Token: 0x06000187 RID: 391
			public abstract Class11.Class22 vmethod_58(Class11.Class22 class22_0);

			// Token: 0x06000188 RID: 392
			public abstract Class11.Class22 vmethod_59(Class11.Class22 class22_0);

			// Token: 0x06000189 RID: 393
			public abstract Class11.Class22 vmethod_60(Class11.Class22 class22_0);

			// Token: 0x0600018A RID: 394
			public abstract Class11.Class22 vmethod_61(Class11.Class22 class22_0);

			// Token: 0x0600018B RID: 395
			public abstract Class11.Class22 vmethod_62(Class11.Class22 class22_0);

			// Token: 0x0600018C RID: 396
			public abstract Class11.Class22 vmethod_63(Class11.Class22 class22_0);

			// Token: 0x0600018D RID: 397
			public abstract Class11.Class22 vmethod_64(Class11.Class22 class22_0);

			// Token: 0x0600018E RID: 398
			public abstract Class11.Class22 vmethod_65(Class11.Class22 class22_0);

			// Token: 0x0600018F RID: 399
			public abstract Class11.Class22 vmethod_66(Class11.Class22 class22_0);

			// Token: 0x06000190 RID: 400
			public abstract Class11.Class22 vmethod_67(Class11.Class22 class22_0);

			// Token: 0x06000191 RID: 401
			public abstract Class11.Class22 vmethod_68(Class11.Class22 class22_0);

			// Token: 0x06000192 RID: 402
			public abstract Class11.Class22 vmethod_69(Class11.Class22 class22_0);

			// Token: 0x06000193 RID: 403
			public abstract Class11.Class22 vmethod_70(Class11.Class22 class22_0);

			// Token: 0x06000194 RID: 404
			public abstract Class11.Class22 vmethod_71(Class11.Class22 class22_0);

			// Token: 0x06000195 RID: 405
			public abstract Class11.Class22 vmethod_72();

			// Token: 0x06000196 RID: 406
			public abstract Class11.Class22 vmethod_73(Class11.Class22 class22_0);

			// Token: 0x06000197 RID: 407
			public abstract Class11.Class23 vmethod_74();

			// Token: 0x06000198 RID: 408
			public abstract Class11.Class22 vmethod_75(Class11.Class22 class22_0);

			// Token: 0x06000199 RID: 409
			public abstract Class11.Class22 vmethod_76(Class11.Class22 class22_0);

			// Token: 0x0600019A RID: 410
			public abstract Class11.Class22 vmethod_77(Class11.Class22 class22_0);

			// Token: 0x0600019B RID: 411
			public abstract bool vmethod_78(Class11.Class22 class22_0);

			// Token: 0x0600019C RID: 412
			public abstract bool vmethod_79(Class11.Class22 class22_0);

			// Token: 0x0600019D RID: 413
			public abstract bool vmethod_80(Class11.Class22 class22_0);

			// Token: 0x0600019E RID: 414
			public abstract bool vmethod_81(Class11.Class22 class22_0);

			// Token: 0x0600019F RID: 415
			public abstract bool vmethod_82(Class11.Class22 class22_0);

			// Token: 0x060001A0 RID: 416
			public abstract bool vmethod_83(Class11.Class22 class22_0);

			// Token: 0x060001A1 RID: 417
			public abstract bool vmethod_84(Class11.Class22 class22_0);

			// Token: 0x060001A2 RID: 418
			public abstract bool vmethod_85(Class11.Class22 class22_0);

			// Token: 0x060001A3 RID: 419 RVA: 0x000057E0 File Offset: 0x000039E0
			internal override bool vmethod_3()
			{
				return true;
			}
		}

		// Token: 0x0200001D RID: 29
		private class Class27 : Class11.Class23
		{
			// Token: 0x060001A5 RID: 421 RVA: 0x000024EE File Offset: 0x000006EE
			internal override void vmethod_10(Class11.Class22 class22_0)
			{
				this.double_0 = ((Class11.Class27)class22_0).double_0;
				this.enum1_0 = ((Class11.Class27)class22_0).enum1_0;
			}

			// Token: 0x060001A6 RID: 422 RVA: 0x00002325 File Offset: 0x00000525
			internal override void vmethod_2(Class11.Class22 class22_0)
			{
				this.vmethod_10(class22_0);
			}

			// Token: 0x060001A7 RID: 423 RVA: 0x00002513 File Offset: 0x00000713
			public Class27(double double_1)
			{
				this.enum4_0 = (Class11.Enum4)5;
				this.enum1_0 = (Class11.Enum1)10;
				this.double_0 = double_1;
			}

			// Token: 0x060001A8 RID: 424 RVA: 0x00002533 File Offset: 0x00000733
			public Class27(Class11.Class27 class27_0)
			{
				this.enum4_0 = class27_0.enum4_0;
				this.enum1_0 = class27_0.enum1_0;
				this.double_0 = class27_0.double_0;
			}

			// Token: 0x060001A9 RID: 425 RVA: 0x0000AB28 File Offset: 0x00008D28
			public override Class11.Class23 vmethod_74()
			{
				return new Class11.Class27(this);
			}

			// Token: 0x060001AA RID: 426 RVA: 0x00002561 File Offset: 0x00000761
			public Class27(double double_1, Class11.Enum1 enum1_1)
			{
				this.enum4_0 = (Class11.Enum4)5;
				this.double_0 = double_1;
				this.enum1_0 = enum1_1;
			}

			// Token: 0x060001AB RID: 427 RVA: 0x00002580 File Offset: 0x00000780
			public Class27(float float_0)
			{
				this.enum4_0 = (Class11.Enum4)5;
				this.double_0 = (double)float_0;
				this.enum1_0 = (Class11.Enum1)9;
			}

			// Token: 0x060001AC RID: 428 RVA: 0x000025A1 File Offset: 0x000007A1
			public Class27(float float_0, Class11.Enum1 enum1_1)
			{
				this.enum4_0 = (Class11.Enum4)5;
				this.double_0 = (double)float_0;
				this.enum1_0 = enum1_1;
			}

			// Token: 0x060001AD RID: 429 RVA: 0x0000AB40 File Offset: 0x00008D40
			public override bool vmethod_11()
			{
				return this.double_0 == 0.0;
			}

			// Token: 0x060001AE RID: 430 RVA: 0x000040C8 File Offset: 0x000022C8
			public override bool vmethod_12()
			{
				return !this.vmethod_11();
			}

			// Token: 0x060001AF RID: 431 RVA: 0x0000AB64 File Offset: 0x00008D64
			public override string ToString()
			{
				return this.double_0.ToString();
			}

			// Token: 0x060001B0 RID: 432 RVA: 0x0000AB84 File Offset: 0x00008D84
			public override Class11.Class22 vmethod_13(Class11.Enum1 enum1_1)
			{
				if (!true)
				{
				}
				Class11.Class22 result;
				switch (enum1_1)
				{
				case (Class11.Enum1)1:
					result = this.vmethod_15();
					break;
				case (Class11.Enum1)2:
					result = this.vmethod_16();
					break;
				case (Class11.Enum1)3:
					result = this.vmethod_17();
					break;
				case (Class11.Enum1)4:
					result = this.vmethod_18();
					break;
				case (Class11.Enum1)5:
					result = this.vmethod_19();
					break;
				case (Class11.Enum1)6:
					result = this.vmethod_20();
					break;
				case (Class11.Enum1)7:
					result = this.vmethod_21();
					break;
				case (Class11.Enum1)8:
					result = this.vmethod_22();
					break;
				case (Class11.Enum1)9:
					result = this.vmethod_47();
					break;
				case (Class11.Enum1)10:
					result = this.vmethod_48();
					break;
				case (Class11.Enum1)11:
					result = this.vmethod_14();
					break;
				default:
					throw new Exception(((Class11.Enum5)4).ToString());
				}
				if (!true)
				{
				}
				return result;
			}

			// Token: 0x060001B1 RID: 433 RVA: 0x0000AC5C File Offset: 0x00008E5C
			internal override object vmethod_4(Type type_0)
			{
				bool flag = type_0 != null && type_0.IsByRef;
				if (flag)
				{
					type_0 = type_0.GetElementType();
				}
				bool flag2 = !(type_0 == typeof(float));
				object result;
				if (flag2)
				{
					bool flag3 = type_0 == typeof(double);
					if (flag3)
					{
						result = this.double_0;
					}
					else
					{
						bool flag4 = (type_0 == null || type_0 == typeof(object)) && this.enum1_0 == (Class11.Enum1)9;
						if (flag4)
						{
							result = (float)this.double_0;
						}
						else
						{
							result = this.double_0;
						}
					}
				}
				else
				{
					result = (float)this.double_0;
				}
				return result;
			}

			// Token: 0x060001B2 RID: 434 RVA: 0x0000AD24 File Offset: 0x00008F24
			public override Class11.Class24 vmethod_14()
			{
				return new Class11.Class24(this.vmethod_11() ? 1 : 0);
			}

			// Token: 0x060001B3 RID: 435 RVA: 0x000047D0 File Offset: 0x000029D0
			internal override bool vmethod_7()
			{
				return this.vmethod_12();
			}

			// Token: 0x060001B4 RID: 436 RVA: 0x0000AD48 File Offset: 0x00008F48
			public override Class11.Class24 vmethod_15()
			{
				return new Class11.Class24((int)((sbyte)this.double_0), (Class11.Enum1)1);
			}

			// Token: 0x060001B5 RID: 437 RVA: 0x0000AD68 File Offset: 0x00008F68
			public override Class11.Class24 vmethod_16()
			{
				return new Class11.Class24((uint)((byte)this.double_0), (Class11.Enum1)2);
			}

			// Token: 0x060001B6 RID: 438 RVA: 0x0000AD88 File Offset: 0x00008F88
			public override Class11.Class24 vmethod_17()
			{
				return new Class11.Class24((int)((short)this.double_0), (Class11.Enum1)3);
			}

			// Token: 0x060001B7 RID: 439 RVA: 0x0000ADA8 File Offset: 0x00008FA8
			public override Class11.Class24 vmethod_18()
			{
				return new Class11.Class24((uint)((ushort)this.double_0), (Class11.Enum1)4);
			}

			// Token: 0x060001B8 RID: 440 RVA: 0x0000ADC8 File Offset: 0x00008FC8
			public override Class11.Class24 vmethod_19()
			{
				return new Class11.Class24((int)this.double_0, (Class11.Enum1)5);
			}

			// Token: 0x060001B9 RID: 441 RVA: 0x0000ADE8 File Offset: 0x00008FE8
			public override Class11.Class24 vmethod_20()
			{
				return new Class11.Class24((uint)this.double_0, (Class11.Enum1)6);
			}

			// Token: 0x060001BA RID: 442 RVA: 0x0000AE08 File Offset: 0x00009008
			public override Class11.Class25 vmethod_21()
			{
				return new Class11.Class25((long)this.double_0, (Class11.Enum1)7);
			}

			// Token: 0x060001BB RID: 443 RVA: 0x0000AE28 File Offset: 0x00009028
			public override Class11.Class25 vmethod_22()
			{
				return new Class11.Class25((ulong)this.double_0, (Class11.Enum1)8);
			}

			// Token: 0x060001BC RID: 444 RVA: 0x0000492C File Offset: 0x00002B2C
			public override Class11.Class24 vmethod_23()
			{
				return this.vmethod_15();
			}

			// Token: 0x060001BD RID: 445 RVA: 0x00004944 File Offset: 0x00002B44
			public override Class11.Class24 vmethod_24()
			{
				return this.vmethod_17();
			}

			// Token: 0x060001BE RID: 446 RVA: 0x0000495C File Offset: 0x00002B5C
			public override Class11.Class24 vmethod_25()
			{
				return this.vmethod_19();
			}

			// Token: 0x060001BF RID: 447 RVA: 0x00004974 File Offset: 0x00002B74
			public override Class11.Class25 vmethod_26()
			{
				return this.vmethod_21();
			}

			// Token: 0x060001C0 RID: 448 RVA: 0x0000498C File Offset: 0x00002B8C
			public override Class11.Class24 vmethod_27()
			{
				return this.vmethod_16();
			}

			// Token: 0x060001C1 RID: 449 RVA: 0x000049A4 File Offset: 0x00002BA4
			public override Class11.Class24 vmethod_28()
			{
				return this.vmethod_18();
			}

			// Token: 0x060001C2 RID: 450 RVA: 0x000049BC File Offset: 0x00002BBC
			public override Class11.Class24 vmethod_29()
			{
				return this.vmethod_20();
			}

			// Token: 0x060001C3 RID: 451 RVA: 0x000049D4 File Offset: 0x00002BD4
			public override Class11.Class25 vmethod_30()
			{
				return this.vmethod_22();
			}

			// Token: 0x060001C4 RID: 452 RVA: 0x0000AE48 File Offset: 0x00009048
			public override Class11.Class24 vmethod_31()
			{
				return new Class11.Class24((int)(checked((sbyte)this.double_0)), (Class11.Enum1)1);
			}

			// Token: 0x060001C5 RID: 453 RVA: 0x0000AE48 File Offset: 0x00009048
			public override Class11.Class24 vmethod_32()
			{
				return new Class11.Class24((int)(checked((sbyte)this.double_0)), (Class11.Enum1)1);
			}

			// Token: 0x060001C6 RID: 454 RVA: 0x0000AE68 File Offset: 0x00009068
			public override Class11.Class24 vmethod_33()
			{
				return new Class11.Class24((int)(checked((short)this.double_0)), (Class11.Enum1)3);
			}

			// Token: 0x060001C7 RID: 455 RVA: 0x0000AE68 File Offset: 0x00009068
			public override Class11.Class24 vmethod_34()
			{
				return new Class11.Class24((int)(checked((short)this.double_0)), (Class11.Enum1)3);
			}

			// Token: 0x060001C8 RID: 456 RVA: 0x0000AE88 File Offset: 0x00009088
			public override Class11.Class24 vmethod_35()
			{
				return new Class11.Class24(checked((int)this.double_0), (Class11.Enum1)5);
			}

			// Token: 0x060001C9 RID: 457 RVA: 0x0000AE88 File Offset: 0x00009088
			public override Class11.Class24 vmethod_36()
			{
				return new Class11.Class24(checked((int)this.double_0), (Class11.Enum1)5);
			}

			// Token: 0x060001CA RID: 458 RVA: 0x0000AEA8 File Offset: 0x000090A8
			public override Class11.Class25 vmethod_37()
			{
				return new Class11.Class25(checked((long)this.double_0), (Class11.Enum1)7);
			}

			// Token: 0x060001CB RID: 459 RVA: 0x0000AEA8 File Offset: 0x000090A8
			public override Class11.Class25 vmethod_38()
			{
				return new Class11.Class25(checked((long)this.double_0), (Class11.Enum1)7);
			}

			// Token: 0x060001CC RID: 460 RVA: 0x0000AEC8 File Offset: 0x000090C8
			public override Class11.Class24 vmethod_39()
			{
				return new Class11.Class24((int)(checked((byte)this.double_0)), (Class11.Enum1)2);
			}

			// Token: 0x060001CD RID: 461 RVA: 0x0000AEC8 File Offset: 0x000090C8
			public override Class11.Class24 vmethod_40()
			{
				return new Class11.Class24((int)(checked((byte)this.double_0)), (Class11.Enum1)2);
			}

			// Token: 0x060001CE RID: 462 RVA: 0x0000AEE8 File Offset: 0x000090E8
			public override Class11.Class24 vmethod_41()
			{
				return new Class11.Class24((int)(checked((ushort)this.double_0)), (Class11.Enum1)4);
			}

			// Token: 0x060001CF RID: 463 RVA: 0x0000AEE8 File Offset: 0x000090E8
			public override Class11.Class24 vmethod_42()
			{
				return new Class11.Class24((int)(checked((ushort)this.double_0)), (Class11.Enum1)4);
			}

			// Token: 0x060001D0 RID: 464 RVA: 0x0000AF08 File Offset: 0x00009108
			public override Class11.Class24 vmethod_43()
			{
				return new Class11.Class24(checked((uint)this.double_0), (Class11.Enum1)6);
			}

			// Token: 0x060001D1 RID: 465 RVA: 0x0000AF08 File Offset: 0x00009108
			public override Class11.Class24 vmethod_44()
			{
				return new Class11.Class24(checked((uint)this.double_0), (Class11.Enum1)6);
			}

			// Token: 0x060001D2 RID: 466 RVA: 0x0000AF28 File Offset: 0x00009128
			public override Class11.Class25 vmethod_45()
			{
				return new Class11.Class25(checked((ulong)this.double_0), (Class11.Enum1)8);
			}

			// Token: 0x060001D3 RID: 467 RVA: 0x0000AF28 File Offset: 0x00009128
			public override Class11.Class25 vmethod_46()
			{
				return new Class11.Class25(checked((ulong)this.double_0), (Class11.Enum1)8);
			}

			// Token: 0x060001D4 RID: 468 RVA: 0x0000AF48 File Offset: 0x00009148
			public override Class11.Class27 vmethod_47()
			{
				return new Class11.Class27((float)this.double_0, (Class11.Enum1)9);
			}

			// Token: 0x060001D5 RID: 469 RVA: 0x0000AF68 File Offset: 0x00009168
			public override Class11.Class27 vmethod_48()
			{
				return new Class11.Class27(this.double_0, (Class11.Enum1)10);
			}

			// Token: 0x060001D6 RID: 470 RVA: 0x0000AF88 File Offset: 0x00009188
			public override Class11.Class27 vmethod_49()
			{
				return new Class11.Class27(this.double_0);
			}

			// Token: 0x060001D7 RID: 471 RVA: 0x00004C08 File Offset: 0x00002E08
			public override Class11.Class26 vmethod_50()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_26().struct2_0.long_0);
				}
				else
				{
					result = new Class11.Class26((long)this.vmethod_25().struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x060001D8 RID: 472 RVA: 0x00004C58 File Offset: 0x00002E58
			public override Class11.Class26 vmethod_51()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_30().struct2_0.ulong_0);
				}
				else
				{
					result = new Class11.Class26((ulong)this.vmethod_29().struct1_0.uint_0);
				}
				return result;
			}

			// Token: 0x060001D9 RID: 473 RVA: 0x00004CA8 File Offset: 0x00002EA8
			public override Class11.Class26 vmethod_52()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_37().struct2_0.long_0);
				}
				else
				{
					result = new Class11.Class26((long)this.vmethod_35().struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x060001DA RID: 474 RVA: 0x00004CF8 File Offset: 0x00002EF8
			public override Class11.Class26 vmethod_53()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_45().struct2_0.ulong_0);
				}
				else
				{
					result = new Class11.Class26((ulong)this.vmethod_43().struct1_0.uint_0);
				}
				return result;
			}

			// Token: 0x060001DB RID: 475 RVA: 0x00004D48 File Offset: 0x00002F48
			public override Class11.Class26 vmethod_54()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_38().struct2_0.long_0);
				}
				else
				{
					result = new Class11.Class26((long)this.vmethod_36().struct1_0.int_0);
				}
				return result;
			}

			// Token: 0x060001DC RID: 476 RVA: 0x00004D98 File Offset: 0x00002F98
			public override Class11.Class26 vmethod_55()
			{
				bool flag = IntPtr.Size == 8;
				Class11.Class26 result;
				if (flag)
				{
					result = new Class11.Class26(this.vmethod_46().struct2_0.ulong_0);
				}
				else
				{
					result = new Class11.Class26((ulong)this.vmethod_44().struct1_0.uint_0);
				}
				return result;
			}

			// Token: 0x060001DD RID: 477 RVA: 0x0000AFA8 File Offset: 0x000091A8
			public override Class11.Class22 vmethod_56()
			{
				bool flag = this.enum1_0 == (Class11.Enum1)9;
				Class11.Class22 result;
				if (flag)
				{
					result = new Class11.Class27((float)(0.0 - this.double_0));
				}
				else
				{
					result = new Class11.Class27(0.0 - this.double_0);
				}
				return result;
			}

			// Token: 0x060001DE RID: 478 RVA: 0x0000AFF8 File Offset: 0x000091F8
			public override Class11.Class22 vmethod_57(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class27(this.double_0 + ((Class11.Class27)class22_0).double_0);
			}

			// Token: 0x060001DF RID: 479 RVA: 0x0000AFF8 File Offset: 0x000091F8
			public override Class11.Class22 vmethod_58(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class27(this.double_0 + ((Class11.Class27)class22_0).double_0);
			}

			// Token: 0x060001E0 RID: 480 RVA: 0x0000AFF8 File Offset: 0x000091F8
			public override Class11.Class22 vmethod_59(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class27(this.double_0 + ((Class11.Class27)class22_0).double_0);
			}

			// Token: 0x060001E1 RID: 481 RVA: 0x0000B04C File Offset: 0x0000924C
			public override Class11.Class22 vmethod_60(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class27(this.double_0 - ((Class11.Class27)class22_0).double_0);
			}

			// Token: 0x060001E2 RID: 482 RVA: 0x0000B04C File Offset: 0x0000924C
			public override Class11.Class22 vmethod_61(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class27(this.double_0 - ((Class11.Class27)class22_0).double_0);
			}

			// Token: 0x060001E3 RID: 483 RVA: 0x0000B04C File Offset: 0x0000924C
			public override Class11.Class22 vmethod_62(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class27(this.double_0 - ((Class11.Class27)class22_0).double_0);
			}

			// Token: 0x060001E4 RID: 484 RVA: 0x0000B0A0 File Offset: 0x000092A0
			public override Class11.Class22 vmethod_63(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4() || !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class27(this.double_0 * ((Class11.Class27)class22_0).double_0);
			}

			// Token: 0x060001E5 RID: 485 RVA: 0x0000B0FC File Offset: 0x000092FC
			public override Class11.Class22 vmethod_64(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class27(this.double_0 * ((Class11.Class27)class22_0).double_0);
			}

			// Token: 0x060001E6 RID: 486 RVA: 0x0000B0FC File Offset: 0x000092FC
			public override Class11.Class22 vmethod_65(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class27(this.double_0 * ((Class11.Class27)class22_0).double_0);
			}

			// Token: 0x060001E7 RID: 487 RVA: 0x0000B150 File Offset: 0x00009350
			public override Class11.Class22 vmethod_66(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class27(this.double_0 / ((Class11.Class27)class22_0).double_0);
			}

			// Token: 0x060001E8 RID: 488 RVA: 0x0000B150 File Offset: 0x00009350
			public override Class11.Class22 vmethod_67(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class27(this.double_0 / ((Class11.Class27)class22_0).double_0);
			}

			// Token: 0x060001E9 RID: 489 RVA: 0x0000B1A4 File Offset: 0x000093A4
			public override Class11.Class22 vmethod_68(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class27(this.double_0 % ((Class11.Class27)class22_0).double_0);
			}

			// Token: 0x060001EA RID: 490 RVA: 0x0000B1A4 File Offset: 0x000093A4
			public override Class11.Class22 vmethod_69(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return new Class11.Class27(this.double_0 % ((Class11.Class27)class22_0).double_0);
			}

			// Token: 0x060001EB RID: 491 RVA: 0x000025C1 File Offset: 0x000007C1
			public override Class11.Class22 vmethod_70(Class11.Class22 class22_0)
			{
				throw new Class11.Exception1();
			}

			// Token: 0x060001EC RID: 492 RVA: 0x000025C1 File Offset: 0x000007C1
			public override Class11.Class22 vmethod_71(Class11.Class22 class22_0)
			{
				throw new Class11.Exception1();
			}

			// Token: 0x060001ED RID: 493 RVA: 0x000025C1 File Offset: 0x000007C1
			public override Class11.Class22 vmethod_72()
			{
				throw new Class11.Exception1();
			}

			// Token: 0x060001EE RID: 494 RVA: 0x000025C1 File Offset: 0x000007C1
			public override Class11.Class22 vmethod_73(Class11.Class22 class22_0)
			{
				throw new Class11.Exception1();
			}

			// Token: 0x060001EF RID: 495 RVA: 0x000025C1 File Offset: 0x000007C1
			public override Class11.Class22 vmethod_75(Class11.Class22 class22_0)
			{
				throw new Class11.Exception1();
			}

			// Token: 0x060001F0 RID: 496 RVA: 0x000025C1 File Offset: 0x000007C1
			public override Class11.Class22 vmethod_76(Class11.Class22 class22_0)
			{
				throw new Class11.Exception1();
			}

			// Token: 0x060001F1 RID: 497 RVA: 0x000025C1 File Offset: 0x000007C1
			public override Class11.Class22 vmethod_77(Class11.Class22 class22_0)
			{
				throw new Class11.Exception1();
			}

			// Token: 0x060001F2 RID: 498 RVA: 0x000057CC File Offset: 0x000039CC
			internal override Class11.Class22 vmethod_8()
			{
				return this;
			}

			// Token: 0x060001F3 RID: 499 RVA: 0x0000B1F8 File Offset: 0x000093F8
			internal override bool vmethod_5(Class11.Class22 class22_0)
			{
				bool flag = !class22_0.method_0();
				bool result;
				if (flag)
				{
					bool flag2 = !class22_0.vmethod_0();
					if (flag2)
					{
						Class11.Class22 @class = class22_0.vmethod_8();
						bool flag3 = !@class.method_4();
						result = (!flag3 && this.double_0 == ((Class11.Class27)@class).double_0);
					}
					else
					{
						result = ((Class11.Class28)class22_0).vmethod_5(this);
					}
				}
				else
				{
					result = false;
				}
				return result;
			}

			// Token: 0x060001F4 RID: 500 RVA: 0x0000B26C File Offset: 0x0000946C
			internal override bool vmethod_6(Class11.Class22 class22_0)
			{
				bool flag = !class22_0.method_0();
				bool result;
				if (flag)
				{
					bool flag2 = !class22_0.vmethod_0();
					if (flag2)
					{
						Class11.Class22 @class = class22_0.vmethod_8();
						bool flag3 = !@class.method_4();
						result = (!flag3 && this.double_0 != ((Class11.Class27)@class).double_0);
					}
					else
					{
						result = ((Class11.Class28)class22_0).vmethod_6(this);
					}
				}
				else
				{
					result = false;
				}
				return result;
			}

			// Token: 0x060001F5 RID: 501 RVA: 0x0000B2E4 File Offset: 0x000094E4
			public override bool vmethod_78(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return this.double_0 >= ((Class11.Class27)class22_0).double_0;
			}

			// Token: 0x060001F6 RID: 502 RVA: 0x0000B2E4 File Offset: 0x000094E4
			public override bool vmethod_79(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return this.double_0 >= ((Class11.Class27)class22_0).double_0;
			}

			// Token: 0x060001F7 RID: 503 RVA: 0x0000B334 File Offset: 0x00009534
			public override bool vmethod_80(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return this.double_0 > ((Class11.Class27)class22_0).double_0;
			}

			// Token: 0x060001F8 RID: 504 RVA: 0x0000B334 File Offset: 0x00009534
			public override bool vmethod_81(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return this.double_0 > ((Class11.Class27)class22_0).double_0;
			}

			// Token: 0x060001F9 RID: 505 RVA: 0x0000B384 File Offset: 0x00009584
			public override bool vmethod_82(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return this.double_0 <= ((Class11.Class27)class22_0).double_0;
			}

			// Token: 0x060001FA RID: 506 RVA: 0x0000B384 File Offset: 0x00009584
			public override bool vmethod_83(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return this.double_0 <= ((Class11.Class27)class22_0).double_0;
			}

			// Token: 0x060001FB RID: 507 RVA: 0x0000B3D4 File Offset: 0x000095D4
			public override bool vmethod_84(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return this.double_0 < ((Class11.Class27)class22_0).double_0;
			}

			// Token: 0x060001FC RID: 508 RVA: 0x0000B3D4 File Offset: 0x000095D4
			public override bool vmethod_85(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				if (flag)
				{
					class22_0 = class22_0.vmethod_8();
				}
				bool flag2 = !class22_0.method_4();
				if (flag2)
				{
					throw new Class11.Exception1();
				}
				return this.double_0 < ((Class11.Class27)class22_0).double_0;
			}

			// Token: 0x0400002D RID: 45
			public double double_0;

			// Token: 0x0400002E RID: 46
			public Class11.Enum1 enum1_0;
		}

		// Token: 0x0200001E RID: 30
		internal enum Enum1 : byte
		{

		}

		// Token: 0x0200001F RID: 31
		internal enum Enum2 : byte
		{

		}

		// Token: 0x02000020 RID: 32
		private class Exception0 : Exception
		{
			// Token: 0x060001FD RID: 509 RVA: 0x000025C9 File Offset: 0x000007C9
			public Exception0(string string_0) : base(string_0)
			{
			}
		}

		// Token: 0x02000021 RID: 33
		private class Exception1 : Exception
		{
			// Token: 0x060001FE RID: 510 RVA: 0x000025D4 File Offset: 0x000007D4
			public Exception1()
			{
			}

			// Token: 0x060001FF RID: 511 RVA: 0x000025C9 File Offset: 0x000007C9
			public Exception1(string string_0) : base(string_0)
			{
			}
		}

		// Token: 0x02000022 RID: 34
		internal class Class12
		{
			// Token: 0x06000200 RID: 512 RVA: 0x0000B424 File Offset: 0x00009624
			public override string ToString()
			{
				object obj = this.enum3_0;
				bool flag = this.object_0 == null;
				string result;
				if (flag)
				{
					result = obj.ToString();
				}
				else
				{
					result = obj.ToString() + "H" + this.object_0.ToString();
				}
				return result;
			}

			// Token: 0x04000031 RID: 49
			internal Class11.Enum3 enum3_0 = (Class11.Enum3)126;

			// Token: 0x04000032 RID: 50
			internal object object_0;
		}

		// Token: 0x02000023 RID: 35
		internal abstract class Class28 : Class11.Class22
		{
			// Token: 0x06000202 RID: 514 RVA: 0x000025EF File Offset: 0x000007EF
			public Class28()
			{
			}

			// Token: 0x06000203 RID: 515 RVA: 0x000057E0 File Offset: 0x000039E0
			internal override bool vmethod_0()
			{
				return true;
			}

			// Token: 0x06000204 RID: 516
			internal abstract IntPtr vmethod_11();

			// Token: 0x06000205 RID: 517
			internal abstract void vmethod_12(Class11.Class22 class22_0);

			// Token: 0x06000206 RID: 518 RVA: 0x000057E0 File Offset: 0x000039E0
			internal override bool vmethod_1()
			{
				return true;
			}
		}

		// Token: 0x02000024 RID: 36
		internal class Class29 : Class11.Class28
		{
			// Token: 0x06000207 RID: 519 RVA: 0x000025F9 File Offset: 0x000007F9
			public Class29(int int_1, Class11.Class20 class20_1)
			{
				this.class20_0 = class20_1;
				this.int_0 = int_1;
				this.enum4_0 = (Class11.Enum4)7;
			}

			// Token: 0x06000208 RID: 520 RVA: 0x0000B474 File Offset: 0x00009674
			internal override void vmethod_10(Class11.Class22 class22_0)
			{
				bool flag = !(class22_0 is Class11.Class29);
				if (flag)
				{
					Class11.Class14 @class = this.class20_0.class17_0.list_1[this.int_0];
					bool flag2 = class22_0 is Class11.Class28 && (@class.enum1_0 & (Class11.Enum1)226) > (Class11.Enum1)0;
					if (flag2)
					{
						Class11.Class22 class22_ = (class22_0 as Class11.Class28).vmethod_8();
						this.vmethod_12(class22_);
					}
					else
					{
						this.vmethod_12(class22_0);
					}
				}
				else
				{
					this.class20_0 = ((Class11.Class29)class22_0).class20_0;
					this.int_0 = ((Class11.Class29)class22_0).int_0;
				}
			}

			// Token: 0x06000209 RID: 521 RVA: 0x00002618 File Offset: 0x00000818
			internal override void vmethod_2(Class11.Class22 class22_0)
			{
				this.vmethod_12(class22_0);
			}

			// Token: 0x0600020A RID: 522 RVA: 0x00002623 File Offset: 0x00000823
			internal override IntPtr vmethod_11()
			{
				throw new NotImplementedException();
			}

			// Token: 0x0600020B RID: 523 RVA: 0x0000262B File Offset: 0x0000082B
			internal override void vmethod_12(Class11.Class22 class22_0)
			{
				this.class20_0.class22_1[this.int_0] = class22_0;
			}

			// Token: 0x0600020C RID: 524 RVA: 0x0000B518 File Offset: 0x00009718
			internal override object vmethod_4(Type type_0)
			{
				bool flag = this.class20_0.class22_1[this.int_0] != null;
				object result;
				if (flag)
				{
					result = this.vmethod_8().vmethod_4(type_0);
				}
				else
				{
					result = null;
				}
				return result;
			}

			// Token: 0x0600020D RID: 525 RVA: 0x0000B554 File Offset: 0x00009754
			internal override Class11.Class22 vmethod_8()
			{
				bool flag = this.class20_0.class22_1[this.int_0] == null;
				Class11.Class22 result;
				if (flag)
				{
					result = new Class11.Class34(null);
				}
				else
				{
					result = this.class20_0.class22_1[this.int_0].vmethod_8();
				}
				return result;
			}

			// Token: 0x0600020E RID: 526 RVA: 0x0000B5A0 File Offset: 0x000097A0
			internal override bool vmethod_9()
			{
				return this.vmethod_8().vmethod_9();
			}

			// Token: 0x0600020F RID: 527 RVA: 0x0000B5C0 File Offset: 0x000097C0
			internal override bool vmethod_5(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				bool result;
				if (flag)
				{
					bool flag2 = !(class22_0 is Class11.Class29);
					if (flag2)
					{
						result = false;
					}
					else
					{
						bool flag3 = ((Class11.Class29)class22_0).int_0 == this.int_0;
						result = flag3;
					}
				}
				else
				{
					result = false;
				}
				return result;
			}

			// Token: 0x06000210 RID: 528 RVA: 0x0000B614 File Offset: 0x00009814
			internal override bool vmethod_6(Class11.Class22 class22_0)
			{
				bool flag = !class22_0.vmethod_0();
				bool result;
				if (flag)
				{
					result = true;
				}
				else
				{
					bool flag2 = class22_0 is Class11.Class29;
					if (flag2)
					{
						bool flag3 = ((Class11.Class29)class22_0).int_0 != this.int_0;
						result = flag3;
					}
					else
					{
						result = true;
					}
				}
				return result;
			}

			// Token: 0x06000211 RID: 529 RVA: 0x0000B66C File Offset: 0x0000986C
			internal override bool vmethod_7()
			{
				return this.vmethod_8().vmethod_7();
			}

			// Token: 0x04000033 RID: 51
			private Class11.Class20 class20_0;

			// Token: 0x04000034 RID: 52
			internal int int_0;
		}

		// Token: 0x02000025 RID: 37
		internal class Class30 : Class11.Class28
		{
			// Token: 0x06000212 RID: 530 RVA: 0x00002641 File Offset: 0x00000841
			public Class30(int int_1, Array array_1)
			{
				this.array_0 = array_1;
				this.int_0 = int_1;
				this.enum4_0 = (Class11.Enum4)7;
			}

			// Token: 0x06000213 RID: 531 RVA: 0x00002623 File Offset: 0x00000823
			internal override IntPtr vmethod_11()
			{
				throw new NotImplementedException();
			}

			// Token: 0x06000214 RID: 532 RVA: 0x0000B68C File Offset: 0x0000988C
			internal override void vmethod_10(Class11.Class22 class22_0)
			{
				bool flag = !(class22_0 is Class11.Class30);
				if (flag)
				{
					this.vmethod_12(class22_0);
				}
				else
				{
					this.array_0 = ((Class11.Class30)class22_0).array_0;
					this.int_0 = ((Class11.Class30)class22_0).int_0;
				}
			}

			// Token: 0x06000215 RID: 533 RVA: 0x00002618 File Offset: 0x00000818
			internal override void vmethod_2(Class11.Class22 class22_0)
			{
				this.vmethod_12(class22_0);
			}

			// Token: 0x06000216 RID: 534 RVA: 0x00002660 File Offset: 0x00000860
			internal override void vmethod_12(Class11.Class22 class22_0)
			{
				this.array_0.SetValue(class22_0.vmethod_4(null), this.int_0);
			}

			// Token: 0x06000217 RID: 535 RVA: 0x0000B6D8 File Offset: 0x000098D8
			internal override object vmethod_4(Type type_0)
			{
				return this.vmethod_8().vmethod_4(type_0);
			}

			// Token: 0x06000218 RID: 536 RVA: 0x0000B6F8 File Offset: 0x000098F8
			internal override Class11.Class22 vmethod_8()
			{
				return Class11.Class22.smethod_1(this.array_0.GetType().GetElementType(), this.array_0.GetValue(this.int_0));
			}

			// Token: 0x06000219 RID: 537 RVA: 0x0000B5A0 File Offset: 0x000097A0
			internal override bool vmethod_9()
			{
				return this.vmethod_8().vmethod_9();
			}

			// Token: 0x0600021A RID: 538 RVA: 0x0000B730 File Offset: 0x00009930
			internal override bool vmethod_5(Class11.Class22 class22_0)
			{
				bool flag = !class22_0.vmethod_0();
				bool result;
				if (flag)
				{
					result = false;
				}
				else
				{
					bool flag2 = !(class22_0 is Class11.Class30);
					if (flag2)
					{
						result = false;
					}
					else
					{
						Class11.Class30 @class = (Class11.Class30)class22_0;
						bool flag3 = @class.int_0 != this.int_0;
						if (flag3)
						{
							result = false;
						}
						else
						{
							bool flag4 = @class.array_0 != this.array_0;
							result = !flag4;
						}
					}
				}
				return result;
			}

			// Token: 0x0600021B RID: 539 RVA: 0x0000B7AC File Offset: 0x000099AC
			internal override bool vmethod_6(Class11.Class22 class22_0)
			{
				bool flag = !class22_0.vmethod_0();
				bool result;
				if (flag)
				{
					result = true;
				}
				else
				{
					bool flag2 = !(class22_0 is Class11.Class30);
					if (flag2)
					{
						result = true;
					}
					else
					{
						Class11.Class30 @class = (Class11.Class30)class22_0;
						bool flag3 = @class.int_0 != this.int_0;
						if (flag3)
						{
							result = true;
						}
						else
						{
							bool flag4 = @class.array_0 != this.array_0;
							result = flag4;
						}
					}
				}
				return result;
			}

			// Token: 0x0600021C RID: 540 RVA: 0x0000B66C File Offset: 0x0000986C
			internal override bool vmethod_7()
			{
				return this.vmethod_8().vmethod_7();
			}

			// Token: 0x04000035 RID: 53
			private Array array_0;

			// Token: 0x04000036 RID: 54
			internal int int_0;
		}

		// Token: 0x02000026 RID: 38
		internal class Class31 : Class11.Class28
		{
			// Token: 0x0600021D RID: 541 RVA: 0x0000267C File Offset: 0x0000087C
			public Class31(FieldInfo fieldInfo_1, object object_1)
			{
				this.fieldInfo_0 = fieldInfo_1;
				this.object_0 = object_1;
				this.enum4_0 = (Class11.Enum4)7;
			}

			// Token: 0x0600021E RID: 542 RVA: 0x00002623 File Offset: 0x00000823
			internal override IntPtr vmethod_11()
			{
				throw new NotImplementedException();
			}

			// Token: 0x0600021F RID: 543 RVA: 0x0000B828 File Offset: 0x00009A28
			internal override void vmethod_12(Class11.Class22 class22_0)
			{
				bool flag = this.object_0 != null && this.object_0 is Class11.Class22;
				if (flag)
				{
					this.fieldInfo_0.SetValue(((Class11.Class22)this.object_0).vmethod_4(null), class22_0.vmethod_4(null));
				}
				else
				{
					this.fieldInfo_0.SetValue(this.object_0, class22_0.vmethod_4(null));
				}
			}

			// Token: 0x06000220 RID: 544 RVA: 0x0000B898 File Offset: 0x00009A98
			internal override void vmethod_10(Class11.Class22 class22_0)
			{
				bool flag = class22_0 is Class11.Class31;
				if (flag)
				{
					this.fieldInfo_0 = ((Class11.Class31)class22_0).fieldInfo_0;
					this.object_0 = ((Class11.Class31)class22_0).object_0;
				}
				else
				{
					this.vmethod_12(class22_0);
				}
			}

			// Token: 0x06000221 RID: 545 RVA: 0x00002618 File Offset: 0x00000818
			internal override void vmethod_2(Class11.Class22 class22_0)
			{
				this.vmethod_12(class22_0);
			}

			// Token: 0x06000222 RID: 546 RVA: 0x0000B6D8 File Offset: 0x000098D8
			internal override object vmethod_4(Type type_0)
			{
				return this.vmethod_8().vmethod_4(type_0);
			}

			// Token: 0x06000223 RID: 547 RVA: 0x0000B8E4 File Offset: 0x00009AE4
			internal override Class11.Class22 vmethod_8()
			{
				bool flag = this.object_0 != null && this.object_0 is Class11.Class22;
				Class11.Class22 result;
				if (flag)
				{
					result = Class11.Class22.smethod_1(this.fieldInfo_0.FieldType, this.fieldInfo_0.GetValue(((Class11.Class22)this.object_0).vmethod_4(null)));
				}
				else
				{
					result = Class11.Class22.smethod_1(this.fieldInfo_0.FieldType, this.fieldInfo_0.GetValue(this.object_0));
				}
				return result;
			}

			// Token: 0x06000224 RID: 548 RVA: 0x0000B5A0 File Offset: 0x000097A0
			internal override bool vmethod_9()
			{
				return this.vmethod_8().vmethod_9();
			}

			// Token: 0x06000225 RID: 549 RVA: 0x0000B964 File Offset: 0x00009B64
			internal override bool vmethod_5(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				bool result;
				if (flag)
				{
					bool flag2 = !(class22_0 is Class11.Class31);
					if (flag2)
					{
						result = false;
					}
					else
					{
						Class11.Class31 @class = (Class11.Class31)class22_0;
						bool flag3 = !(@class.fieldInfo_0 != this.fieldInfo_0);
						if (flag3)
						{
							bool flag4 = @class.object_0 != this.object_0;
							result = !flag4;
						}
						else
						{
							result = false;
						}
					}
				}
				else
				{
					result = false;
				}
				return result;
			}

			// Token: 0x06000226 RID: 550 RVA: 0x0000B9E0 File Offset: 0x00009BE0
			internal override bool vmethod_6(Class11.Class22 class22_0)
			{
				bool flag = !class22_0.vmethod_0();
				bool result;
				if (flag)
				{
					result = true;
				}
				else
				{
					bool flag2 = class22_0 is Class11.Class31;
					if (flag2)
					{
						Class11.Class31 @class = (Class11.Class31)class22_0;
						bool flag3 = !(@class.fieldInfo_0 != this.fieldInfo_0);
						if (flag3)
						{
							bool flag4 = @class.object_0 != this.object_0;
							result = flag4;
						}
						else
						{
							result = true;
						}
					}
					else
					{
						result = true;
					}
				}
				return result;
			}

			// Token: 0x06000227 RID: 551 RVA: 0x0000B66C File Offset: 0x0000986C
			internal override bool vmethod_7()
			{
				return this.vmethod_8().vmethod_7();
			}

			// Token: 0x04000037 RID: 55
			internal FieldInfo fieldInfo_0;

			// Token: 0x04000038 RID: 56
			internal object object_0;
		}

		// Token: 0x02000027 RID: 39
		internal class Class32 : Class11.Class28
		{
			// Token: 0x06000228 RID: 552 RVA: 0x0000269B File Offset: 0x0000089B
			public Class32(int int_1, Class11.Class20 class20_1)
			{
				this.class20_0 = class20_1;
				this.int_0 = int_1;
				this.enum4_0 = (Class11.Enum4)7;
			}

			// Token: 0x06000229 RID: 553 RVA: 0x00002623 File Offset: 0x00000823
			internal override IntPtr vmethod_11()
			{
				throw new NotImplementedException();
			}

			// Token: 0x0600022A RID: 554 RVA: 0x0000BA5C File Offset: 0x00009C5C
			internal override void vmethod_10(Class11.Class22 class22_0)
			{
				bool flag = !(class22_0 is Class11.Class32);
				if (flag)
				{
					this.vmethod_12(class22_0);
				}
				else
				{
					this.class20_0 = ((Class11.Class32)class22_0).class20_0;
					this.int_0 = ((Class11.Class32)class22_0).int_0;
				}
			}

			// Token: 0x0600022B RID: 555 RVA: 0x00002618 File Offset: 0x00000818
			internal override void vmethod_2(Class11.Class22 class22_0)
			{
				this.vmethod_12(class22_0);
			}

			// Token: 0x0600022C RID: 556 RVA: 0x000026BA File Offset: 0x000008BA
			internal override void vmethod_12(Class11.Class22 class22_0)
			{
				this.class20_0.class22_0[this.int_0] = class22_0;
			}

			// Token: 0x0600022D RID: 557 RVA: 0x0000BAA8 File Offset: 0x00009CA8
			internal override object vmethod_4(Type type_0)
			{
				bool flag = this.class20_0.class22_0[this.int_0] != null;
				object result;
				if (flag)
				{
					result = this.vmethod_8().vmethod_4(type_0);
				}
				else
				{
					result = null;
				}
				return result;
			}

			// Token: 0x0600022E RID: 558 RVA: 0x0000BAE4 File Offset: 0x00009CE4
			internal override Class11.Class22 vmethod_8()
			{
				bool flag = this.class20_0.class22_0[this.int_0] != null;
				Class11.Class22 result;
				if (flag)
				{
					result = this.class20_0.class22_0[this.int_0].vmethod_8();
				}
				else
				{
					result = new Class11.Class34(null);
				}
				return result;
			}

			// Token: 0x0600022F RID: 559 RVA: 0x0000B5A0 File Offset: 0x000097A0
			internal override bool vmethod_9()
			{
				return this.vmethod_8().vmethod_9();
			}

			// Token: 0x06000230 RID: 560 RVA: 0x0000BB30 File Offset: 0x00009D30
			internal override bool vmethod_5(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				bool result;
				if (flag)
				{
					bool flag2 = !(class22_0 is Class11.Class32);
					result = (!flag2 && ((Class11.Class32)class22_0).int_0 == this.int_0);
				}
				else
				{
					result = false;
				}
				return result;
			}

			// Token: 0x06000231 RID: 561 RVA: 0x0000BB7C File Offset: 0x00009D7C
			internal override bool vmethod_6(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				bool result;
				if (flag)
				{
					bool flag2 = class22_0 is Class11.Class32;
					result = (!flag2 || ((Class11.Class32)class22_0).int_0 != this.int_0);
				}
				else
				{
					result = true;
				}
				return result;
			}

			// Token: 0x06000232 RID: 562 RVA: 0x0000B66C File Offset: 0x0000986C
			internal override bool vmethod_7()
			{
				return this.vmethod_8().vmethod_7();
			}

			// Token: 0x04000039 RID: 57
			private Class11.Class20 class20_0;

			// Token: 0x0400003A RID: 58
			internal int int_0;
		}

		// Token: 0x02000028 RID: 40
		internal class Class33 : Class11.Class28
		{
			// Token: 0x06000233 RID: 563 RVA: 0x000026D0 File Offset: 0x000008D0
			public Class33(Class11.Class22 class22_1, Type type_1)
			{
				this.class22_0 = class22_1;
				this.type_0 = type_1;
				this.enum4_0 = (Class11.Enum4)7;
			}

			// Token: 0x06000234 RID: 564 RVA: 0x00002623 File Offset: 0x00000823
			internal override IntPtr vmethod_11()
			{
				throw new NotImplementedException();
			}

			// Token: 0x06000235 RID: 565 RVA: 0x0000BBC8 File Offset: 0x00009DC8
			internal override void vmethod_10(Class11.Class22 class22_1)
			{
				bool flag = !(class22_1 is Class11.Class33);
				if (flag)
				{
					this.class22_0.vmethod_10(class22_1);
				}
				else
				{
					this.type_0 = ((Class11.Class33)class22_1).type_0;
					this.class22_0 = ((Class11.Class33)class22_1).class22_0;
				}
			}

			// Token: 0x06000236 RID: 566 RVA: 0x00002618 File Offset: 0x00000818
			internal override void vmethod_2(Class11.Class22 class22_1)
			{
				this.vmethod_12(class22_1);
			}

			// Token: 0x06000237 RID: 567 RVA: 0x000026EF File Offset: 0x000008EF
			internal override void vmethod_12(Class11.Class22 class22_1)
			{
				this.class22_0 = class22_1;
			}

			// Token: 0x06000238 RID: 568 RVA: 0x0000BC18 File Offset: 0x00009E18
			internal override object vmethod_4(Type type_1)
			{
				bool flag = this.class22_0 == null;
				object result;
				if (flag)
				{
					result = new Class11.Class34(null);
				}
				else
				{
					bool flag2 = !(type_1 == null) && !(type_1 == typeof(object));
					if (flag2)
					{
						result = this.class22_0.vmethod_4(type_1);
					}
					else
					{
						result = this.class22_0.vmethod_4(this.type_0);
					}
				}
				return result;
			}

			// Token: 0x06000239 RID: 569 RVA: 0x0000BC88 File Offset: 0x00009E88
			internal override Class11.Class22 vmethod_8()
			{
				bool flag = this.class22_0 != null;
				Class11.Class22 result;
				if (flag)
				{
					result = this.class22_0.vmethod_8();
				}
				else
				{
					result = new Class11.Class34(null);
				}
				return result;
			}

			// Token: 0x0600023A RID: 570 RVA: 0x0000B5A0 File Offset: 0x000097A0
			internal override bool vmethod_9()
			{
				return this.vmethod_8().vmethod_9();
			}

			// Token: 0x0600023B RID: 571 RVA: 0x0000BCBC File Offset: 0x00009EBC
			internal override bool vmethod_5(Class11.Class22 class22_1)
			{
				bool flag = class22_1.vmethod_0();
				bool result;
				if (flag)
				{
					bool flag2 = !(class22_1 is Class11.Class33);
					if (flag2)
					{
						result = false;
					}
					else
					{
						Class11.Class33 @class = (Class11.Class33)class22_1;
						bool flag3 = @class.type_0 != this.type_0;
						if (flag3)
						{
							result = false;
						}
						else
						{
							bool flag4 = this.class22_0 != null;
							if (flag4)
							{
								result = this.class22_0.vmethod_5(@class.class22_0);
							}
							else
							{
								bool flag5 = @class.class22_0 != null;
								result = !flag5;
							}
						}
					}
				}
				else
				{
					result = false;
				}
				return result;
			}

			// Token: 0x0600023C RID: 572 RVA: 0x0000BD50 File Offset: 0x00009F50
			internal override bool vmethod_6(Class11.Class22 class22_1)
			{
				bool flag = class22_1.vmethod_0();
				bool result;
				if (flag)
				{
					bool flag2 = !(class22_1 is Class11.Class33);
					if (flag2)
					{
						result = true;
					}
					else
					{
						Class11.Class33 @class = (Class11.Class33)class22_1;
						bool flag3 = !(@class.type_0 != this.type_0);
						if (flag3)
						{
							bool flag4 = this.class22_0 == null;
							if (flag4)
							{
								bool flag5 = @class.class22_0 == null;
								result = !flag5;
							}
							else
							{
								result = this.class22_0.vmethod_6(@class.class22_0);
							}
						}
						else
						{
							result = true;
						}
					}
				}
				else
				{
					result = true;
				}
				return result;
			}

			// Token: 0x0600023D RID: 573 RVA: 0x0000B66C File Offset: 0x0000986C
			internal override bool vmethod_7()
			{
				return this.vmethod_8().vmethod_7();
			}

			// Token: 0x0400003B RID: 59
			private Class11.Class22 class22_0;

			// Token: 0x0400003C RID: 60
			private Type type_0;
		}

		// Token: 0x02000029 RID: 41
		internal class Class13
		{
			// Token: 0x0400003D RID: 61
			public int int_0;

			// Token: 0x0400003E RID: 62
			public bool bool_0;

			// Token: 0x0400003F RID: 63
			public Class11.Enum1 enum1_0;
		}

		// Token: 0x0200002A RID: 42
		internal class Class14
		{
			// Token: 0x04000040 RID: 64
			public int int_0;

			// Token: 0x04000041 RID: 65
			public Class11.Enum1 enum1_0;

			// Token: 0x04000042 RID: 66
			public bool bool_0;

			// Token: 0x04000043 RID: 67
			public Type type_0 = typeof(object);
		}

		// Token: 0x0200002B RID: 43
		internal class Class15
		{
			// Token: 0x04000044 RID: 68
			public int int_0;

			// Token: 0x04000045 RID: 69
			public int int_1;

			// Token: 0x04000046 RID: 70
			public Class11.Class16 class16_0;
		}

		// Token: 0x0200002C RID: 44
		internal class Class16
		{
			// Token: 0x04000047 RID: 71
			public int int_0;

			// Token: 0x04000048 RID: 72
			public int int_1;

			// Token: 0x04000049 RID: 73
			public byte byte_0;

			// Token: 0x0400004A RID: 74
			public Type type_0;

			// Token: 0x0400004B RID: 75
			public int int_2;

			// Token: 0x0400004C RID: 76
			public int int_3;
		}

		// Token: 0x0200002D RID: 45
		internal class Class17
		{
			// Token: 0x0400004D RID: 77
			internal object object_0;

			// Token: 0x0400004E RID: 78
			internal List<Class11.Class12> list_0;

			// Token: 0x0400004F RID: 79
			internal Class11.Class13[] class13_0;

			// Token: 0x04000050 RID: 80
			internal List<Class11.Class14> list_1;

			// Token: 0x04000051 RID: 81
			internal List<Class11.Class15> list_2;
		}

		// Token: 0x0200002E RID: 46
		private class Class18
		{
			// Token: 0x06000243 RID: 579 RVA: 0x00002712 File Offset: 0x00000912
			public Class18(FieldInfo fieldInfo_0, int int_1)
			{
				this.object_0 = fieldInfo_0;
				this.int_0 = int_1;
			}

			// Token: 0x04000052 RID: 82
			internal object object_0;

			// Token: 0x04000053 RID: 83
			internal int int_0;
		}

		// Token: 0x0200002F RID: 47
		private class Class19
		{
			// Token: 0x06000244 RID: 580 RVA: 0x0000272A File Offset: 0x0000092A
			public Class19(MethodBase methodBase_1, List<Class11.Class18> list_1)
			{
				this.list_0 = list_1;
				this.methodBase_0 = methodBase_1;
			}

			// Token: 0x06000245 RID: 581 RVA: 0x0000274D File Offset: 0x0000094D
			public Class19(MethodBase methodBase_1, Class11.Class18[] class18_0)
			{
				this.list_0.AddRange(class18_0);
			}

			// Token: 0x06000246 RID: 582 RVA: 0x0000BDE8 File Offset: 0x00009FE8
			public override bool Equals(object obj)
			{
				Class11.Class19 @class = obj as Class11.Class19;
				bool flag = obj == null;
				bool result;
				if (flag)
				{
					result = false;
				}
				else
				{
					bool flag2 = !(this.methodBase_0 != @class.methodBase_0);
					if (flag2)
					{
						bool flag3 = this.list_0.Count != @class.list_0.Count;
						if (flag3)
						{
							result = false;
						}
						else
						{
							int num = 0;
							for (;;)
							{
								bool flag4 = num < this.list_0.Count;
								if (!flag4)
								{
									goto IL_F1;
								}
								bool flag5 = (FieldInfo)this.list_0[num].object_0 != (FieldInfo)@class.list_0[num].object_0;
								if (flag5)
								{
									break;
								}
								bool flag6 = this.list_0[num].int_0 == @class.list_0[num].int_0;
								if (!flag6)
								{
									goto IL_ED;
								}
								num++;
							}
							return false;
							IL_ED:
							return false;
							IL_F1:
							result = true;
						}
					}
					else
					{
						result = false;
					}
				}
				return result;
			}

			// Token: 0x06000247 RID: 583 RVA: 0x0000BEFC File Offset: 0x0000A0FC
			public override int GetHashCode()
			{
				int num = this.methodBase_0.GetHashCode();
				foreach (Class11.Class18 @class in this.list_0)
				{
					int num2 = @class.object_0.GetHashCode() + @class.int_0;
					num = (num ^ num2) + num2;
				}
				return num;
			}

			// Token: 0x06000248 RID: 584 RVA: 0x0000BF7C File Offset: 0x0000A17C
			public Class11.Class18 method_0(int int_0)
			{
				foreach (Class11.Class18 @class in this.list_0)
				{
					bool flag = @class.int_0 == int_0;
					if (flag)
					{
						return @class;
					}
				}
				return null;
			}

			// Token: 0x06000249 RID: 585 RVA: 0x0000BFE4 File Offset: 0x0000A1E4
			public bool method_1(int int_0)
			{
				foreach (Class11.Class18 @class in this.list_0)
				{
					bool flag = @class.int_0 == int_0;
					if (flag)
					{
						return true;
					}
				}
				return false;
			}

			// Token: 0x04000054 RID: 84
			private List<Class11.Class18> list_0 = new List<Class11.Class18>();

			// Token: 0x04000055 RID: 85
			private MethodBase methodBase_0;
		}

		// Token: 0x02000030 RID: 48
		// (Invoke) Token: 0x0600024B RID: 587
		private delegate object Delegate10(object target, object[] paramters);

		// Token: 0x02000031 RID: 49
		// (Invoke) Token: 0x0600024F RID: 591
		private delegate object Delegate11(object target);

		// Token: 0x02000032 RID: 50
		// (Invoke) Token: 0x06000253 RID: 595
		private delegate void Delegate12(IntPtr a, byte b, int c);

		// Token: 0x02000033 RID: 51
		// (Invoke) Token: 0x06000257 RID: 599
		private delegate void Delegate13(IntPtr s, IntPtr t, uint c);

		// Token: 0x02000034 RID: 52
		internal class Class20
		{
			// Token: 0x0600025A RID: 602 RVA: 0x0000C04C File Offset: 0x0000A24C
			internal void method_0()
			{
				bool flag = false;
				this.method_2(ref flag);
			}

			// Token: 0x0600025B RID: 603 RVA: 0x0000C068 File Offset: 0x0000A268
			internal void method_1()
			{
				this.class36_0.method_1();
				this.class22_1 = null;
				bool flag = this.list_0 == null;
				if (!flag)
				{
					foreach (IntPtr hglobal in this.list_0)
					{
						try
						{
							Marshal.FreeHGlobal(hglobal);
						}
						catch
						{
						}
					}
					this.list_0.Clear();
					this.list_0 = null;
				}
			}

			// Token: 0x0600025C RID: 604 RVA: 0x0000C10C File Offset: 0x0000A30C
			internal void method_2(ref bool bool_4)
			{
				while (this.int_0 > -2)
				{
					bool flag = this.bool_0;
					if (flag)
					{
						this.bool_0 = false;
						int num = this.int_1;
						int num2 = this.int_0;
						this.method_4(this.int_1, this.int_0);
						this.int_0 = num2;
						this.int_1 = num;
					}
					bool flag2 = !this.bool_2;
					if (flag2)
					{
						bool flag3 = !this.bool_1;
						if (flag3)
						{
							this.int_1 = this.int_0;
							Class11.Class12 @class = this.class17_0.list_0[this.int_0];
							this.object_0 = @class.object_0;
							try
							{
								this.method_7(@class);
							}
							catch (Exception innerException)
							{
								bool flag4 = innerException is TargetInvocationException;
								if (flag4)
								{
									TargetInvocationException ex = (TargetInvocationException)innerException;
									bool flag5 = ex.InnerException != null;
									if (flag5)
									{
										innerException = ex.InnerException;
									}
								}
								this.exception_0 = innerException;
								bool_4 = true;
								this.class36_0.method_1();
								int int_ = this.int_1;
								Class11.Class15 class2 = this.method_5(int_, innerException);
								List<Class11.Class15> list = this.method_6(int_, false);
								List<Class11.Class15> list2 = new List<Class11.Class15>();
								bool flag6 = class2 != null;
								if (flag6)
								{
									list2.Add(class2);
								}
								bool flag7 = list != null && list.Count > 0;
								if (flag7)
								{
									list2.AddRange(list);
								}
								list2.Sort((Class11.Class15 x, Class11.Class15 y) => x.class16_0.int_0.CompareTo(y.class16_0.int_0));
								Class11.Class15 class3 = null;
								foreach (Class11.Class15 class4 in list2)
								{
									bool flag8 = class4.class16_0.int_3 != 0;
									if (!flag8)
									{
										class3 = class4;
										break;
									}
									this.class36_0.method_2(new Class11.Class34(innerException));
									this.int_1 = class4.class16_0.int_2;
									this.int_0 = this.int_1;
									this.method_0();
									bool flag9 = this.bool_3;
									if (flag9)
									{
										this.bool_3 = false;
										class3 = class4;
										break;
									}
								}
								bool flag10 = class3 == null;
								if (flag10)
								{
									throw innerException;
								}
								this.int_2 = class3.class16_0.int_0;
								this.method_3(int_, class3.class16_0.int_0);
								bool flag11 = this.int_2 >= 0;
								if (flag11)
								{
									this.class36_0.method_2(new Class11.Class34(innerException));
									this.int_1 = this.int_2;
									this.int_0 = this.int_1;
									this.int_2 = -1;
									this.method_0();
								}
								return;
							}
							this.int_0++;
							continue;
						}
						this.bool_1 = false;
					}
					else
					{
						this.bool_2 = false;
					}
					return;
				}
				this.class36_0.method_1();
			}

			// Token: 0x0600025D RID: 605 RVA: 0x0000C440 File Offset: 0x0000A640
			internal void method_3(int int_3, int int_4)
			{
				bool flag = this.class17_0.list_2 == null;
				if (!flag)
				{
					foreach (Class11.Class15 @class in this.class17_0.list_2)
					{
						bool flag2 = (@class.class16_0.int_3 == 4 || @class.class16_0.int_3 == 2) && @class.class16_0.int_0 >= int_3 && @class.class16_0.int_1 <= int_4;
						if (flag2)
						{
							this.int_1 = @class.class16_0.int_0;
							this.int_0 = this.int_1;
							bool flag3 = false;
							this.method_2(ref flag3);
							bool flag4 = flag3;
							if (flag4)
							{
								break;
							}
						}
					}
				}
			}

			// Token: 0x0600025E RID: 606 RVA: 0x0000C52C File Offset: 0x0000A72C
			internal void method_4(int int_3, int int_4)
			{
				bool flag = this.class17_0.list_2 == null;
				if (!flag)
				{
					foreach (Class11.Class15 @class in this.class17_0.list_2)
					{
						bool flag2 = @class.class16_0.int_3 == 2 && @class.class16_0.int_0 >= int_3 && @class.class16_0.int_1 <= int_4;
						if (flag2)
						{
							this.int_1 = @class.class16_0.int_0;
							this.int_0 = this.int_1;
							bool flag3 = false;
							this.method_2(ref flag3);
							bool flag4 = flag3;
							if (flag4)
							{
								break;
							}
						}
					}
				}
			}

			// Token: 0x0600025F RID: 607 RVA: 0x0000C604 File Offset: 0x0000A804
			internal Class11.Class15 method_5(int int_3, Exception exception_1)
			{
				Class11.Class15 @class = null;
				bool flag = this.class17_0.list_2 != null;
				if (flag)
				{
					foreach (Class11.Class15 class2 in this.class17_0.list_2)
					{
						bool flag2 = class2.class16_0.int_3 == 0 && (class2.class16_0.type_0 == exception_1.GetType() || (class2.class16_0.type_0 != null && (class2.class16_0.type_0.FullName == exception_1.GetType().FullName || class2.class16_0.type_0.FullName == typeof(object).FullName || class2.class16_0.type_0.FullName == typeof(Exception).FullName))) && int_3 >= class2.int_0 && int_3 <= class2.int_1;
						if (flag2)
						{
							bool flag3 = @class == null;
							if (flag3)
							{
								@class = class2;
							}
							else
							{
								bool flag4 = class2.class16_0.int_0 < @class.class16_0.int_0;
								if (flag4)
								{
									@class = class2;
								}
							}
						}
					}
				}
				return @class;
			}

			// Token: 0x06000260 RID: 608 RVA: 0x0000C790 File Offset: 0x0000A990
			internal List<Class11.Class15> method_6(int int_3, bool bool_4)
			{
				bool flag = this.class17_0.list_2 == null;
				List<Class11.Class15> result;
				if (flag)
				{
					result = null;
				}
				else
				{
					List<Class11.Class15> list = new List<Class11.Class15>();
					foreach (Class11.Class15 @class in this.class17_0.list_2)
					{
						bool flag2 = (@class.class16_0.int_3 & 1) == 1 && int_3 >= @class.int_0 && int_3 <= @class.int_1;
						if (flag2)
						{
							list.Add(@class);
						}
					}
					bool flag3 = list.Count == 0;
					if (flag3)
					{
						result = null;
					}
					else
					{
						result = list;
					}
				}
				return result;
			}

			// Token: 0x06000261 RID: 609 RVA: 0x0000C85C File Offset: 0x0000AA5C
			private unsafe void method_7(Class11.Class12 class12_0)
			{
				switch (class12_0.enum3_0)
				{
				case (Class11.Enum3)0:
				{
					Class11.Class22 @class = this.class36_0.method_4();
					bool flag = Class11.Class20.smethod_1(this.class36_0.method_4()).vmethod_85(@class);
					if (flag)
					{
						this.class36_0.method_2(new Class11.Class24(1));
					}
					else
					{
						this.class36_0.method_2(new Class11.Class24(0));
					}
					break;
				}
				case (Class11.Enum3)1:
				case (Class11.Enum3)121:
				{
					int metadataToken = (int)this.object_0;
					Type type = typeof(Class11).Module.ResolveType(metadataToken);
					Class11.Class22 class2 = this.class36_0.method_4();
					object obj = class2.vmethod_4(type);
					bool flag2 = obj != null;
					if (flag2)
					{
						bool isValueType = type.IsValueType;
						if (isValueType)
						{
							obj = Class11.Class20.smethod_9(obj);
						}
						class2 = Class11.Class22.smethod_1(type, obj);
					}
					else
					{
						bool isValueType2 = type.IsValueType;
						if (isValueType2)
						{
							obj = Activator.CreateInstance(type);
							class2 = Class11.Class22.smethod_1(type, obj);
						}
						else
						{
							class2 = new Class11.Class34(null);
						}
					}
					Class11.Class28 class3 = this.class36_0.method_4() as Class11.Class28;
					if (class3 == null)
					{
						throw new Class11.Exception1();
					}
					class3.vmethod_10(class2);
					break;
				}
				case (Class11.Enum3)2:
				{
					Class11.Class22 class4 = this.class36_0.method_4();
					Class11.Class22 class5 = this.class36_0.method_4();
					bool flag3 = class4.vmethod_5(class5);
					if (flag3)
					{
						this.int_0 = (int)this.object_0 - 1;
					}
					break;
				}
				case (Class11.Enum3)3:
					this.bool_3 = (bool)this.class36_0.method_4().vmethod_4(typeof(bool));
					this.bool_1 = true;
					break;
				case (Class11.Enum3)4:
				{
					Class11.Class23 class6 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag4 = class6 != null;
					if (!flag4)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class6.vmethod_36());
					break;
				}
				case (Class11.Enum3)5:
				{
					int metadataToken2 = (int)this.object_0;
					Type type2 = typeof(Class11).Module.ResolveType(metadataToken2);
					Class11.Class22 class7 = this.class36_0.method_4();
					object obj2 = class7.vmethod_4(null);
					bool flag5 = obj2 != null;
					if (flag5)
					{
						bool flag6 = type2.IsAssignableFrom(obj2.GetType());
						if (flag6)
						{
							this.class36_0.method_2(class7);
						}
						else
						{
							this.class36_0.method_2(new Class11.Class34(null));
						}
					}
					else
					{
						this.class36_0.method_2(new Class11.Class34(null));
					}
					break;
				}
				case (Class11.Enum3)6:
					this.class36_0.method_2(this.class36_0.method_3());
					break;
				case (Class11.Enum3)7:
				{
					Class11.Class22 class8 = this.class36_0.method_4();
					bool flag7 = class8.vmethod_3();
					if (flag7)
					{
						class8 = ((Class11.Class23)class8).vmethod_23();
					}
					this.class36_0.method_4().vmethod_2(class8);
					break;
				}
				case (Class11.Enum3)8:
				{
					Class11.Class23 class9 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag8 = class9 != null;
					if (!flag8)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class9.vmethod_41());
					break;
				}
				case (Class11.Enum3)9:
				{
					Class11.Class23 class10 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag9 = class10 != null;
					if (!flag9)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class10.vmethod_29());
					break;
				}
				case (Class11.Enum3)10:
				{
					Class11.Class22 class11 = this.class36_0.method_4();
					bool flag10 = class11.vmethod_3();
					if (flag10)
					{
						class11 = ((Class11.Class23)class11).vmethod_24();
					}
					this.class36_0.method_4().vmethod_2(class11);
					break;
				}
				case (Class11.Enum3)11:
				{
					Class11.Class23 class12 = Class11.Class20.smethod_1(this.class36_0.method_4());
					object value = ((Array)this.class36_0.method_4().vmethod_4(null)).GetValue(class12.vmethod_19().struct1_0.int_0);
					this.class36_0.method_2(Class11.Class22.smethod_1(typeof(int), value));
					break;
				}
				case (Class11.Enum3)12:
				{
					Class11.Class23 class13 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag11 = class13 != null;
					if (!flag11)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class13.vmethod_46());
					break;
				}
				case (Class11.Enum3)13:
				{
					Class11.Class22 class14 = this.class36_0.method_4();
					this.class36_0.method_4().vmethod_2(class14);
					break;
				}
				case (Class11.Enum3)14:
				{
					Class11.Class22 class15 = Class11.Class20.smethod_6(this.class36_0.method_4());
					Class11.Class22 class16 = Class11.Class20.smethod_6(this.class36_0.method_4());
					bool flag12 = !class15.vmethod_5(class16);
					if (flag12)
					{
						this.class36_0.method_2(new Class11.Class24(0));
					}
					else
					{
						this.class36_0.method_2(new Class11.Class24(1));
					}
					break;
				}
				case (Class11.Enum3)15:
				{
					Class11.Class22 class17 = this.class36_0.method_4();
					bool flag13 = Class11.Class20.smethod_1(this.class36_0.method_4()).vmethod_84(class17);
					if (flag13)
					{
						this.class36_0.method_2(new Class11.Class24(1));
					}
					else
					{
						this.class36_0.method_2(new Class11.Class24(0));
					}
					break;
				}
				case (Class11.Enum3)16:
				{
					Class11.Class23 class18 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag14 = class18 != null;
					if (!flag14)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class18.vmethod_44());
					break;
				}
				case (Class11.Enum3)17:
				{
					Class11.Class23 class19 = Class11.Class20.smethod_1(this.class36_0.method_4());
					object value2 = ((Array)this.class36_0.method_4().vmethod_4(null)).GetValue(class19.vmethod_19().struct1_0.int_0);
					this.class36_0.method_2(Class11.Class22.smethod_1(typeof(float), value2));
					break;
				}
				case (Class11.Enum3)18:
				{
					Class11.Class22 class20 = this.class36_0.method_4();
					Class11.Class23 class21 = Class11.Class20.smethod_1(class20);
					Class11.Class22 class22_ = this.class36_0.method_4();
					Class11.Class23 class22 = Class11.Class20.smethod_1(class22_);
					bool flag15 = class22 != null && class21 != null;
					if (flag15)
					{
						bool flag16 = class22.vmethod_81(class20);
						if (flag16)
						{
							this.int_0 = (int)this.object_0 - 1;
						}
					}
					else
					{
						bool flag17 = class20.vmethod_6(class22_);
						if (flag17)
						{
							this.int_0 = (int)this.object_0 - 1;
						}
					}
					break;
				}
				case (Class11.Enum3)19:
				{
					Class11.Class23 class23 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag18 = class23 != null;
					if (!flag18)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class23.vmethod_49());
					break;
				}
				case (Class11.Enum3)20:
				{
					int metadataToken3 = (int)this.object_0;
					Type type3 = typeof(Class11).Module.ResolveType(metadataToken3);
					Class11.Class22 class24 = this.class36_0.method_4();
					Class11.Class28 class25 = class24 as Class11.Class28;
					bool flag19 = class25 != null;
					if (!flag19)
					{
						throw new Class11.Exception1();
					}
					bool isValueType3 = type3.IsValueType;
					if (isValueType3)
					{
						object obj3 = Activator.CreateInstance(type3);
						class25.vmethod_12(Class11.Class22.smethod_1(type3, obj3));
					}
					else
					{
						class25.vmethod_12(new Class11.Class34(null));
					}
					break;
				}
				case (Class11.Enum3)21:
				{
					Class11.Class23 class26 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class27 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag20 = class27 != null && class26 != null;
					if (!flag20)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class27.vmethod_69(class26));
					break;
				}
				case (Class11.Enum3)22:
				{
					int metadataToken4 = (int)this.object_0;
					Type type4 = typeof(Class11).Module.ResolveType(metadataToken4);
					Class11.Class28 class28 = this.class36_0.method_4() as Class11.Class28;
					if (class28 == null)
					{
						throw new Class11.Exception1();
					}
					object obj4 = class28.vmethod_4(type4);
					bool flag21 = obj4 != null;
					Class11.Class22 class29;
					if (flag21)
					{
						bool isValueType4 = type4.IsValueType;
						if (isValueType4)
						{
							obj4 = Class11.Class20.smethod_9(obj4);
						}
						class29 = Class11.Class22.smethod_1(type4, obj4);
					}
					else
					{
						bool flag22 = !type4.IsValueType;
						if (flag22)
						{
							class29 = new Class11.Class34(null);
						}
						else
						{
							obj4 = Activator.CreateInstance(type4);
							class29 = Class11.Class22.smethod_1(type4, obj4);
						}
					}
					this.class36_0.method_2(class29);
					break;
				}
				case (Class11.Enum3)23:
				{
					int metadataToken5 = (int)this.object_0;
					uint uint_ = (uint)Class11.Class20.smethod_0(typeof(Class11).Module.ResolveType(metadataToken5));
					this.class36_0.method_2(new Class11.Class24(uint_, (Class11.Enum1)6));
					break;
				}
				case (Class11.Enum3)24:
				{
					Class11.Class23 class30 = Class11.Class20.smethod_1(this.class36_0.method_3());
					if (class30 == null)
					{
						throw new ArithmeticException(((Class11.Enum5)0).ToString());
					}
					Class11.Class23 class31 = class30;
					Class11.Class27 class32 = class31 as Class11.Class27;
					bool flag23 = class32 != null;
					if (flag23)
					{
						bool flag24 = double.IsNaN(class32.double_0);
						if (flag24)
						{
							throw new OverflowException(((Class11.Enum5)2).ToString());
						}
						bool flag25 = double.IsInfinity(class32.double_0);
						if (flag25)
						{
							throw new OverflowException(((Class11.Enum5)1).ToString());
						}
					}
					break;
				}
				case (Class11.Enum3)25:
					this.method_12(false);
					break;
				case (Class11.Enum3)26:
				{
					Class11.Class23 class33 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class34 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag26 = class34 != null && class33 != null;
					if (!flag26)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class34.vmethod_76(class33));
					break;
				}
				case (Class11.Enum3)27:
				case (Class11.Enum3)29:
				case (Class11.Enum3)70:
				case (Class11.Enum3)88:
				case (Class11.Enum3)107:
				case (Class11.Enum3)152:
					throw new Class11.Exception1();
				case (Class11.Enum3)28:
				{
					IntPtr intPtr = Marshal.AllocHGlobal((this.class36_0.method_4() as Class11.Class23).vmethod_19().struct1_0.int_0);
					bool flag27 = this.list_0 == null;
					if (flag27)
					{
						this.list_0 = new List<IntPtr>();
					}
					this.list_0.Add(intPtr);
					this.class36_0.method_2(new Class11.Class26(intPtr));
					break;
				}
				case (Class11.Enum3)30:
				case (Class11.Enum3)34:
				case (Class11.Enum3)51:
				case (Class11.Enum3)61:
				case (Class11.Enum3)65:
				case (Class11.Enum3)104:
				case (Class11.Enum3)143:
				case (Class11.Enum3)144:
				{
					Class11.Class22 class35 = this.class36_0.method_4();
					Class11.Class23 class36 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Array array = (Array)this.class36_0.method_4().vmethod_4(null);
					Type elementType = array.GetType().GetElementType();
					array.SetValue(class35.vmethod_4(elementType), class36.vmethod_19().struct1_0.int_0);
					break;
				}
				case (Class11.Enum3)31:
				{
					int[] array2 = (int[])this.object_0;
					Class11.Class23 class37 = Class11.Class20.smethod_1(this.class36_0.method_4());
					long num = class37.vmethod_21().struct2_0.long_0;
					bool flag28 = (num < 0L || class37.method_4()) && IntPtr.Size == 4;
					if (flag28)
					{
						num = (long)((int)num);
					}
					bool flag29 = class37.method_1();
					if (flag29)
					{
						Class11.Class24 class38 = (Class11.Class24)class37;
						bool flag30 = class38.enum1_0 == (Class11.Enum1)6;
						if (flag30)
						{
							num = (long)((ulong)class38.struct1_0.uint_0);
						}
					}
					bool flag31 = num < (long)array2.Length && num >= 0L;
					if (flag31)
					{
						this.int_0 = array2[(int)(checked((IntPtr)num))] - 1;
					}
					break;
				}
				case (Class11.Enum3)32:
				{
					int metadataToken6 = (int)this.object_0;
					Type elementType2 = typeof(Class11).Module.ResolveType(metadataToken6);
					Class11.Class23 class39 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Array array3 = Array.CreateInstance(elementType2, class39.vmethod_19().struct1_0.int_0);
					this.class36_0.method_2(new Class11.Class34(array3));
					break;
				}
				case (Class11.Enum3)33:
				{
					Class11.Class23 class40 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class41 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag32 = class41 != null && class40 != null;
					if (!flag32)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class41.vmethod_75(class40));
					break;
				}
				case (Class11.Enum3)35:
				{
					Class11.Class22 class42 = this.class36_0.method_4();
					bool flag33 = Class11.Class20.smethod_1(this.class36_0.method_4()).vmethod_80(class42);
					if (flag33)
					{
						this.int_0 = (int)this.object_0 - 1;
					}
					break;
				}
				case (Class11.Enum3)36:
				case (Class11.Enum3)62:
				{
					int metadataToken7 = (int)this.object_0;
					Module module = typeof(Class11).Module;
					this.class36_0.method_2(new Class11.Class26(module.ResolveMethod(metadataToken7).MethodHandle.GetFunctionPointer()));
					break;
				}
				case (Class11.Enum3)37:
				{
					Class11.Class22 class43 = this.class36_0.method_4();
					Class11.Class23 class44 = Class11.Class20.smethod_1(class43);
					Class11.Class22 class22_2 = this.class36_0.method_4();
					Class11.Class23 class45 = Class11.Class20.smethod_1(class22_2);
					bool flag34 = class45 != null && class44 != null;
					if (flag34)
					{
						bool flag35 = !class45.vmethod_81(class43);
						if (flag35)
						{
							this.class36_0.method_2(new Class11.Class24(0));
						}
						else
						{
							this.class36_0.method_2(new Class11.Class24(1));
						}
					}
					else
					{
						bool flag36 = !class43.vmethod_6(class22_2);
						if (flag36)
						{
							this.class36_0.method_2(new Class11.Class24(0));
						}
						else
						{
							this.class36_0.method_2(new Class11.Class24(1));
						}
					}
					break;
				}
				case (Class11.Enum3)38:
				{
					int metadataToken8 = (int)this.object_0;
					FieldInfo fieldInfo_ = typeof(Class11).Module.ResolveField(metadataToken8);
					this.class36_0.method_2(new Class11.Class31(fieldInfo_, null));
					break;
				}
				case (Class11.Enum3)39:
				{
					Class11.Class23 class46 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag37 = class46 != null;
					if (!flag37)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class46.vmethod_35());
					break;
				}
				case (Class11.Enum3)40:
				{
					int metadataToken9 = (int)this.object_0;
					FieldInfo fieldInfo = typeof(Class11).Module.ResolveField(metadataToken9);
					object value3 = this.class36_0.method_4().vmethod_4(fieldInfo.FieldType);
					Class11.Class22 class47 = this.class36_0.method_4();
					object obj5 = class47.vmethod_4(null);
					bool flag38 = obj5 == null;
					if (flag38)
					{
						Type type5 = fieldInfo.DeclaringType;
						bool isByRef = type5.IsByRef;
						if (isByRef)
						{
							type5 = type5.GetElementType();
						}
						bool flag39 = !type5.IsValueType;
						if (flag39)
						{
							throw new NullReferenceException();
						}
						obj5 = Activator.CreateInstance(type5);
						bool flag40 = class47 is Class11.Class29;
						if (flag40)
						{
							((Class11.Class28)class47).vmethod_12(Class11.Class22.smethod_1(type5, obj5));
						}
					}
					fieldInfo.SetValue(obj5, value3);
					break;
				}
				case (Class11.Enum3)41:
				{
					this.int_0 = -3;
					bool flag41 = this.class36_0.method_0() > 0;
					if (flag41)
					{
						this.class22_2 = this.class36_0.method_4();
					}
					break;
				}
				case (Class11.Enum3)42:
				{
					int metadataToken10 = (int)this.object_0;
					FieldInfo fieldInfo2 = typeof(Class11).Module.ResolveField(metadataToken10);
					this.class36_0.method_2(Class11.Class22.smethod_1(fieldInfo2.FieldType, fieldInfo2.GetValue(null)));
					break;
				}
				case (Class11.Enum3)43:
					this.bool_2 = true;
					break;
				case (Class11.Enum3)44:
				{
					bool flag42 = Class11.list_0.Count != 0;
					if (flag42)
					{
						this.class36_0.method_2(new Class11.Class35(Class11.list_0[(int)this.object_0]));
					}
					else
					{
						Module module2 = typeof(Class11).Module;
						this.class36_0.method_2(new Class11.Class35(module2.ResolveString((int)this.object_0 | 1879048192)));
					}
					break;
				}
				case (Class11.Enum3)45:
				{
					int metadataToken11 = (int)this.object_0;
					typeof(Class11).Module.ResolveType(metadataToken11);
					Class11.Class23 class48 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Array array_ = (Array)this.class36_0.method_4().vmethod_4(null);
					this.class36_0.method_2(new Class11.Class30(class48.vmethod_19().struct1_0.int_0, array_));
					break;
				}
				case (Class11.Enum3)46:
				{
					Class11.Class23 class49 = Class11.Class20.smethod_1(this.class36_0.method_4());
					object value4 = ((Array)this.class36_0.method_4().vmethod_4(null)).GetValue(class49.vmethod_19().struct1_0.int_0);
					this.class36_0.method_2(Class11.Class22.smethod_1(typeof(byte), value4));
					break;
				}
				case (Class11.Enum3)47:
				{
					Class11.Class22 class50 = this.class36_0.method_4();
					Class11.Class23 class51 = Class11.Class20.smethod_1(class50);
					bool flag43 = class50 != null && class50.vmethod_0() && class51 != null;
					if (flag43)
					{
						this.class36_0.method_2(class51.vmethod_25());
					}
					else
					{
						bool flag44 = class51 != null && class51.method_2();
						if (!flag44)
						{
							throw new Class11.Exception1();
						}
						IntPtr value5 = ((Class11.Class26)class51).method_7();
						this.class36_0.method_2(new Class11.Class24(*(int*)((void*)value5), (Class11.Enum1)5));
					}
					break;
				}
				case (Class11.Enum3)48:
				{
					Class11.Class23 class52 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class53 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag45 = class53 != null && class52 != null;
					if (!flag45)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class53.vmethod_57(class52));
					break;
				}
				case (Class11.Enum3)49:
				{
					Class11.Class22 class54 = this.class36_0.method_4();
					bool flag46 = class54.vmethod_3();
					if (flag46)
					{
						class54 = ((Class11.Class23)class54).vmethod_50();
					}
					this.class36_0.method_4().vmethod_2(class54);
					break;
				}
				case (Class11.Enum3)50:
				{
					Class11.Class23 class55 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag47 = class55 != null;
					if (!flag47)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class55.vmethod_51());
					break;
				}
				case (Class11.Enum3)52:
				{
					Class11.Class23 class56 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class57 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag48 = class57 != null && class56 != null;
					if (!flag48)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class57.vmethod_67(class56));
					break;
				}
				case (Class11.Enum3)53:
				{
					Class11.Class23 class58 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class59 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag49 = class59 != null && class58 != null;
					if (!flag49)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class59.vmethod_77(class58));
					break;
				}
				case (Class11.Enum3)54:
				{
					Array array4 = (Array)this.class36_0.method_4().vmethod_4(null);
					this.class36_0.method_2(new Class11.Class24(array4.Length, (Class11.Enum1)5));
					break;
				}
				case (Class11.Enum3)55:
					this.int_0 = (int)this.object_0 - 1;
					this.bool_0 = true;
					break;
				case (Class11.Enum3)56:
				{
					bool flag50 = this.class36_0.method_4().vmethod_6(this.class36_0.method_4());
					if (flag50)
					{
						this.int_0 = (int)this.object_0 - 1;
					}
					break;
				}
				case (Class11.Enum3)57:
				{
					Class11.Class23 class60 = this.class36_0.method_4() as Class11.Class23;
					Class11.Class23 class61 = this.class36_0.method_4() as Class11.Class23;
					IntPtr intPtr2 = Class11.Class20.smethod_8(this.class36_0.method_4());
					bool flag51 = intPtr2 != IntPtr.Zero;
					if (flag51)
					{
						byte byte_ = class61.vmethod_16().struct1_0.byte_0;
						uint uint_2 = class60.vmethod_20().struct1_0.uint_0;
						Class11.Class20.smethod_10(intPtr2, byte_, (int)uint_2);
					}
					break;
				}
				case (Class11.Enum3)58:
				{
					Class11.Class23 class62 = Class11.Class20.smethod_1(this.class36_0.method_4());
					object value6 = ((Array)this.class36_0.method_4().vmethod_4(null)).GetValue(class62.vmethod_19().struct1_0.int_0);
					this.class36_0.method_2(Class11.Class22.smethod_1(typeof(sbyte), value6));
					break;
				}
				case (Class11.Enum3)59:
					this.class36_0.method_2(((Class11.Class23)this.class36_0.method_4()).vmethod_56());
					break;
				case (Class11.Enum3)60:
				{
					Class11.Class22 class63 = this.class36_0.method_4();
					Class11.Class23 class64 = Class11.Class20.smethod_1(class63);
					bool flag52 = class63 != null && class63.vmethod_0() && class64 != null;
					if (flag52)
					{
						this.class36_0.method_2(class64.vmethod_28());
					}
					else
					{
						bool flag53 = class64 != null && class64.method_2();
						if (!flag53)
						{
							throw new Class11.Exception1();
						}
						IntPtr value7 = ((Class11.Class26)class64).method_7();
						this.class36_0.method_2(new Class11.Class24((int)(*(ushort*)((void*)value7)), (Class11.Enum1)4));
					}
					break;
				}
				case (Class11.Enum3)63:
				{
					Class11.Class23 class65 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag54 = class65 != null;
					if (!flag54)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class65.vmethod_39());
					break;
				}
				case (Class11.Enum3)64:
				{
					Class11.Class23 class66 = Class11.Class20.smethod_1(this.class36_0.method_4());
					object value8 = ((Array)this.class36_0.method_4().vmethod_4(null)).GetValue(class66.vmethod_19().struct1_0.int_0);
					this.class36_0.method_2(Class11.Class22.smethod_1(typeof(long), value8));
					break;
				}
				case (Class11.Enum3)66:
				{
					Class11.Class23 class67 = Class11.Class20.smethod_1(this.class36_0.method_4());
					object value9 = ((Array)this.class36_0.method_4().vmethod_4(null)).GetValue(class67.vmethod_19().struct1_0.int_0);
					this.class36_0.method_2(Class11.Class22.smethod_1(typeof(ushort), value9));
					break;
				}
				case (Class11.Enum3)68:
				{
					Class11.Class23 class68 = Class11.Class20.smethod_1(this.class36_0.method_4());
					object value10 = ((Array)this.class36_0.method_4().vmethod_4(null)).GetValue(class68.vmethod_19().struct1_0.int_0);
					this.class36_0.method_2(Class11.Class22.smethod_1(typeof(uint), value10));
					break;
				}
				case (Class11.Enum3)69:
				{
					Class11.Class23 class69 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class70 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag55 = class70 != null && class69 != null;
					if (!flag55)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class70.vmethod_64(class69));
					break;
				}
				case (Class11.Enum3)71:
					this.class36_0.method_2(this.class22_0[(int)this.object_0]);
					break;
				case (Class11.Enum3)72:
					this.class36_0.method_2(this.class36_0.method_4().vmethod_8());
					break;
				case (Class11.Enum3)73:
				{
					Class11.Class23 class71 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag56 = class71 != null;
					if (!flag56)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class71.vmethod_47());
					break;
				}
				case (Class11.Enum3)74:
				{
					int metadataToken12 = (int)this.object_0;
					Type type_ = typeof(Class11).Module.ResolveType(metadataToken12);
					Class11.Class23 class72 = Class11.Class20.smethod_1(this.class36_0.method_4());
					object value11 = ((Array)this.class36_0.method_4().vmethod_4(null)).GetValue(class72.vmethod_19().struct1_0.int_0);
					this.class36_0.method_2(Class11.Class22.smethod_1(type_, value11));
					break;
				}
				case (Class11.Enum3)75:
				{
					Class11.Class23 class73 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class74 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag57 = class73 != null && class74 != null;
					if (!flag57)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class73.vmethod_70(class74));
					break;
				}
				case (Class11.Enum3)76:
					throw this.exception_0;
				case (Class11.Enum3)77:
				{
					int metadataToken13 = (int)this.object_0;
					FieldInfo fieldInfo3 = typeof(Class11).Module.ResolveField(metadataToken13);
					object value12 = this.class36_0.method_4().vmethod_4(fieldInfo3.FieldType);
					fieldInfo3.SetValue(null, value12);
					break;
				}
				case (Class11.Enum3)78:
					this.class36_0.method_2(new Class11.Class29((int)this.object_0, this));
					break;
				case (Class11.Enum3)79:
				{
					Class11.Class23 class75 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class76 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag58 = class76 != null && class75 != null;
					if (!flag58)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class76.vmethod_68(class75));
					break;
				}
				case (Class11.Enum3)80:
				{
					Class11.Class23 class77 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class78 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag59 = class78 != null && class77 != null;
					if (!flag59)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class78.vmethod_66(class77));
					break;
				}
				case (Class11.Enum3)81:
				{
					Class11.Class22 value13 = this.class36_0.method_4();
					object key = this.class36_0.method_4().vmethod_4(null);
					Class11.Class20.dictionary_1[key] = value13;
					break;
				}
				case (Class11.Enum3)82:
				{
					Class11.Class23 class79 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag60 = class79 == null;
					if (flag60)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class79.vmethod_50());
					break;
				}
				case (Class11.Enum3)83:
					this.class36_0.method_2(new Class11.Class32((int)this.object_0, this));
					break;
				case (Class11.Enum3)84:
				{
					Class11.Class23 class80 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag61 = class80 != null;
					if (!flag61)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class80.vmethod_72());
					break;
				}
				case (Class11.Enum3)85:
				{
					Class11.Class22 class81 = this.class36_0.method_4();
					bool flag62 = class81 != null && class81.vmethod_7();
					if (flag62)
					{
						this.int_0 = (int)this.object_0 - 1;
					}
					break;
				}
				case (Class11.Enum3)86:
					this.class36_0.method_2(new Class11.Class27((float)this.object_0));
					break;
				case (Class11.Enum3)87:
				{
					Class11.Class23 class82 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag63 = class82 == null;
					if (flag63)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class82.vmethod_32());
					break;
				}
				case (Class11.Enum3)89:
				{
					Class11.Class23 class83 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag64 = class83 == null;
					if (flag64)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class83.vmethod_54());
					break;
				}
				case (Class11.Enum3)90:
					this.class36_0.method_2(new Class11.Class27((double)this.object_0));
					break;
				case (Class11.Enum3)91:
				{
					Class11.Class23 class84 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class85 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag65 = class85 != null && class84 != null;
					if (!flag65)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class85.vmethod_65(class84));
					break;
				}
				case (Class11.Enum3)92:
				{
					Class11.Class23 class86 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag66 = class86 != null;
					if (!flag66)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class86.vmethod_30());
					break;
				}
				case (Class11.Enum3)93:
				{
					Class11.Class22 class87 = this.class22_1[(int)this.object_0];
					this.class36_0.method_2(class87);
					break;
				}
				case (Class11.Enum3)94:
				{
					Class11.Class23 class88 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class89 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag67 = class89 != null && class88 != null;
					if (!flag67)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class89.vmethod_63(class88));
					break;
				}
				case (Class11.Enum3)95:
					this.class36_0.method_2(new Class11.Class34(null));
					break;
				case (Class11.Enum3)96:
				{
					Class11.Class22 class90 = this.class36_0.method_4();
					bool flag68 = Class11.Class20.smethod_1(this.class36_0.method_4()).vmethod_78(class90);
					if (flag68)
					{
						this.int_0 = (int)this.object_0 - 1;
					}
					break;
				}
				case (Class11.Enum3)97:
				{
					int metadataToken14 = (int)this.object_0;
					FieldInfo fieldInfo_2 = typeof(Class11).Module.ResolveField(metadataToken14);
					Class11.Class22 class91 = this.class36_0.method_4();
					class91.vmethod_8();
					object object_ = class91.vmethod_4(null);
					this.class36_0.method_2(new Class11.Class31(fieldInfo_2, object_));
					break;
				}
				case (Class11.Enum3)98:
				{
					Class11.Class23 class92 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class93 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag69 = class92 != null && class93 != null;
					if (!flag69)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class92.vmethod_73(class93));
					break;
				}
				case (Class11.Enum3)99:
				{
					Class11.Class23 class94 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag70 = class94 != null;
					if (!flag70)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class94.vmethod_23());
					break;
				}
				case (Class11.Enum3)100:
				{
					Class11.Class23 class95 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag71 = class95 != null;
					if (!flag71)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class95.vmethod_26());
					break;
				}
				case (Class11.Enum3)102:
				{
					Class11.Class23 class96 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Array array5 = (Array)this.class36_0.method_4().vmethod_4(null);
					object value14 = array5.GetValue(class96.vmethod_19().struct1_0.int_0);
					Type elementType3 = array5.GetType().GetElementType();
					this.class36_0.method_2(Class11.Class22.smethod_1(elementType3, value14));
					break;
				}
				case (Class11.Enum3)103:
				{
					Class11.Class22 class97 = this.class36_0.method_4();
					Class11.Class23 class98 = Class11.Class20.smethod_1(class97);
					bool flag72 = class97 != null && class97.vmethod_0() && class98 != null;
					if (flag72)
					{
						this.class36_0.method_2(class98.vmethod_47());
					}
					else
					{
						bool flag73 = class98 != null && class98.method_2();
						if (!flag73)
						{
							throw new Class11.Exception1();
						}
						IntPtr value15 = ((Class11.Class26)class98).method_7();
						this.class36_0.method_2(new Class11.Class27(*(float*)((void*)value15), (Class11.Enum1)9));
					}
					break;
				}
				case (Class11.Enum3)105:
					this.class36_0.method_4();
					break;
				case (Class11.Enum3)106:
				{
					Class11.Class23 class99 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag74 = class99 == null;
					if (flag74)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class99.vmethod_40());
					break;
				}
				case (Class11.Enum3)108:
				{
					Class11.Class22 class100 = this.class36_0.method_4();
					Class11.Class23 class101 = Class11.Class20.smethod_1(class100);
					bool flag75 = class100 != null && class100.vmethod_0() && class101 != null;
					if (flag75)
					{
						this.class36_0.method_2(class101.vmethod_27());
					}
					else
					{
						bool flag76 = class101 != null && class101.method_2();
						if (!flag76)
						{
							throw new Class11.Exception1();
						}
						IntPtr value16 = ((Class11.Class26)class101).method_7();
						this.class36_0.method_2(new Class11.Class24((int)(*(byte*)((void*)value16)), (Class11.Enum1)2));
					}
					break;
				}
				case (Class11.Enum3)110:
					this.class36_0.method_2(new Class11.Class25((long)this.object_0));
					break;
				case (Class11.Enum3)111:
				{
					Class11.Class23 class102 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag77 = class102 != null;
					if (!flag77)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class102.vmethod_42());
					break;
				}
				case (Class11.Enum3)112:
				{
					Class11.Class22 class103 = this.class36_0.method_4();
					bool flag78 = class103 == null || !class103.vmethod_7();
					if (flag78)
					{
						this.int_0 = (int)this.object_0 - 1;
					}
					break;
				}
				case (Class11.Enum3)113:
				{
					Class11.Class23 class104 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class105 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag79 = class104 != null && class105 != null;
					if (!flag79)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class104.vmethod_71(class105));
					break;
				}
				case (Class11.Enum3)114:
				{
					Class11.Class22 class106 = this.class36_0.method_4();
					Class11.Class23 class107 = Class11.Class20.smethod_1(class106);
					bool flag80 = class106 != null && class106.vmethod_0() && class107 != null;
					if (flag80)
					{
						this.class36_0.method_2(class107.vmethod_48());
					}
					else
					{
						bool flag81 = class107 != null && class107.method_2();
						if (!flag81)
						{
							throw new Class11.Exception1();
						}
						IntPtr value17 = ((Class11.Class26)class107).method_7();
						this.class36_0.method_2(new Class11.Class27(*(double*)((void*)value17), (Class11.Enum1)10));
					}
					break;
				}
				case (Class11.Enum3)115:
					throw (Exception)this.class36_0.method_4().vmethod_4(null);
				case (Class11.Enum3)116:
				{
					Class11.Class22 class108 = this.class36_0.method_4();
					Class11.Class23 class109 = Class11.Class20.smethod_1(class108);
					bool flag82 = class108 != null && class108.vmethod_0() && class109 != null;
					if (flag82)
					{
						this.class36_0.method_2(class109.vmethod_29());
					}
					else
					{
						bool flag83 = class109 != null && class109.method_2();
						if (!flag83)
						{
							throw new Class11.Exception1();
						}
						IntPtr value18 = ((Class11.Class26)class109).method_7();
						this.class36_0.method_2(new Class11.Class24(*(uint*)((void*)value18), (Class11.Enum1)6));
					}
					break;
				}
				case (Class11.Enum3)117:
				{
					Class11.Class23 class110 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag84 = class110 == null;
					if (flag84)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class110.vmethod_28());
					break;
				}
				case (Class11.Enum3)118:
				{
					Class11.Class23 class111 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class112 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag85 = class112 != null && class111 != null;
					if (!flag85)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class112.vmethod_60(class111));
					break;
				}
				case (Class11.Enum3)119:
				{
					Class11.Class23 class113 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class114 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag86 = class114 != null && class113 != null;
					if (!flag86)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class114.vmethod_59(class113));
					break;
				}
				case (Class11.Enum3)120:
				{
					Class11.Class23 class115 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag87 = class115 != null;
					if (!flag87)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class115.vmethod_48());
					break;
				}
				case (Class11.Enum3)122:
				{
					Class11.Class23 class116 = Class11.Class20.smethod_1(this.class36_0.method_4());
					object value19 = ((Array)this.class36_0.method_4().vmethod_4(null)).GetValue(class116.vmethod_19().struct1_0.int_0);
					this.class36_0.method_2(Class11.Class22.smethod_1(typeof(IntPtr), value19));
					break;
				}
				case (Class11.Enum3)123:
				{
					int metadataToken15 = (int)this.object_0;
					Type type_2 = typeof(Class11).Module.ResolveType(metadataToken15);
					Class11.Class22 class117 = this.class36_0.method_4();
					Class11.Class23 class118 = Class11.Class20.smethod_1(this.class36_0.method_4());
					((Array)this.class36_0.method_4().vmethod_4(null)).SetValue(class117.vmethod_4(type_2), class118.vmethod_19().struct1_0.int_0);
					break;
				}
				case (Class11.Enum3)124:
				{
					Class11.Class23 class119 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class120 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag88 = class120 != null && class119 != null;
					if (!flag88)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class120.vmethod_58(class119));
					break;
				}
				case (Class11.Enum3)125:
				{
					Class11.Class23 class121 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag89 = class121 != null;
					if (!flag89)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class121.vmethod_53());
					break;
				}
				case (Class11.Enum3)126:
				{
					int metadataToken16 = (int)this.object_0;
					Type type_3 = typeof(Class11).Module.ResolveType(metadataToken16);
					object obj6 = this.class36_0.method_4().vmethod_8().vmethod_4(type_3);
					Class11.Class22 class122 = Class11.Class22.smethod_1(type_3, obj6);
					this.class36_0.method_2(class122);
					break;
				}
				case (Class11.Enum3)128:
				{
					Class11.Class22 class123 = this.class36_0.method_4();
					Class11.Class23 class124 = Class11.Class20.smethod_1(class123);
					bool flag90 = class123 != null && class123.vmethod_0() && class124 != null;
					if (flag90)
					{
						this.class36_0.method_2(class124.vmethod_24());
					}
					else
					{
						bool flag91 = class124 != null && class124.method_2();
						if (!flag91)
						{
							throw new Class11.Exception1();
						}
						IntPtr value20 = ((Class11.Class26)class124).method_7();
						this.class36_0.method_2(new Class11.Class24((int)(*(short*)((void*)value20)), (Class11.Enum1)3));
					}
					break;
				}
				case (Class11.Enum3)129:
				{
					Class11.Class23 class125 = Class11.Class20.smethod_1(this.class36_0.method_4());
					object value21 = ((Array)this.class36_0.method_4().vmethod_4(null)).GetValue(class125.vmethod_19().struct1_0.int_0);
					this.class36_0.method_2(Class11.Class22.smethod_1(typeof(short), value21));
					break;
				}
				case (Class11.Enum3)130:
				{
					Class11.Class22 class126 = this.class36_0.method_4();
					bool flag92 = Class11.Class20.smethod_1(this.class36_0.method_4()).vmethod_85(class126);
					bool flag93 = !flag92;
					if (flag93)
					{
						this.class36_0.method_2(new Class11.Class24(0));
					}
					else
					{
						this.class36_0.method_2(new Class11.Class24(1));
					}
					bool flag94 = flag92;
					if (flag94)
					{
						this.int_0 = (int)this.object_0 - 1;
					}
					break;
				}
				case (Class11.Enum3)131:
				{
					int metadataToken17 = (int)this.object_0;
					FieldInfo fieldInfo4 = typeof(Class11).Module.ResolveField(metadataToken17);
					object obj7 = this.class36_0.method_4().vmethod_4(null);
					this.class36_0.method_2(Class11.Class22.smethod_1(fieldInfo4.FieldType, fieldInfo4.GetValue(obj7)));
					break;
				}
				case (Class11.Enum3)132:
				{
					int metadataToken18 = (int)this.object_0;
					ConstructorInfo constructorInfo = (ConstructorInfo)typeof(Class11).Module.ResolveMethod(metadataToken18);
					ParameterInfo[] parameters = constructorInfo.GetParameters();
					object[] array6 = new object[parameters.Length];
					Class11.Class22[] array7 = new Class11.Class22[parameters.Length];
					List<Class11.Class18> list = null;
					Class11.Class19 class127 = null;
					int num2;
					for (int i = 0; i < parameters.Length; i = num2 + 1)
					{
						Class11.Class22 class128 = this.class36_0.method_4();
						Type type6 = parameters[parameters.Length - 1 - i].ParameterType;
						object obj8 = null;
						bool flag95 = false;
						Class11.Class31 class129;
						bool flag96;
						if (type6.IsByRef)
						{
							class129 = (class128 as Class11.Class31);
							flag96 = (class129 != null);
						}
						else
						{
							flag96 = false;
						}
						bool flag97 = flag96;
						if (flag97)
						{
							bool flag98 = list == null;
							if (flag98)
							{
								list = new List<Class11.Class18>();
							}
							list.Add(new Class11.Class18(class129.fieldInfo_0, i));
							obj8 = class129.object_0;
							bool flag99 = !(obj8 is Class11.Class22);
							if (flag99)
							{
								flag95 = true;
							}
							else
							{
								class128 = (obj8 as Class11.Class22);
							}
						}
						bool flag100 = !flag95;
						if (flag100)
						{
							bool flag101 = class128 != null;
							if (flag101)
							{
								obj8 = class128.vmethod_4(type6);
							}
							bool flag102 = obj8 == null;
							if (flag102)
							{
								bool isByRef2 = type6.IsByRef;
								if (isByRef2)
								{
									type6 = type6.GetElementType();
								}
								bool isValueType5 = type6.IsValueType;
								if (isValueType5)
								{
									obj8 = Activator.CreateInstance(type6);
									bool flag103 = class128 is Class11.Class29;
									if (flag103)
									{
										((Class11.Class28)class128).vmethod_12(Class11.Class22.smethod_1(type6, obj8));
									}
								}
							}
						}
						array7[array6.Length - 1 - i] = class128;
						array6[array6.Length - 1 - i] = obj8;
						num2 = i;
					}
					Class11.Delegate10 @delegate = null;
					bool flag104 = list != null;
					if (flag104)
					{
						class127 = new Class11.Class19(constructorInfo, list);
						@delegate = Class11.Class20.smethod_4(constructorInfo, true, class127);
					}
					object obj9 = (@delegate == null) ? constructorInfo.Invoke(array6) : @delegate(null, array6);
					for (int j = 0; j < parameters.Length; j = num2 + 1)
					{
						bool flag105 = parameters[j].ParameterType.IsByRef && (class127 == null || !class127.method_1(j));
						if (flag105)
						{
							bool flag106 = array7[j].method_2();
							if (flag106)
							{
								((Class11.Class26)array7[j]).method_6(Class11.Class22.smethod_1(parameters[j].ParameterType, array6[j]));
							}
							else
							{
								bool flag107 = array7[j] is Class11.Class29;
								if (flag107)
								{
									array7[j].vmethod_10(Class11.Class22.smethod_1(parameters[j].ParameterType.GetElementType(), array6[j]));
								}
								else
								{
									array7[j].vmethod_10(Class11.Class22.smethod_1(parameters[j].ParameterType, array6[j]));
								}
							}
						}
						num2 = j;
					}
					this.class36_0.method_2(Class11.Class22.smethod_1(constructorInfo.DeclaringType, obj9));
					break;
				}
				case (Class11.Enum3)133:
				{
					Class11.Class22 class130 = this.class36_0.method_4();
					Class11.Class23 class131 = Class11.Class20.smethod_1(class130);
					bool flag108 = class130 != null && class130.vmethod_0() && class131 != null;
					if (flag108)
					{
						this.class36_0.method_2(class131.vmethod_26());
					}
					else
					{
						bool flag109 = class131 != null && class131.method_2();
						if (!flag109)
						{
							throw new Class11.Exception1();
						}
						IntPtr value22 = ((Class11.Class26)class131).method_7();
						this.class36_0.method_2(new Class11.Class25(*(long*)((void*)value22), (Class11.Enum1)7));
					}
					break;
				}
				case (Class11.Enum3)134:
					this.method_12(true);
					break;
				case (Class11.Enum3)136:
				{
					Class11.Class23 class132 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag110 = class132 != null;
					if (!flag110)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class132.vmethod_33());
					break;
				}
				case (Class11.Enum3)138:
				{
					Class11.Class22 class133 = this.class36_0.method_4();
					bool flag111 = class133.vmethod_3();
					if (flag111)
					{
						class133 = ((Class11.Class23)class133).vmethod_48();
					}
					this.class36_0.method_4().vmethod_2(class133);
					break;
				}
				case (Class11.Enum3)140:
					this.int_0 = (int)this.object_0 - 1;
					break;
				case (Class11.Enum3)141:
				{
					Class11.Class23 class134 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class135 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag112 = class135 != null && class134 != null;
					if (!flag112)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class135.vmethod_62(class134));
					break;
				}
				case (Class11.Enum3)142:
				{
					Class11.Class22 class136 = this.class36_0.method_4();
					bool flag113 = Class11.Class20.smethod_1(this.class36_0.method_4()).vmethod_80(class136);
					if (flag113)
					{
						this.class36_0.method_2(new Class11.Class24(1));
					}
					else
					{
						this.class36_0.method_2(new Class11.Class24(0));
					}
					break;
				}
				case (Class11.Enum3)145:
				{
					Class11.Class23 class137 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag114 = class137 != null;
					if (!flag114)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class137.vmethod_55());
					break;
				}
				case (Class11.Enum3)146:
				{
					Class11.Class22 class138 = this.class36_0.method_4();
					bool flag115 = class138.vmethod_0();
					if (!flag115)
					{
						throw new Class11.Exception1();
					}
					object obj10 = class138.vmethod_4(null);
					class138 = ((obj10 != null) ? Class11.Class22.smethod_1(obj10.GetType(), obj10) : new Class11.Class34(null));
					this.class36_0.method_2(class138);
					break;
				}
				case (Class11.Enum3)147:
				{
					Class11.Class22 class139 = this.class36_0.method_4();
					bool flag116 = class139.vmethod_3();
					if (flag116)
					{
						class139 = ((Class11.Class23)class139).vmethod_25();
					}
					this.class36_0.method_4().vmethod_2(class139);
					break;
				}
				case (Class11.Enum3)148:
				{
					object key2 = this.class36_0.method_4().vmethod_4(null);
					Class11.Class22 class140 = null;
					bool flag117 = Class11.Class20.dictionary_1.TryGetValue(key2, out class140);
					if (flag117)
					{
						this.class36_0.method_2(class140);
					}
					else
					{
						this.class36_0.method_2(new Class11.Class34(null));
					}
					break;
				}
				case (Class11.Enum3)149:
				{
					Class11.Class23 class141 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag118 = class141 != null;
					if (!flag118)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class141.vmethod_24());
					break;
				}
				case (Class11.Enum3)150:
				{
					Class11.Class23 class142 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag119 = class142 != null;
					if (!flag119)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class142.vmethod_45());
					break;
				}
				case (Class11.Enum3)151:
				{
					Class11.Class23 class143 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag120 = class143 == null;
					if (flag120)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class143.vmethod_37());
					break;
				}
				case (Class11.Enum3)153:
				{
					int num3 = (int)this.object_0;
					this.class22_1[num3] = this.method_8(this.class36_0.method_4(), this.class17_0.list_1[num3].enum1_0, this.class17_0.list_1[num3].bool_0);
					break;
				}
				case (Class11.Enum3)154:
				{
					Type type7 = typeof(Class11).Module.ResolveType((int)this.object_0);
					object obj11 = this.class36_0.method_4().vmethod_4(type7);
					bool flag121 = obj11 == null;
					if (flag121)
					{
						obj11 = Activator.CreateInstance(type7);
					}
					this.class36_0.method_2(new Class11.Class34(Class11.Class22.smethod_1(type7, Class11.Class20.smethod_9(obj11))));
					break;
				}
				case (Class11.Enum3)155:
					this.class36_0.method_2(new Class11.Class24((int)this.object_0));
					break;
				case (Class11.Enum3)156:
				{
					Class11.Class22 class144 = this.class36_0.method_4();
					bool flag122 = class144.vmethod_3();
					if (flag122)
					{
						class144 = ((Class11.Class23)class144).vmethod_47();
					}
					this.class36_0.method_4().vmethod_2(class144);
					break;
				}
				case (Class11.Enum3)157:
				{
					Class11.Class23 class145 = Class11.Class20.smethod_1(this.class36_0.method_4());
					Class11.Class23 class146 = (Class11.Class23)this.class36_0.method_4();
					bool flag123 = class146 != null && class145 != null;
					if (!flag123)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class146.vmethod_61(class145));
					break;
				}
				case (Class11.Enum3)158:
				{
					int num4 = (int)this.object_0;
					bool flag124 = !((MethodBase)this.class17_0.object_0).IsStatic;
					if (flag124)
					{
						this.class22_0[num4] = this.method_8(this.class36_0.method_4(), this.class17_0.class13_0[num4 - 1].enum1_0, false);
					}
					else
					{
						this.class22_0[num4] = this.method_8(this.class36_0.method_4(), this.class17_0.class13_0[num4].enum1_0, false);
					}
					break;
				}
				case (Class11.Enum3)159:
				{
					Class11.Class23 class147 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag125 = class147 == null;
					if (flag125)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class147.vmethod_25());
					break;
				}
				case (Class11.Enum3)160:
				{
					Class11.Class23 class148 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag126 = class148 != null;
					if (!flag126)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class148.vmethod_31());
					break;
				}
				case (Class11.Enum3)161:
				{
					Class11.Class23 class149 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag127 = class149 == null;
					if (flag127)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class149.vmethod_43());
					break;
				}
				case (Class11.Enum3)162:
				{
					Class11.Class22 class150 = this.class36_0.method_4();
					Class11.Class23 class151 = Class11.Class20.smethod_1(class150);
					bool flag128 = class150 != null && class150.vmethod_0() && class151 != null;
					if (flag128)
					{
						this.class36_0.method_2(class151.vmethod_23());
					}
					else
					{
						bool flag129 = class151 != null && class151.method_2();
						if (!flag129)
						{
							throw new Class11.Exception1();
						}
						IntPtr value23 = ((Class11.Class26)class151).method_7();
						this.class36_0.method_2(new Class11.Class24((int)(*(sbyte*)((void*)value23)), (Class11.Enum1)1));
					}
					break;
				}
				case (Class11.Enum3)163:
				{
					Class11.Class23 class152 = this.class36_0.method_4() as Class11.Class23;
					IntPtr intPtr3 = Class11.Class20.smethod_8(this.class36_0.method_4());
					IntPtr intPtr4 = Class11.Class20.smethod_8(this.class36_0.method_4());
					bool flag130 = intPtr3 != IntPtr.Zero && intPtr4 != IntPtr.Zero;
					if (flag130)
					{
						uint uint_3 = class152.vmethod_20().struct1_0.uint_0;
						Class11.Class20.smethod_11(intPtr4, intPtr3, uint_3);
					}
					break;
				}
				case (Class11.Enum3)164:
				{
					Class11.Class22 class153 = this.class36_0.method_4();
					bool flag131 = Class11.Class20.smethod_1(this.class36_0.method_4()).vmethod_83(class153);
					if (flag131)
					{
						this.int_0 = (int)this.object_0 - 1;
					}
					break;
				}
				case (Class11.Enum3)165:
				{
					Class11.Class23 class154 = Class11.Class20.smethod_1(this.class36_0.method_4());
					object value24 = ((Array)this.class36_0.method_4().vmethod_4(null)).GetValue(class154.vmethod_19().struct1_0.int_0);
					this.class36_0.method_2(Class11.Class22.smethod_1(typeof(double), value24));
					break;
				}
				case (Class11.Enum3)166:
				{
					Class11.Class22 class155 = this.class36_0.method_4();
					bool flag132 = Class11.Class20.smethod_1(this.class36_0.method_4()).vmethod_82(class155);
					if (flag132)
					{
						this.int_0 = (int)this.object_0 - 1;
					}
					break;
				}
				case (Class11.Enum3)167:
				{
					Class11.Class22 class156 = this.class36_0.method_4();
					bool flag133 = Class11.Class20.smethod_1(this.class36_0.method_4()).vmethod_79(class156);
					if (flag133)
					{
						this.int_0 = (int)this.object_0 - 1;
					}
					break;
				}
				case (Class11.Enum3)168:
				{
					Class11.Class23 class157 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag134 = class157 != null;
					if (!flag134)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class157.vmethod_38());
					break;
				}
				case (Class11.Enum3)169:
				{
					Class11.Class22 class158 = this.class36_0.method_4();
					bool flag135 = Class11.Class20.smethod_1(this.class36_0.method_4()).vmethod_84(class158);
					if (flag135)
					{
						this.int_0 = (int)this.object_0 - 1;
					}
					break;
				}
				case (Class11.Enum3)170:
				{
					Class11.Class22 class159 = this.class36_0.method_4();
					Class11.Class23 class160 = Class11.Class20.smethod_1(class159);
					bool flag136 = class159 != null && class159.vmethod_0() && class160 != null;
					if (flag136)
					{
						this.class36_0.method_2(class160.vmethod_50());
					}
					else
					{
						bool flag137 = class160 != null && class160.method_2();
						if (!flag137)
						{
							throw new Class11.Exception1();
						}
						IntPtr value25 = ((Class11.Class26)class160).method_7();
						bool flag138 = IntPtr.Size == 8;
						if (flag138)
						{
							long long_ = *(long*)((void*)value25);
							this.class36_0.method_2(new Class11.Class26(long_, (Class11.Enum1)12));
						}
						else
						{
							int num5 = *(int*)((void*)value25);
							this.class36_0.method_2(new Class11.Class26((long)num5, (Class11.Enum1)12));
						}
					}
					break;
				}
				case (Class11.Enum3)171:
				{
					Class11.Class23 class161 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag139 = class161 == null;
					if (flag139)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class161.vmethod_34());
					break;
				}
				case (Class11.Enum3)172:
				{
					int metadataToken19 = (int)this.object_0;
					Module module3 = typeof(Class11).Module;
					object obj12 = null;
					try
					{
						obj12 = module3.ResolveType(metadataToken19);
					}
					catch
					{
						try
						{
							obj12 = module3.ResolveMethod(metadataToken19);
						}
						catch
						{
							try
							{
								obj12 = module3.ResolveField(metadataToken19);
							}
							catch
							{
								obj12 = module3.ResolveMember(metadataToken19);
							}
						}
					}
					this.class36_0.method_2(new Class11.Class34(obj12));
					break;
				}
				case (Class11.Enum3)173:
				{
					Class11.Class23 class162 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag140 = class162 != null;
					if (!flag140)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class162.vmethod_27());
					break;
				}
				case (Class11.Enum3)174:
				{
					Class11.Class23 class163 = Class11.Class20.smethod_1(this.class36_0.method_4());
					bool flag141 = class163 == null;
					if (flag141)
					{
						throw new Class11.Exception1();
					}
					this.class36_0.method_2(class163.vmethod_52());
					break;
				}
				case (Class11.Enum3)175:
				{
					Class11.Class22 class164 = this.class36_0.method_4();
					bool flag142 = class164.vmethod_3();
					if (flag142)
					{
						class164 = ((Class11.Class23)class164).vmethod_26();
					}
					this.class36_0.method_4().vmethod_2(class164);
					break;
				}
				}
			}

			// Token: 0x06000262 RID: 610 RVA: 0x000108BC File Offset: 0x0000EABC
			private Class11.Class22 method_8(Class11.Class22 class22_3, Class11.Enum1 enum1_0, bool bool_4 = false)
			{
				bool flag = !bool_4 && class22_3.vmethod_0();
				if (flag)
				{
					class22_3 = class22_3.vmethod_8();
				}
				bool flag2 = !class22_3.method_1();
				Class11.Class22 result;
				if (flag2)
				{
					bool flag3 = !class22_3.method_3();
					if (flag3)
					{
						bool flag4 = !class22_3.method_4();
						if (flag4)
						{
							bool flag5 = !class22_3.method_2();
							if (flag5)
							{
								result = class22_3;
							}
							else
							{
								result = ((Class11.Class26)class22_3).vmethod_13(enum1_0);
							}
						}
						else
						{
							result = ((Class11.Class27)class22_3).vmethod_13(enum1_0);
						}
					}
					else
					{
						result = ((Class11.Class25)class22_3).vmethod_13(enum1_0);
					}
				}
				else
				{
					result = ((Class11.Class24)class22_3).vmethod_13(enum1_0);
				}
				return result;
			}

			// Token: 0x06000263 RID: 611 RVA: 0x00010968 File Offset: 0x0000EB68
			private Class11.Class22 method_9(int int_3)
			{
				return this.class22_1[int_3];
			}

			// Token: 0x06000264 RID: 612 RVA: 0x0000276F File Offset: 0x0000096F
			private void method_10(int int_3)
			{
				this.method_11(int_3, this.class36_0.method_4());
			}

			// Token: 0x06000265 RID: 613 RVA: 0x00010984 File Offset: 0x0000EB84
			private static int smethod_0(Type type_0)
			{
				bool flag = Class11.Class20.dictionary_0 == null;
				if (flag)
				{
					Class11.Class20.dictionary_0 = new Dictionary<Type, int>();
				}
				int result;
				try
				{
					int num = 0;
					bool flag2 = !Class11.Class20.dictionary_0.TryGetValue(type_0, out num);
					if (flag2)
					{
						DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(int), Type.EmptyTypes, true);
						ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
						ilgenerator.Emit(OpCodes.Sizeof, type_0);
						ilgenerator.Emit(OpCodes.Ret);
						num = (int)dynamicMethod.Invoke(null, null);
						Class11.Class20.dictionary_0[type_0] = num;
						result = num;
					}
					else
					{
						result = num;
					}
				}
				catch
				{
					result = 0;
				}
				return result;
			}

			// Token: 0x06000266 RID: 614 RVA: 0x00002785 File Offset: 0x00000985
			private void method_11(int int_3, Class11.Class22 class22_3)
			{
				this.class22_1[int_3] = this.method_8(class22_3, this.class17_0.list_1[int_3].enum1_0, this.class17_0.list_1[int_3].bool_0);
			}

			// Token: 0x06000267 RID: 615 RVA: 0x000058A8 File Offset: 0x00003AA8
			private static Class11.Class23 smethod_1(Class11.Class22 class22_3)
			{
				Class11.Class23 @class = class22_3 as Class11.Class23;
				bool flag = @class == null && class22_3.vmethod_0();
				if (flag)
				{
					@class = (class22_3.vmethod_8() as Class11.Class23);
				}
				return @class;
			}

			// Token: 0x06000268 RID: 616 RVA: 0x00010A40 File Offset: 0x0000EC40
			private void method_12(bool bool_4)
			{
				int metadataToken = (int)this.object_0;
				MethodBase methodBase = typeof(Class11).Module.ResolveMethod(metadataToken);
				MethodInfo methodInfo = methodBase as MethodInfo;
				ParameterInfo[] parameters = methodBase.GetParameters();
				object[] array = new object[parameters.Length];
				Class11.Class22[] array2 = new Class11.Class22[parameters.Length];
				List<Class11.Class18> list = null;
				Class11.Class19 @class = null;
				for (int i = 0; i < parameters.Length; i++)
				{
					Class11.Class22 class2 = this.class36_0.method_4();
					Type type = parameters[parameters.Length - 1 - i].ParameterType;
					object obj = null;
					bool flag = false;
					Class11.Class31 class3;
					bool flag2;
					if (type.IsByRef)
					{
						class3 = (class2 as Class11.Class31);
						flag2 = (class3 != null);
					}
					else
					{
						flag2 = false;
					}
					bool flag3 = flag2;
					if (flag3)
					{
						bool flag4 = list == null;
						if (flag4)
						{
							list = new List<Class11.Class18>();
						}
						list.Add(new Class11.Class18(class3.fieldInfo_0, i));
						obj = class3.object_0;
						bool flag5 = obj is Class11.Class22;
						if (flag5)
						{
							class2 = (obj as Class11.Class22);
						}
						else
						{
							flag = true;
						}
					}
					bool flag6 = !flag;
					if (flag6)
					{
						bool flag7 = class2 != null;
						if (flag7)
						{
							obj = class2.vmethod_4(type);
						}
						bool flag8 = obj == null;
						if (flag8)
						{
							bool isByRef = type.IsByRef;
							if (isByRef)
							{
								type = type.GetElementType();
							}
							bool isValueType = type.IsValueType;
							if (isValueType)
							{
								obj = Activator.CreateInstance(type);
								bool flag9 = class2 is Class11.Class29;
								if (flag9)
								{
									((Class11.Class28)class2).vmethod_12(Class11.Class22.smethod_1(type, obj));
								}
							}
						}
					}
					array2[array.Length - 1 - i] = class2;
					array[array.Length - 1 - i] = obj;
				}
				Class11.Delegate10 @delegate = null;
				bool flag10 = list == null;
				if (flag10)
				{
					bool flag11 = methodInfo != null && methodInfo.ReturnType.IsByRef;
					if (flag11)
					{
						@delegate = Class11.Class20.smethod_2(methodBase, bool_4);
					}
				}
				else
				{
					@class = new Class11.Class19(methodBase, list);
					@delegate = Class11.Class20.smethod_3(methodBase, bool_4, @class);
				}
				object obj2 = null;
				bool flag12 = !methodBase.IsStatic;
				if (flag12)
				{
					Class11.Class22 class4 = this.class36_0.method_4();
					bool flag13 = class4 != null;
					if (flag13)
					{
						obj2 = class4.vmethod_4(methodBase.DeclaringType);
					}
					bool flag14 = obj2 == null;
					if (flag14)
					{
						Type type2 = methodBase.DeclaringType;
						bool isByRef2 = type2.IsByRef;
						if (isByRef2)
						{
							type2 = type2.GetElementType();
						}
						bool flag15 = !type2.IsValueType;
						if (flag15)
						{
							throw new NullReferenceException();
						}
						obj2 = Activator.CreateInstance(type2);
						bool flag16 = class4 is Class11.Class29;
						if (flag16)
						{
							((Class11.Class28)class4).vmethod_12(Class11.Class22.smethod_1(type2, obj2));
						}
					}
				}
				object obj3 = (@delegate != null) ? @delegate(obj2, array) : methodBase.Invoke(obj2, array);
				for (int j = 0; j < parameters.Length; j++)
				{
					bool flag17 = parameters[j].ParameterType.IsByRef && (@class == null || !@class.method_1(j));
					if (flag17)
					{
						bool flag18 = array2[j].method_2();
						if (flag18)
						{
							((Class11.Class26)array2[j]).method_6(Class11.Class22.smethod_1(parameters[j].ParameterType, array[j]));
						}
						else
						{
							bool flag19 = array2[j] is Class11.Class29;
							if (flag19)
							{
								array2[j].vmethod_10(Class11.Class22.smethod_1(parameters[j].ParameterType.GetElementType(), array[j]));
							}
							else
							{
								array2[j].vmethod_10(Class11.Class22.smethod_1(parameters[j].ParameterType, array[j]));
							}
						}
					}
				}
				bool flag20 = methodInfo != null && methodInfo.ReturnType != typeof(void);
				if (flag20)
				{
					this.class36_0.method_2(Class11.Class22.smethod_1(methodInfo.ReturnType, obj3));
				}
			}

			// Token: 0x06000269 RID: 617 RVA: 0x00010E48 File Offset: 0x0000F048
			private static Class11.Delegate10 smethod_2(object object_1, bool bool_4)
			{
				Class11.Delegate10 result = null;
				if (bool_4)
				{
					bool flag = Class11.Class20.dictionary_2.TryGetValue((MethodBase)object_1, out result);
					if (flag)
					{
						return result;
					}
				}
				else
				{
					bool flag2 = Class11.Class20.dictionary_3.TryGetValue((MethodBase)object_1, out result);
					if (flag2)
					{
						return result;
					}
				}
				MethodInfo methodInfo = object_1 as MethodInfo;
				DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(object), new Type[]
				{
					typeof(object),
					typeof(object[])
				}, true);
				ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
				ParameterInfo[] parameters = ((MethodBase)object_1).GetParameters();
				Type[] array = new Type[parameters.Length];
				for (int i = 0; i < array.Length; i++)
				{
					bool flag3 = !parameters[i].ParameterType.IsByRef;
					if (flag3)
					{
						array[i] = parameters[i].ParameterType;
					}
					else
					{
						array[i] = parameters[i].ParameterType.GetElementType();
					}
				}
				int num = array.Length;
				bool isValueType = ((MemberInfo)object_1).DeclaringType.IsValueType;
				if (isValueType)
				{
					num++;
				}
				LocalBuilder[] array2 = new LocalBuilder[num];
				for (int j = 0; j < array.Length; j++)
				{
					array2[j] = ilgenerator.DeclareLocal(array[j]);
				}
				bool isValueType2 = ((MemberInfo)object_1).DeclaringType.IsValueType;
				if (isValueType2)
				{
					array2[array2.Length - 1] = ilgenerator.DeclareLocal(((MemberInfo)object_1).DeclaringType.MakeByRefType());
				}
				for (int k = 0; k < array.Length; k++)
				{
					ilgenerator.Emit(OpCodes.Ldarg_1);
					Class11.Class20.smethod_5(ilgenerator, k);
					ilgenerator.Emit(OpCodes.Ldelem_Ref);
					bool isValueType3 = array[k].IsValueType;
					if (isValueType3)
					{
						ilgenerator.Emit(OpCodes.Unbox_Any, array[k]);
					}
					else
					{
						bool flag4 = array[k] != typeof(object);
						if (flag4)
						{
							ilgenerator.Emit(OpCodes.Castclass, array[k]);
						}
					}
					ilgenerator.Emit(OpCodes.Stloc, array2[k]);
				}
				bool flag5 = !((MethodBase)object_1).IsStatic;
				if (flag5)
				{
					ilgenerator.Emit(OpCodes.Ldarg_0);
					bool isValueType4 = ((MemberInfo)object_1).DeclaringType.IsValueType;
					if (isValueType4)
					{
						ilgenerator.Emit(OpCodes.Unbox, ((MemberInfo)object_1).DeclaringType);
						ilgenerator.Emit(OpCodes.Stloc, array2[array2.Length - 1]);
						ilgenerator.Emit(OpCodes.Ldloc_S, array2[array2.Length - 1]);
					}
					else
					{
						ilgenerator.Emit(OpCodes.Castclass, ((MemberInfo)object_1).DeclaringType);
					}
				}
				for (int l = 0; l < array.Length; l++)
				{
					bool flag6 = !parameters[l].ParameterType.IsByRef;
					if (flag6)
					{
						ilgenerator.Emit(OpCodes.Ldloc, array2[l]);
					}
					else
					{
						ilgenerator.Emit(OpCodes.Ldloca_S, array2[l]);
					}
				}
				if (bool_4)
				{
					bool flag7 = !(methodInfo != null);
					if (flag7)
					{
						ilgenerator.Emit(OpCodes.Call, object_1 as ConstructorInfo);
					}
					else
					{
						ilgenerator.EmitCall(OpCodes.Call, methodInfo, null);
					}
				}
				else
				{
					bool flag8 = methodInfo != null;
					if (flag8)
					{
						ilgenerator.EmitCall(OpCodes.Callvirt, methodInfo, null);
					}
					else
					{
						ilgenerator.Emit(OpCodes.Callvirt, object_1 as ConstructorInfo);
					}
				}
				bool flag9 = !(methodInfo == null) && !(methodInfo.ReturnType == typeof(void));
				if (flag9)
				{
					bool flag10 = !methodInfo.ReturnType.IsByRef;
					if (flag10)
					{
						bool isValueType5 = methodInfo.ReturnType.IsValueType;
						if (isValueType5)
						{
							ilgenerator.Emit(OpCodes.Box, methodInfo.ReturnType);
						}
					}
					else
					{
						Type elementType = methodInfo.ReturnType.GetElementType();
						bool isValueType6 = elementType.IsValueType;
						if (isValueType6)
						{
							ilgenerator.Emit(OpCodes.Ldobj, elementType);
						}
						else
						{
							ilgenerator.Emit(OpCodes.Ldind_Ref, elementType);
						}
						bool isValueType7 = elementType.IsValueType;
						if (isValueType7)
						{
							ilgenerator.Emit(OpCodes.Box, elementType);
						}
					}
				}
				else
				{
					ilgenerator.Emit(OpCodes.Ldnull);
				}
				for (int m = 0; m < array.Length; m++)
				{
					bool isByRef = parameters[m].ParameterType.IsByRef;
					if (isByRef)
					{
						ilgenerator.Emit(OpCodes.Ldarg_1);
						Class11.Class20.smethod_5(ilgenerator, m);
						ilgenerator.Emit(OpCodes.Ldloc, array2[m]);
						bool isValueType8 = array2[m].LocalType.IsValueType;
						if (isValueType8)
						{
							ilgenerator.Emit(OpCodes.Box, array2[m].LocalType);
						}
						ilgenerator.Emit(OpCodes.Stelem_Ref);
					}
				}
				ilgenerator.Emit(OpCodes.Ret);
				Class11.Delegate10 @delegate = (Class11.Delegate10)dynamicMethod.CreateDelegate(typeof(Class11.Delegate10));
				bool flag11 = !bool_4;
				if (flag11)
				{
					Class11.Class20.dictionary_3.Add((MethodBase)object_1, @delegate);
				}
				else
				{
					Class11.Class20.dictionary_2.Add((MethodBase)object_1, @delegate);
				}
				return @delegate;
			}

			// Token: 0x0600026A RID: 618 RVA: 0x000113C8 File Offset: 0x0000F5C8
			private static Class11.Delegate10 smethod_3(object object_1, bool bool_4, Class11.Class19 class19_0)
			{
				Class11.Delegate10 result = null;
				if (bool_4)
				{
					bool flag = Class11.Class20.dictionary_4.TryGetValue(class19_0, out result);
					if (flag)
					{
						return result;
					}
				}
				else
				{
					bool flag2 = Class11.Class20.dictionary_5.TryGetValue(class19_0, out result);
					if (flag2)
					{
						return result;
					}
				}
				MethodInfo methodInfo = object_1 as MethodInfo;
				DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(object), new Type[]
				{
					typeof(object),
					typeof(object[])
				}, typeof(Class11), true);
				ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
				ParameterInfo[] parameters = ((MethodBase)object_1).GetParameters();
				Type[] array = new Type[parameters.Length];
				for (int i = 0; i < array.Length; i++)
				{
					bool isByRef = parameters[i].ParameterType.IsByRef;
					if (isByRef)
					{
						array[i] = parameters[i].ParameterType.GetElementType();
					}
					else
					{
						array[i] = parameters[i].ParameterType;
					}
				}
				int num = array.Length;
				bool isValueType = ((MemberInfo)object_1).DeclaringType.IsValueType;
				if (isValueType)
				{
					num++;
				}
				LocalBuilder[] array2 = new LocalBuilder[num];
				for (int j = 0; j < array.Length; j++)
				{
					bool flag3 = !class19_0.method_1(j);
					if (flag3)
					{
						array2[j] = ilgenerator.DeclareLocal(array[j]);
					}
					else
					{
						array2[j] = ilgenerator.DeclareLocal(typeof(object));
					}
				}
				bool isValueType2 = ((MemberInfo)object_1).DeclaringType.IsValueType;
				if (isValueType2)
				{
					array2[array2.Length - 1] = ilgenerator.DeclareLocal(((MemberInfo)object_1).DeclaringType.MakeByRefType());
				}
				for (int k = 0; k < array.Length; k++)
				{
					ilgenerator.Emit(OpCodes.Ldarg_1);
					Class11.Class20.smethod_5(ilgenerator, k);
					ilgenerator.Emit(OpCodes.Ldelem_Ref);
					bool flag4 = !class19_0.method_1(k);
					if (flag4)
					{
						bool isValueType3 = array[k].IsValueType;
						if (isValueType3)
						{
							ilgenerator.Emit(OpCodes.Unbox_Any, array[k]);
						}
						else
						{
							bool flag5 = array[k] != typeof(object);
							if (flag5)
							{
								ilgenerator.Emit(OpCodes.Castclass, array[k]);
							}
						}
					}
					ilgenerator.Emit(OpCodes.Stloc, array2[k]);
				}
				bool flag6 = !((MethodBase)object_1).IsStatic;
				if (flag6)
				{
					ilgenerator.Emit(OpCodes.Ldarg_0);
					bool isValueType4 = ((MemberInfo)object_1).DeclaringType.IsValueType;
					if (isValueType4)
					{
						ilgenerator.Emit(OpCodes.Unbox, ((MemberInfo)object_1).DeclaringType);
						ilgenerator.Emit(OpCodes.Stloc, array2[array2.Length - 1]);
						ilgenerator.Emit(OpCodes.Ldloc_S, array2[array2.Length - 1]);
					}
					else
					{
						ilgenerator.Emit(OpCodes.Castclass, ((MemberInfo)object_1).DeclaringType);
					}
				}
				for (int l = 0; l < array.Length; l++)
				{
					bool flag7 = class19_0.method_1(l);
					if (flag7)
					{
						Class11.Class18 @class = class19_0.method_0(l);
						bool flag8 = !((FieldInfo)@class.object_0).IsStatic;
						if (flag8)
						{
							bool isValueType5 = ((MemberInfo)@class.object_0).DeclaringType.IsValueType;
							if (isValueType5)
							{
								ilgenerator.Emit(OpCodes.Ldloc, array2[l]);
								ilgenerator.Emit(OpCodes.Unbox, ((MemberInfo)@class.object_0).DeclaringType);
								ilgenerator.Emit(OpCodes.Ldflda, (FieldInfo)@class.object_0);
							}
							else
							{
								ilgenerator.Emit(OpCodes.Ldloc, array2[l]);
								ilgenerator.Emit(OpCodes.Castclass, ((MemberInfo)@class.object_0).DeclaringType);
								ilgenerator.Emit(OpCodes.Ldflda, (FieldInfo)@class.object_0);
							}
						}
						else
						{
							ilgenerator.Emit(OpCodes.Ldsflda, (FieldInfo)@class.object_0);
						}
					}
					else
					{
						bool flag9 = !parameters[l].ParameterType.IsByRef;
						if (flag9)
						{
							ilgenerator.Emit(OpCodes.Ldloc, array2[l]);
						}
						else
						{
							ilgenerator.Emit(OpCodes.Ldloca_S, array2[l]);
						}
					}
				}
				if (bool_4)
				{
					bool flag10 = methodInfo != null;
					if (flag10)
					{
						ilgenerator.EmitCall(OpCodes.Call, methodInfo, null);
					}
					else
					{
						ilgenerator.Emit(OpCodes.Call, object_1 as ConstructorInfo);
					}
				}
				else
				{
					bool flag11 = !(methodInfo != null);
					if (flag11)
					{
						ilgenerator.Emit(OpCodes.Callvirt, object_1 as ConstructorInfo);
					}
					else
					{
						ilgenerator.EmitCall(OpCodes.Callvirt, methodInfo, null);
					}
				}
				bool flag12 = !(methodInfo == null) && !(methodInfo.ReturnType == typeof(void));
				if (flag12)
				{
					bool flag13 = !methodInfo.ReturnType.IsByRef;
					if (flag13)
					{
						bool isValueType6 = methodInfo.ReturnType.IsValueType;
						if (isValueType6)
						{
							ilgenerator.Emit(OpCodes.Box, methodInfo.ReturnType);
						}
					}
					else
					{
						Type elementType = methodInfo.ReturnType.GetElementType();
						bool flag14 = !elementType.IsValueType;
						if (flag14)
						{
							ilgenerator.Emit(OpCodes.Ldind_Ref, elementType);
						}
						else
						{
							ilgenerator.Emit(OpCodes.Ldobj, elementType);
						}
						bool isValueType7 = elementType.IsValueType;
						if (isValueType7)
						{
							ilgenerator.Emit(OpCodes.Box, elementType);
						}
					}
				}
				else
				{
					ilgenerator.Emit(OpCodes.Ldnull);
				}
				for (int m = 0; m < array.Length; m++)
				{
					bool flag15 = !parameters[m].ParameterType.IsByRef;
					if (!flag15)
					{
						bool flag16 = !class19_0.method_1(m);
						if (flag16)
						{
							ilgenerator.Emit(OpCodes.Ldarg_1);
							Class11.Class20.smethod_5(ilgenerator, m);
							ilgenerator.Emit(OpCodes.Ldloc, array2[m]);
							bool isValueType8 = array2[m].LocalType.IsValueType;
							if (isValueType8)
							{
								ilgenerator.Emit(OpCodes.Box, array2[m].LocalType);
							}
							ilgenerator.Emit(OpCodes.Stelem_Ref);
						}
						else
						{
							Class11.Class18 class2 = class19_0.method_0(m);
							bool isStatic = ((FieldInfo)class2.object_0).IsStatic;
							if (isStatic)
							{
								ilgenerator.Emit(OpCodes.Ldarg_1);
								Class11.Class20.smethod_5(ilgenerator, m);
								ilgenerator.Emit(OpCodes.Ldsfld, (FieldInfo)class2.object_0);
								bool isValueType9 = ((FieldInfo)class2.object_0).FieldType.IsValueType;
								if (isValueType9)
								{
									ilgenerator.Emit(OpCodes.Box, array2[m].LocalType);
								}
								ilgenerator.Emit(OpCodes.Stelem_Ref);
							}
							else
							{
								ilgenerator.Emit(OpCodes.Ldarg_1);
								Class11.Class20.smethod_5(ilgenerator, m);
								ilgenerator.Emit(OpCodes.Ldloc, array2[m]);
								bool isValueType10 = array2[m].LocalType.IsValueType;
								if (isValueType10)
								{
									ilgenerator.Emit(OpCodes.Box, array2[m].LocalType);
								}
								ilgenerator.Emit(OpCodes.Stelem_Ref);
							}
						}
					}
				}
				ilgenerator.Emit(OpCodes.Ret);
				Class11.Delegate10 @delegate = (Class11.Delegate10)dynamicMethod.CreateDelegate(typeof(Class11.Delegate10));
				if (bool_4)
				{
					Class11.Class20.dictionary_4.Add(class19_0, @delegate);
				}
				else
				{
					Class11.Class20.dictionary_5.Add(class19_0, @delegate);
				}
				return @delegate;
			}

			// Token: 0x0600026B RID: 619 RVA: 0x00011B9C File Offset: 0x0000FD9C
			private static Class11.Delegate10 smethod_4(object object_1, bool bool_4, Class11.Class19 class19_0)
			{
				Class11.Delegate10 @delegate = null;
				bool flag = Class11.Class20.dictionary_6.TryGetValue(class19_0, out @delegate);
				Class11.Delegate10 result;
				if (flag)
				{
					result = @delegate;
				}
				else
				{
					ConstructorInfo constructorInfo = object_1 as ConstructorInfo;
					DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(object), new Type[]
					{
						typeof(object),
						typeof(object[])
					}, typeof(Class11), true);
					ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
					ParameterInfo[] parameters = ((MethodBase)object_1).GetParameters();
					Type[] array = new Type[parameters.Length];
					for (int i = 0; i < array.Length; i++)
					{
						bool flag2 = !parameters[i].ParameterType.IsByRef;
						if (flag2)
						{
							array[i] = parameters[i].ParameterType;
						}
						else
						{
							array[i] = parameters[i].ParameterType.GetElementType();
						}
					}
					int num = array.Length;
					bool isValueType = ((MemberInfo)object_1).DeclaringType.IsValueType;
					if (isValueType)
					{
						num++;
					}
					LocalBuilder[] array2 = new LocalBuilder[num];
					for (int j = 0; j < array.Length; j++)
					{
						bool flag3 = class19_0.method_1(j);
						if (flag3)
						{
							array2[j] = ilgenerator.DeclareLocal(typeof(object));
						}
						else
						{
							array2[j] = ilgenerator.DeclareLocal(array[j]);
						}
					}
					bool isValueType2 = ((MemberInfo)object_1).DeclaringType.IsValueType;
					if (isValueType2)
					{
						array2[array2.Length - 1] = ilgenerator.DeclareLocal(((MemberInfo)object_1).DeclaringType.MakeByRefType());
					}
					for (int k = 0; k < array.Length; k++)
					{
						ilgenerator.Emit(OpCodes.Ldarg_1);
						Class11.Class20.smethod_5(ilgenerator, k);
						ilgenerator.Emit(OpCodes.Ldelem_Ref);
						bool flag4 = !class19_0.method_1(k);
						if (flag4)
						{
							bool flag5 = !array[k].IsValueType;
							if (flag5)
							{
								bool flag6 = array[k] != typeof(object);
								if (flag6)
								{
									ilgenerator.Emit(OpCodes.Castclass, array[k]);
								}
							}
							else
							{
								ilgenerator.Emit(OpCodes.Unbox_Any, array[k]);
							}
						}
						ilgenerator.Emit(OpCodes.Stloc, array2[k]);
					}
					for (int l = 0; l < array.Length; l++)
					{
						bool flag7 = class19_0.method_1(l);
						if (flag7)
						{
							Class11.Class18 @class = class19_0.method_0(l);
							bool isStatic = ((FieldInfo)@class.object_0).IsStatic;
							if (isStatic)
							{
								ilgenerator.Emit(OpCodes.Ldsflda, (FieldInfo)@class.object_0);
							}
							else
							{
								bool isValueType3 = ((MemberInfo)@class.object_0).DeclaringType.IsValueType;
								if (isValueType3)
								{
									ilgenerator.Emit(OpCodes.Ldloc, array2[l]);
									ilgenerator.Emit(OpCodes.Unbox, ((MemberInfo)@class.object_0).DeclaringType);
									ilgenerator.Emit(OpCodes.Ldflda, (FieldInfo)@class.object_0);
								}
								else
								{
									ilgenerator.Emit(OpCodes.Ldloc, array2[l]);
									ilgenerator.Emit(OpCodes.Castclass, ((MemberInfo)@class.object_0).DeclaringType);
									ilgenerator.Emit(OpCodes.Ldflda, (FieldInfo)@class.object_0);
								}
							}
						}
						else
						{
							bool flag8 = !parameters[l].ParameterType.IsByRef;
							if (flag8)
							{
								ilgenerator.Emit(OpCodes.Ldloc, array2[l]);
							}
							else
							{
								ilgenerator.Emit(OpCodes.Ldloca_S, array2[l]);
							}
						}
					}
					ilgenerator.Emit(OpCodes.Newobj, object_1 as ConstructorInfo);
					bool isValueType4 = constructorInfo.DeclaringType.IsValueType;
					if (isValueType4)
					{
						ilgenerator.Emit(OpCodes.Box, constructorInfo.DeclaringType);
					}
					for (int m = 0; m < array.Length; m++)
					{
						bool flag9 = !parameters[m].ParameterType.IsByRef;
						if (!flag9)
						{
							bool flag10 = class19_0.method_1(m);
							if (flag10)
							{
								Class11.Class18 class2 = class19_0.method_0(m);
								bool isStatic2 = ((FieldInfo)class2.object_0).IsStatic;
								if (isStatic2)
								{
									ilgenerator.Emit(OpCodes.Ldarg_1);
									Class11.Class20.smethod_5(ilgenerator, m);
									ilgenerator.Emit(OpCodes.Ldsfld, (FieldInfo)class2.object_0);
									bool isValueType5 = ((FieldInfo)class2.object_0).FieldType.IsValueType;
									if (isValueType5)
									{
										ilgenerator.Emit(OpCodes.Box, array2[m].LocalType);
									}
									ilgenerator.Emit(OpCodes.Stelem_Ref);
								}
								else
								{
									ilgenerator.Emit(OpCodes.Ldarg_1);
									Class11.Class20.smethod_5(ilgenerator, m);
									ilgenerator.Emit(OpCodes.Ldloc, array2[m]);
									bool isValueType6 = array2[m].LocalType.IsValueType;
									if (isValueType6)
									{
										ilgenerator.Emit(OpCodes.Box, array2[m].LocalType);
									}
									ilgenerator.Emit(OpCodes.Stelem_Ref);
								}
							}
							else
							{
								ilgenerator.Emit(OpCodes.Ldarg_1);
								Class11.Class20.smethod_5(ilgenerator, m);
								ilgenerator.Emit(OpCodes.Ldloc, array2[m]);
								bool isValueType7 = array2[m].LocalType.IsValueType;
								if (isValueType7)
								{
									ilgenerator.Emit(OpCodes.Box, array2[m].LocalType);
								}
								ilgenerator.Emit(OpCodes.Stelem_Ref);
							}
						}
					}
					ilgenerator.Emit(OpCodes.Ret);
					Class11.Delegate10 delegate2 = (Class11.Delegate10)dynamicMethod.CreateDelegate(typeof(Class11.Delegate10));
					Class11.Class20.dictionary_6.Add(class19_0, delegate2);
					result = delegate2;
				}
				return result;
			}

			// Token: 0x0600026C RID: 620 RVA: 0x0001217C File Offset: 0x0001037C
			private static void smethod_5(ILGenerator ilgenerator_0, int int_3)
			{
				switch (int_3)
				{
				case -1:
					ilgenerator_0.Emit(OpCodes.Ldc_I4_M1);
					break;
				case 0:
					ilgenerator_0.Emit(OpCodes.Ldc_I4_0);
					break;
				case 1:
					ilgenerator_0.Emit(OpCodes.Ldc_I4_1);
					break;
				case 2:
					ilgenerator_0.Emit(OpCodes.Ldc_I4_2);
					break;
				case 3:
					ilgenerator_0.Emit(OpCodes.Ldc_I4_3);
					break;
				case 4:
					ilgenerator_0.Emit(OpCodes.Ldc_I4_4);
					break;
				case 5:
					ilgenerator_0.Emit(OpCodes.Ldc_I4_5);
					break;
				case 6:
					ilgenerator_0.Emit(OpCodes.Ldc_I4_6);
					break;
				case 7:
					ilgenerator_0.Emit(OpCodes.Ldc_I4_7);
					break;
				case 8:
					ilgenerator_0.Emit(OpCodes.Ldc_I4_8);
					break;
				default:
				{
					bool flag = int_3 > -129 && int_3 < 128;
					if (flag)
					{
						ilgenerator_0.Emit(OpCodes.Ldc_I4_S, (sbyte)int_3);
					}
					else
					{
						ilgenerator_0.Emit(OpCodes.Ldc_I4, int_3);
					}
					break;
				}
				}
			}

			// Token: 0x0600026D RID: 621 RVA: 0x00012294 File Offset: 0x00010494
			private static Class11.Class22 smethod_6(Class11.Class22 class22_3)
			{
				bool flag = class22_3.vmethod_8().method_0();
				if (flag)
				{
					object obj = class22_3.vmethod_4(null);
					bool flag2 = obj != null && obj.GetType().IsEnum;
					if (flag2)
					{
						Type underlyingType = Enum.GetUnderlyingType(obj.GetType());
						object obj2 = Convert.ChangeType(obj, underlyingType);
						Class11.Class22 @class = Class11.Class20.smethod_7(Class11.Class22.smethod_1(underlyingType, obj2));
						bool flag3 = @class != null;
						if (flag3)
						{
							return @class as Class11.Class23;
						}
					}
				}
				return class22_3;
			}

			// Token: 0x0600026E RID: 622 RVA: 0x000058A8 File Offset: 0x00003AA8
			private static Class11.Class23 smethod_7(Class11.Class22 class22_3)
			{
				Class11.Class23 @class = class22_3 as Class11.Class23;
				bool flag = @class == null && class22_3.vmethod_0();
				if (flag)
				{
					@class = (class22_3.vmethod_8() as Class11.Class23);
				}
				return @class;
			}

			// Token: 0x0600026F RID: 623 RVA: 0x00012314 File Offset: 0x00010514
			private static IntPtr smethod_8(object object_1)
			{
				bool flag = object_1 == null;
				IntPtr result;
				if (flag)
				{
					result = IntPtr.Zero;
				}
				else
				{
					bool flag2 = ((Class11.Class22)object_1).method_2();
					if (flag2)
					{
						result = ((Class11.Class26)object_1).method_7();
					}
					else
					{
						bool flag3 = ((Class11.Class22)object_1).vmethod_0();
						if (flag3)
						{
							Class11.Class28 @class = (Class11.Class28)object_1;
							try
							{
								return @class.vmethod_11();
							}
							catch
							{
							}
						}
						object obj = ((Class11.Class22)object_1).vmethod_4(typeof(IntPtr));
						bool flag4 = obj == null || !(obj.GetType() == typeof(IntPtr));
						if (flag4)
						{
							throw new Class11.Exception1();
						}
						result = (IntPtr)obj;
					}
				}
				return result;
			}

			// Token: 0x06000270 RID: 624 RVA: 0x000123DC File Offset: 0x000105DC
			private static object smethod_9(object object_1)
			{
				bool flag = Class11.Class20.dictionary_7 == null;
				if (flag)
				{
					Class11.Class20.dictionary_7 = new Dictionary<Type, Class11.Delegate11>();
				}
				bool flag2 = object_1 == null;
				object result;
				if (flag2)
				{
					result = null;
				}
				else
				{
					try
					{
						Type type = object_1.GetType();
						Class11.Delegate11 @delegate;
						bool flag3 = Class11.Class20.dictionary_7.TryGetValue(type, out @delegate);
						if (flag3)
						{
							result = @delegate(object_1);
						}
						else
						{
							DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(object), new Type[]
							{
								typeof(object)
							}, true);
							ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
							ilgenerator.Emit(OpCodes.Ldarg_0);
							ilgenerator.Emit(OpCodes.Unbox_Any, type);
							ilgenerator.Emit(OpCodes.Box, type);
							ilgenerator.Emit(OpCodes.Ret);
							Class11.Delegate11 delegate2 = (Class11.Delegate11)dynamicMethod.CreateDelegate(typeof(Class11.Delegate11));
							Class11.Class20.dictionary_7.Add(type, delegate2);
							result = delegate2(object_1);
						}
					}
					catch
					{
						result = null;
					}
				}
				return result;
			}

			// Token: 0x06000271 RID: 625 RVA: 0x000124F0 File Offset: 0x000106F0
			private static void smethod_10(IntPtr intptr_0, byte byte_0, int int_3)
			{
				bool flag = Class11.Class20.delegate12_0 == null;
				if (flag)
				{
					DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(void), new Type[]
					{
						typeof(IntPtr),
						typeof(byte),
						typeof(int)
					}, typeof(Class11), true);
					ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
					ilgenerator.Emit(OpCodes.Ldarg_0);
					ilgenerator.Emit(OpCodes.Ldarg_1);
					ilgenerator.Emit(OpCodes.Ldarg_2);
					ilgenerator.Emit(OpCodes.Initblk);
					ilgenerator.Emit(OpCodes.Ret);
					Class11.Class20.delegate12_0 = (Class11.Delegate12)dynamicMethod.CreateDelegate(typeof(Class11.Delegate12));
				}
				Class11.Class20.delegate12_0(intptr_0, byte_0, int_3);
			}

			// Token: 0x06000272 RID: 626 RVA: 0x000125C8 File Offset: 0x000107C8
			private static void smethod_11(IntPtr intptr_0, IntPtr intptr_1, uint uint_0)
			{
				bool flag = Class11.Class20.delegate13_0 == null;
				if (flag)
				{
					DynamicMethod dynamicMethod = new DynamicMethod(string.Empty, typeof(void), new Type[]
					{
						typeof(IntPtr),
						typeof(IntPtr),
						typeof(uint)
					}, typeof(Class11), true);
					ILGenerator ilgenerator = dynamicMethod.GetILGenerator();
					ilgenerator.Emit(OpCodes.Ldarg_0);
					ilgenerator.Emit(OpCodes.Ldarg_1);
					ilgenerator.Emit(OpCodes.Ldarg_2);
					ilgenerator.Emit(OpCodes.Cpblk);
					ilgenerator.Emit(OpCodes.Ret);
					Class11.Class20.delegate13_0 = (Class11.Delegate13)dynamicMethod.CreateDelegate(typeof(Class11.Delegate13));
				}
				Class11.Class20.delegate13_0(intptr_0, intptr_1, uint_0);
			}

			// Token: 0x04000056 RID: 86
			internal Class11.Class17 class17_0;

			// Token: 0x04000057 RID: 87
			internal Class11.Class22[] class22_0 = new Class11.Class22[0];

			// Token: 0x04000058 RID: 88
			internal Class11.Class22[] class22_1 = new Class11.Class22[0];

			// Token: 0x04000059 RID: 89
			internal Class11.Class36 class36_0 = new Class11.Class36();

			// Token: 0x0400005A RID: 90
			internal Class11.Class22 class22_2;

			// Token: 0x0400005B RID: 91
			internal Exception exception_0;

			// Token: 0x0400005C RID: 92
			internal List<IntPtr> list_0;

			// Token: 0x0400005D RID: 93
			private int int_0;

			// Token: 0x0400005E RID: 94
			private int int_1;

			// Token: 0x0400005F RID: 95
			private int int_2 = -1;

			// Token: 0x04000060 RID: 96
			private object object_0;

			// Token: 0x04000061 RID: 97
			private bool bool_0;

			// Token: 0x04000062 RID: 98
			private bool bool_1;

			// Token: 0x04000063 RID: 99
			private bool bool_2;

			// Token: 0x04000064 RID: 100
			private bool bool_3;

			// Token: 0x04000065 RID: 101
			private static Dictionary<Type, int> dictionary_0;

			// Token: 0x04000066 RID: 102
			private static Dictionary<object, Class11.Class22> dictionary_1 = new Dictionary<object, Class11.Class22>();

			// Token: 0x04000067 RID: 103
			private static Dictionary<MethodBase, Class11.Delegate10> dictionary_2 = new Dictionary<MethodBase, Class11.Delegate10>();

			// Token: 0x04000068 RID: 104
			private static Dictionary<MethodBase, Class11.Delegate10> dictionary_3 = new Dictionary<MethodBase, Class11.Delegate10>();

			// Token: 0x04000069 RID: 105
			private static Dictionary<Class11.Class19, Class11.Delegate10> dictionary_4 = new Dictionary<Class11.Class19, Class11.Delegate10>();

			// Token: 0x0400006A RID: 106
			private static Dictionary<Class11.Class19, Class11.Delegate10> dictionary_5 = new Dictionary<Class11.Class19, Class11.Delegate10>();

			// Token: 0x0400006B RID: 107
			private static Dictionary<Class11.Class19, Class11.Delegate10> dictionary_6 = new Dictionary<Class11.Class19, Class11.Delegate10>();

			// Token: 0x0400006C RID: 108
			private static Dictionary<Type, Class11.Delegate11> dictionary_7;

			// Token: 0x0400006D RID: 109
			private static Class11.Delegate12 delegate12_0;

			// Token: 0x0400006E RID: 110
			private static Class11.Delegate13 delegate13_0;

			// Token: 0x02000035 RID: 53
			[CompilerGenerated]
			[Serializable]
			private sealed class Class21
			{
				// Token: 0x06000276 RID: 630 RVA: 0x000126A0 File Offset: 0x000108A0
				internal int method_0(Class11.Class15 x, Class11.Class15 y)
				{
					return x.class16_0.int_0.CompareTo(y.class16_0.int_0);
				}

				// Token: 0x0400006F RID: 111
				public static readonly Class11.Class20.Class21 _003C_003E9 = new Class11.Class20.Class21();

				// Token: 0x04000070 RID: 112
				public static Comparison<Class11.Class15> _003C_003E9__12_0;
			}
		}

		// Token: 0x02000037 RID: 55
		internal enum Enum3 : byte
		{

		}

		// Token: 0x02000038 RID: 56
		internal enum Enum4 : byte
		{

		}

		// Token: 0x02000039 RID: 57
		internal abstract class Class22
		{
			// Token: 0x0600027B RID: 635 RVA: 0x000022CC File Offset: 0x000004CC
			public Class22()
			{
			}

			// Token: 0x0600027C RID: 636 RVA: 0x000126D0 File Offset: 0x000108D0
			internal bool method_0()
			{
				return this.enum4_0 == (Class11.Enum4)0;
			}

			// Token: 0x0600027D RID: 637 RVA: 0x000126EC File Offset: 0x000108EC
			internal bool method_1()
			{
				return this.enum4_0 == (Class11.Enum4)1;
			}

			// Token: 0x0600027E RID: 638 RVA: 0x00012708 File Offset: 0x00010908
			internal bool method_2()
			{
				bool flag = this.enum4_0 != (Class11.Enum4)3;
				return !flag || this.enum4_0 == (Class11.Enum4)4;
			}

			// Token: 0x0600027F RID: 639 RVA: 0x00012738 File Offset: 0x00010938
			internal bool method_3()
			{
				return this.enum4_0 == (Class11.Enum4)2;
			}

			// Token: 0x06000280 RID: 640 RVA: 0x00012754 File Offset: 0x00010954
			internal bool method_4()
			{
				return this.enum4_0 == (Class11.Enum4)5;
			}

			// Token: 0x06000281 RID: 641 RVA: 0x00012770 File Offset: 0x00010970
			internal bool method_5()
			{
				return this.enum4_0 == (Class11.Enum4)6;
			}

			// Token: 0x06000282 RID: 642 RVA: 0x0001278C File Offset: 0x0001098C
			internal virtual bool vmethod_0()
			{
				return false;
			}

			// Token: 0x06000283 RID: 643 RVA: 0x0001278C File Offset: 0x0001098C
			internal virtual bool vmethod_1()
			{
				return false;
			}

			// Token: 0x06000284 RID: 644
			internal abstract void vmethod_2(Class11.Class22 class22_0);

			// Token: 0x06000285 RID: 645 RVA: 0x0001278C File Offset: 0x0001098C
			internal virtual bool vmethod_3()
			{
				return false;
			}

			// Token: 0x06000286 RID: 646 RVA: 0x0000286B File Offset: 0x00000A6B
			internal Class22(Class11.Enum4 enum4_1)
			{
				this.enum4_0 = enum4_1;
			}

			// Token: 0x06000287 RID: 647
			internal abstract object vmethod_4(Type type_0);

			// Token: 0x06000288 RID: 648
			internal abstract bool vmethod_5(Class11.Class22 class22_0);

			// Token: 0x06000289 RID: 649
			internal abstract bool vmethod_6(Class11.Class22 class22_0);

			// Token: 0x0600028A RID: 650
			internal abstract bool vmethod_7();

			// Token: 0x0600028B RID: 651
			internal abstract Class11.Class22 vmethod_8();

			// Token: 0x0600028C RID: 652 RVA: 0x0001278C File Offset: 0x0001098C
			internal virtual bool vmethod_9()
			{
				return false;
			}

			// Token: 0x0600028D RID: 653
			internal abstract void vmethod_10(Class11.Class22 class22_0);

			// Token: 0x0600028E RID: 654 RVA: 0x000127A0 File Offset: 0x000109A0
			internal static Class11.Enum2 smethod_0(Type type_0)
			{
				Type type = type_0;
				bool flag = type != null;
				Class11.Enum2 result;
				if (flag)
				{
					bool isByRef = type.IsByRef;
					if (isByRef)
					{
						type = type.GetElementType();
					}
					bool flag2 = !(type == typeof(string));
					if (flag2)
					{
						bool flag3 = !(type == typeof(byte));
						if (flag3)
						{
							bool flag4 = type == typeof(sbyte);
							if (flag4)
							{
								result = (Class11.Enum2)1;
							}
							else
							{
								bool flag5 = !(type == typeof(short));
								if (flag5)
								{
									bool flag6 = !(type == typeof(ushort));
									if (flag6)
									{
										bool flag7 = !(type == typeof(int));
										if (flag7)
										{
											bool flag8 = !(type == typeof(uint));
											if (flag8)
											{
												bool flag9 = !(type == typeof(long));
												if (flag9)
												{
													bool flag10 = !(type == typeof(ulong));
													if (flag10)
													{
														bool flag11 = !(type == typeof(float));
														if (flag11)
														{
															bool flag12 = type == typeof(double);
															if (flag12)
															{
																result = (Class11.Enum2)10;
															}
															else
															{
																bool flag13 = type == typeof(bool);
																if (flag13)
																{
																	result = (Class11.Enum2)11;
																}
																else
																{
																	bool flag14 = !(type == typeof(IntPtr));
																	if (flag14)
																	{
																		bool flag15 = !(type == typeof(UIntPtr));
																		if (flag15)
																		{
																			bool flag16 = !(type == typeof(char));
																			if (flag16)
																			{
																				bool flag17 = !(type == typeof(object));
																				if (flag17)
																				{
																					bool isEnum = type.IsEnum;
																					if (isEnum)
																					{
																						result = (Class11.Enum2)16;
																					}
																					else
																					{
																						result = (Class11.Enum2)17;
																					}
																				}
																				else
																				{
																					result = (Class11.Enum2)0;
																				}
																			}
																			else
																			{
																				result = (Class11.Enum2)15;
																			}
																		}
																		else
																		{
																			result = (Class11.Enum2)13;
																		}
																	}
																	else
																	{
																		result = (Class11.Enum2)12;
																	}
																}
															}
														}
														else
														{
															result = (Class11.Enum2)9;
														}
													}
													else
													{
														result = (Class11.Enum2)8;
													}
												}
												else
												{
													result = (Class11.Enum2)7;
												}
											}
											else
											{
												result = (Class11.Enum2)6;
											}
										}
										else
										{
											result = (Class11.Enum2)5;
										}
									}
									else
									{
										result = (Class11.Enum2)4;
									}
								}
								else
								{
									result = (Class11.Enum2)3;
								}
							}
						}
						else
						{
							result = (Class11.Enum2)2;
						}
					}
					else
					{
						result = (Class11.Enum2)14;
					}
				}
				else
				{
					result = (Class11.Enum2)18;
				}
				return result;
			}

			// Token: 0x0600028F RID: 655 RVA: 0x00012A04 File Offset: 0x00010C04
			internal static Class11.Class22 smethod_1(Type type_0, object object_0)
			{
				Class11.Enum2 @enum = Class11.Class22.smethod_0(type_0);
				Class11.Enum2 enum2 = (Class11.Enum2)18;
				bool flag = object_0 != null;
				if (flag)
				{
					enum2 = Class11.Class22.smethod_0(object_0.GetType());
				}
				Class11.Class22 @class = null;
				switch (@enum)
				{
				case (Class11.Enum2)0:
					@class = ((enum2 != (Class11.Enum2)15) ? Class11.Class22.smethod_2(object_0) : new Class11.Class34(object_0));
					break;
				case (Class11.Enum2)1:
				{
					if (!true)
					{
					}
					Class11.Class24 class2;
					if (enum2 <= (Class11.Enum2)2)
					{
						if (enum2 == (Class11.Enum2)1)
						{
							class2 = new Class11.Class24((int)((sbyte)object_0), (Class11.Enum1)1);
							goto IL_117;
						}
						if (enum2 == (Class11.Enum2)2)
						{
							class2 = new Class11.Class24((int)((sbyte)((byte)object_0)), (Class11.Enum1)1);
							goto IL_117;
						}
					}
					else
					{
						if (enum2 == (Class11.Enum2)11)
						{
							class2 = ((!(bool)object_0) ? new Class11.Class24(0, (Class11.Enum1)1) : new Class11.Class24(1, (Class11.Enum1)1));
							goto IL_117;
						}
						if (enum2 == (Class11.Enum2)15)
						{
							class2 = new Class11.Class24((int)((sbyte)((char)object_0)), (Class11.Enum1)1);
							goto IL_117;
						}
					}
					throw new InvalidCastException();
					IL_117:
					if (!true)
					{
					}
					Class11.Class24 class3 = class2;
					@class = class3;
					break;
				}
				case (Class11.Enum2)2:
				{
					if (!true)
					{
					}
					Class11.Class24 class2;
					if (enum2 <= (Class11.Enum2)2)
					{
						if (enum2 == (Class11.Enum2)1)
						{
							class2 = new Class11.Class24((int)((byte)((sbyte)object_0)), (Class11.Enum1)2);
							goto IL_1A8;
						}
						if (enum2 == (Class11.Enum2)2)
						{
							class2 = new Class11.Class24((int)((byte)object_0), (Class11.Enum1)2);
							goto IL_1A8;
						}
					}
					else
					{
						if (enum2 == (Class11.Enum2)11)
						{
							class2 = ((!(bool)object_0) ? new Class11.Class24(0, (Class11.Enum1)2) : new Class11.Class24(1, (Class11.Enum1)2));
							goto IL_1A8;
						}
						if (enum2 == (Class11.Enum2)15)
						{
							class2 = new Class11.Class24((int)((byte)((char)object_0)), (Class11.Enum1)2);
							goto IL_1A8;
						}
					}
					throw new InvalidCastException();
					IL_1A8:
					if (!true)
					{
					}
					Class11.Class24 class4 = class2;
					@class = class4;
					break;
				}
				case (Class11.Enum2)3:
				{
					if (!true)
					{
					}
					Class11.Class24 class2;
					if (enum2 != (Class11.Enum2)3)
					{
						if (enum2 != (Class11.Enum2)11)
						{
							if (enum2 != (Class11.Enum2)15)
							{
								throw new InvalidCastException();
							}
							class2 = new Class11.Class24((int)((short)((char)object_0)), (Class11.Enum1)3);
						}
						else
						{
							class2 = (((bool)object_0) ? new Class11.Class24(1, (Class11.Enum1)3) : new Class11.Class24(0, (Class11.Enum1)3));
						}
					}
					else
					{
						class2 = new Class11.Class24((int)((short)object_0), (Class11.Enum1)3);
					}
					if (!true)
					{
					}
					Class11.Class24 class5 = class2;
					@class = class5;
					break;
				}
				case (Class11.Enum2)4:
				{
					if (!true)
					{
					}
					Class11.Class24 class2;
					if (enum2 != (Class11.Enum2)4)
					{
						if (enum2 != (Class11.Enum2)11)
						{
							if (enum2 != (Class11.Enum2)15)
							{
								throw new InvalidCastException();
							}
							class2 = new Class11.Class24((int)((char)object_0), (Class11.Enum1)4);
						}
						else
						{
							class2 = ((!(bool)object_0) ? new Class11.Class24(0, (Class11.Enum1)4) : new Class11.Class24(1, (Class11.Enum1)4));
						}
					}
					else
					{
						class2 = new Class11.Class24((int)((ushort)object_0), (Class11.Enum1)4);
					}
					if (!true)
					{
					}
					Class11.Class24 class6 = class2;
					@class = class6;
					break;
				}
				case (Class11.Enum2)5:
				{
					if (!true)
					{
					}
					Class11.Class24 class2;
					if (enum2 != (Class11.Enum2)5)
					{
						if (enum2 != (Class11.Enum2)11)
						{
							if (enum2 != (Class11.Enum2)15)
							{
								throw new InvalidCastException();
							}
							class2 = new Class11.Class24((int)((char)object_0), (Class11.Enum1)5);
						}
						else
						{
							class2 = ((!(bool)object_0) ? new Class11.Class24(0, (Class11.Enum1)5) : new Class11.Class24(1, (Class11.Enum1)5));
						}
					}
					else
					{
						class2 = new Class11.Class24((int)object_0, (Class11.Enum1)5);
					}
					if (!true)
					{
					}
					Class11.Class24 class7 = class2;
					@class = class7;
					break;
				}
				case (Class11.Enum2)6:
				{
					if (!true)
					{
					}
					Class11.Class24 class2;
					if (enum2 != (Class11.Enum2)6)
					{
						if (enum2 != (Class11.Enum2)11)
						{
							if (enum2 != (Class11.Enum2)15)
							{
								throw new InvalidCastException();
							}
							class2 = new Class11.Class24((uint)((char)object_0), (Class11.Enum1)6);
						}
						else
						{
							class2 = (((bool)object_0) ? new Class11.Class24(1U, (Class11.Enum1)6) : new Class11.Class24(0U, (Class11.Enum1)6));
						}
					}
					else
					{
						class2 = new Class11.Class24((uint)object_0, (Class11.Enum1)6);
					}
					if (!true)
					{
					}
					Class11.Class24 class8 = class2;
					@class = class8;
					break;
				}
				case (Class11.Enum2)7:
				{
					if (!true)
					{
					}
					Class11.Class25 class9;
					if (enum2 != (Class11.Enum2)7)
					{
						if (enum2 != (Class11.Enum2)11)
						{
							if (enum2 != (Class11.Enum2)15)
							{
								throw new InvalidCastException();
							}
							class9 = new Class11.Class25((long)((ulong)((char)object_0)), (Class11.Enum1)7);
						}
						else
						{
							class9 = (((bool)object_0) ? new Class11.Class25(1L, (Class11.Enum1)7) : new Class11.Class25(0L, (Class11.Enum1)7));
						}
					}
					else
					{
						class9 = new Class11.Class25((long)object_0, (Class11.Enum1)7);
					}
					if (!true)
					{
					}
					Class11.Class25 class10 = class9;
					@class = class10;
					break;
				}
				case (Class11.Enum2)8:
				{
					if (!true)
					{
					}
					Class11.Class25 class9;
					if (enum2 != (Class11.Enum2)8)
					{
						if (enum2 != (Class11.Enum2)11)
						{
							if (enum2 != (Class11.Enum2)15)
							{
								throw new InvalidCastException();
							}
							class9 = new Class11.Class25((ulong)((char)object_0), (Class11.Enum1)8);
						}
						else
						{
							class9 = (((bool)object_0) ? new Class11.Class25(1UL, (Class11.Enum1)8) : new Class11.Class25(0UL, (Class11.Enum1)8));
						}
					}
					else
					{
						class9 = new Class11.Class25((ulong)object_0, (Class11.Enum1)8);
					}
					if (!true)
					{
					}
					Class11.Class25 class11 = class9;
					@class = class11;
					break;
				}
				case (Class11.Enum2)9:
				{
					bool flag2 = enum2 == (Class11.Enum2)9;
					if (!flag2)
					{
						throw new InvalidCastException();
					}
					@class = new Class11.Class27((float)object_0);
					break;
				}
				case (Class11.Enum2)10:
				{
					bool flag3 = enum2 == (Class11.Enum2)10;
					if (!flag3)
					{
						throw new InvalidCastException();
					}
					@class = new Class11.Class27((double)object_0);
					break;
				}
				case (Class11.Enum2)11:
					switch (enum2)
					{
					case (Class11.Enum2)1:
						@class = new Class11.Class24((sbyte)object_0 != 0);
						goto IL_5E1;
					case (Class11.Enum2)2:
						@class = new Class11.Class24((byte)object_0 > 0);
						goto IL_5E1;
					case (Class11.Enum2)3:
						@class = new Class11.Class24((short)object_0 != 0);
						goto IL_5E1;
					case (Class11.Enum2)4:
						@class = new Class11.Class24((ushort)object_0 > 0);
						goto IL_5E1;
					case (Class11.Enum2)5:
						@class = new Class11.Class24((int)object_0 != 0);
						goto IL_5E1;
					case (Class11.Enum2)6:
						@class = new Class11.Class24((uint)object_0 > 0U);
						goto IL_5E1;
					case (Class11.Enum2)7:
						@class = new Class11.Class24((long)object_0 != 0L);
						goto IL_5E1;
					case (Class11.Enum2)8:
						@class = new Class11.Class24((ulong)object_0 > 0UL);
						goto IL_5E1;
					case (Class11.Enum2)9:
					case (Class11.Enum2)10:
					case (Class11.Enum2)12:
					case (Class11.Enum2)13:
					case (Class11.Enum2)14:
					case (Class11.Enum2)15:
					case (Class11.Enum2)16:
						throw new InvalidCastException();
					case (Class11.Enum2)11:
						@class = new Class11.Class24((bool)object_0);
						goto IL_5E1;
					case (Class11.Enum2)18:
						@class = new Class11.Class24(false);
						goto IL_5E1;
					}
					@class = new Class11.Class24(object_0 != null);
					IL_5E1:
					break;
				case (Class11.Enum2)12:
				{
					bool flag4 = enum2 == (Class11.Enum2)12;
					if (!flag4)
					{
						throw new InvalidCastException();
					}
					@class = new Class11.Class26((IntPtr)object_0);
					break;
				}
				case (Class11.Enum2)13:
				{
					bool flag5 = enum2 == (Class11.Enum2)13;
					if (!flag5)
					{
						throw new InvalidCastException();
					}
					@class = new Class11.Class26((UIntPtr)object_0);
					break;
				}
				case (Class11.Enum2)14:
					@class = new Class11.Class35(object_0 as string);
					break;
				case (Class11.Enum2)15:
				{
					if (!true)
					{
					}
					Class11.Class24 class2;
					switch (enum2)
					{
					case (Class11.Enum2)1:
						class2 = new Class11.Class24((int)((sbyte)object_0), (Class11.Enum1)15);
						break;
					case (Class11.Enum2)2:
						class2 = new Class11.Class24((int)((byte)object_0), (Class11.Enum1)15);
						break;
					case (Class11.Enum2)3:
						class2 = new Class11.Class24((int)((short)object_0), (Class11.Enum1)15);
						break;
					case (Class11.Enum2)4:
						class2 = new Class11.Class24((int)((ushort)object_0), (Class11.Enum1)15);
						break;
					case (Class11.Enum2)5:
						class2 = new Class11.Class24((int)object_0, (Class11.Enum1)15);
						break;
					case (Class11.Enum2)6:
						class2 = new Class11.Class24((int)((uint)object_0), (Class11.Enum1)15);
						break;
					default:
						if (enum2 != (Class11.Enum2)15)
						{
							throw new InvalidCastException();
						}
						class2 = new Class11.Class24((int)((char)object_0), (Class11.Enum1)15);
						break;
					}
					if (!true)
					{
					}
					Class11.Class24 class12 = class2;
					@class = class12;
					break;
				}
				case (Class11.Enum2)16:
				case (Class11.Enum2)17:
					@class = Class11.Class22.smethod_2(object_0);
					break;
				case (Class11.Enum2)18:
					throw new InvalidCastException();
				}
				bool isByRef = type_0.IsByRef;
				if (isByRef)
				{
					@class = new Class11.Class33(@class, type_0.GetElementType());
				}
				return @class;
			}

			// Token: 0x06000290 RID: 656 RVA: 0x00013144 File Offset: 0x00011344
			private static Class11.Class22 smethod_2(object object_0)
			{
				bool flag = object_0 != null && object_0.GetType().IsEnum;
				if (flag)
				{
					Type underlyingType = Enum.GetUnderlyingType(object_0.GetType());
					object object_ = Convert.ChangeType(object_0, underlyingType);
					Class11.Class22 @class = Class11.Class22.smethod_3(Class11.Class22.smethod_1(underlyingType, object_));
					bool flag2 = @class != null;
					if (flag2)
					{
						return @class as Class11.Class23;
					}
				}
				return new Class11.Class34(object_0);
			}

			// Token: 0x06000291 RID: 657 RVA: 0x000058A8 File Offset: 0x00003AA8
			private static Class11.Class23 smethod_3(Class11.Class22 class22_0)
			{
				Class11.Class23 @class = class22_0 as Class11.Class23;
				bool flag = @class == null && class22_0.vmethod_0();
				if (flag)
				{
					@class = (class22_0.vmethod_8() as Class11.Class23);
				}
				return @class;
			}

			// Token: 0x04000075 RID: 117
			internal Class11.Enum4 enum4_0;
		}

		// Token: 0x0200003A RID: 58
		private class Class34 : Class11.Class22
		{
			// Token: 0x06000292 RID: 658 RVA: 0x0000287C File Offset: 0x00000A7C
			public Class34() : this(null)
			{
			}

			// Token: 0x06000293 RID: 659 RVA: 0x000131AC File Offset: 0x000113AC
			internal override void vmethod_10(Class11.Class22 class22_1)
			{
				bool flag = class22_1 is Class11.Class34;
				if (flag)
				{
					this.class22_0 = ((Class11.Class34)class22_1).class22_0;
					this.type_0 = ((Class11.Class34)class22_1).type_0;
				}
				else
				{
					this.class22_0 = class22_1.vmethod_8();
				}
			}

			// Token: 0x06000294 RID: 660 RVA: 0x00002325 File Offset: 0x00000525
			internal override void vmethod_2(Class11.Class22 class22_1)
			{
				this.vmethod_10(class22_1);
			}

			// Token: 0x06000295 RID: 661 RVA: 0x00002887 File Offset: 0x00000A87
			public Class34(object object_0) : base((Class11.Enum4)0)
			{
				this.class22_0 = (Class11.Class22)object_0;
				this.type_0 = null;
			}

			// Token: 0x06000296 RID: 662 RVA: 0x000028A5 File Offset: 0x00000AA5
			public Class34(object object_0, Type type_1) : base((Class11.Enum4)0)
			{
				this.class22_0 = (Class11.Class22)object_0;
				this.type_0 = type_1;
			}

			// Token: 0x06000297 RID: 663 RVA: 0x000131FC File Offset: 0x000113FC
			public override string ToString()
			{
				bool flag = this.class22_0 == null;
				string result;
				if (flag)
				{
					result = ((Class11.Enum5)5).ToString();
				}
				else
				{
					result = this.class22_0.ToString();
				}
				return result;
			}

			// Token: 0x06000298 RID: 664 RVA: 0x0001323C File Offset: 0x0001143C
			internal override object vmethod_4(Type type_1)
			{
				bool flag = this.class22_0 != null;
				object result;
				if (flag)
				{
					bool flag2 = type_1 != null && type_1.IsByRef;
					if (flag2)
					{
						type_1 = type_1.GetElementType();
					}
					bool flag3 = this.class22_0 != null;
					if (flag3)
					{
						bool flag4 = !(this.type_0 != null);
						if (flag4)
						{
							object obj = this.class22_0.vmethod_4(type_1);
							bool flag5 = obj != null && type_1 != null && obj.GetType() != type_1;
							if (flag5)
							{
								bool flag6 = type_1 == typeof(RuntimeFieldHandle) && obj is FieldInfo;
								if (flag6)
								{
									obj = ((FieldInfo)obj).FieldHandle;
								}
								else
								{
									bool flag7 = type_1 == typeof(RuntimeTypeHandle) && obj is Type;
									if (flag7)
									{
										obj = ((Type)obj).TypeHandle;
									}
									else
									{
										bool flag8 = type_1 == typeof(RuntimeMethodHandle) && obj is MethodBase;
										if (flag8)
										{
											obj = ((MethodBase)obj).MethodHandle;
										}
									}
								}
							}
							result = obj;
						}
						else
						{
							result = this.class22_0.vmethod_4(this.type_0);
						}
					}
					else
					{
						object obj2 = this.class22_0;
						bool flag9 = obj2 != null && type_1 != null && obj2.GetType() != type_1;
						if (flag9)
						{
							bool flag10 = type_1 == typeof(RuntimeFieldHandle) && obj2 is FieldInfo;
							if (flag10)
							{
								obj2 = ((FieldInfo)obj2).FieldHandle;
							}
							else
							{
								bool flag11 = type_1 == typeof(RuntimeTypeHandle) && obj2 is Type;
								if (flag11)
								{
									obj2 = ((Type)obj2).TypeHandle;
								}
								else
								{
									bool flag12 = type_1 == typeof(RuntimeMethodHandle) && obj2 is MethodBase;
									if (flag12)
									{
										obj2 = ((MethodBase)obj2).MethodHandle;
									}
								}
							}
						}
						result = obj2;
					}
				}
				else
				{
					result = null;
				}
				return result;
			}

			// Token: 0x06000299 RID: 665 RVA: 0x00013490 File Offset: 0x00011690
			internal override bool vmethod_5(Class11.Class22 class22_1)
			{
				bool flag = class22_1.vmethod_0();
				bool result;
				if (flag)
				{
					result = ((Class11.Class28)class22_1).vmethod_5(this);
				}
				else
				{
					object obj = this.vmethod_4(null);
					object obj2 = class22_1.vmethod_4(null);
					result = (obj == obj2);
				}
				return result;
			}

			// Token: 0x0600029A RID: 666 RVA: 0x000134D0 File Offset: 0x000116D0
			internal override bool vmethod_6(Class11.Class22 class22_1)
			{
				bool flag = !class22_1.vmethod_0();
				bool result;
				if (flag)
				{
					object obj = this.vmethod_4(null);
					object obj2 = class22_1.vmethod_4(null);
					result = (obj != obj2);
				}
				else
				{
					result = ((Class11.Class28)class22_1).vmethod_6(this);
				}
				return result;
			}

			// Token: 0x0600029B RID: 667 RVA: 0x00013518 File Offset: 0x00011718
			internal override Class11.Class22 vmethod_8()
			{
				Class11.Class22 @class = this.class22_0;
				bool flag = @class != null;
				Class11.Class22 result;
				if (flag)
				{
					result = @class.vmethod_8();
				}
				else
				{
					result = this;
				}
				return result;
			}

			// Token: 0x0600029C RID: 668 RVA: 0x00013544 File Offset: 0x00011744
			internal override bool vmethod_7()
			{
				bool flag = this.class22_0 != null;
				bool result;
				if (flag)
				{
					Class11.Class22 @class = this.class22_0;
					bool flag2 = @class != null;
					if (flag2)
					{
						bool flag3 = @class.vmethod_4(null) == null;
						result = !flag3;
					}
					else
					{
						result = true;
					}
				}
				else
				{
					result = false;
				}
				return result;
			}

			// Token: 0x04000076 RID: 118
			public Class11.Class22 class22_0;

			// Token: 0x04000077 RID: 119
			public Type type_0;
		}

		// Token: 0x0200003B RID: 59
		private class Class35 : Class11.Class22
		{
			// Token: 0x0600029D RID: 669 RVA: 0x000028C3 File Offset: 0x00000AC3
			public Class35(string string_1) : base((Class11.Enum4)6)
			{
				this.string_0 = string_1;
			}

			// Token: 0x0600029E RID: 670 RVA: 0x000028D5 File Offset: 0x00000AD5
			internal override void vmethod_10(Class11.Class22 class22_0)
			{
				this.string_0 = ((Class11.Class35)class22_0).string_0;
			}

			// Token: 0x0600029F RID: 671 RVA: 0x00002325 File Offset: 0x00000525
			internal override void vmethod_2(Class11.Class22 class22_0)
			{
				this.vmethod_10(class22_0);
			}

			// Token: 0x060002A0 RID: 672 RVA: 0x00013598 File Offset: 0x00011798
			public override string ToString()
			{
				bool flag = this.string_0 == null;
				string result;
				if (flag)
				{
					result = ((Class11.Enum5)5).ToString();
				}
				else
				{
					result = "*" + this.string_0 + "*";
				}
				return result;
			}

			// Token: 0x060002A1 RID: 673 RVA: 0x000135E0 File Offset: 0x000117E0
			internal override bool vmethod_7()
			{
				return this.string_0 != null;
			}

			// Token: 0x060002A2 RID: 674 RVA: 0x000135FC File Offset: 0x000117FC
			internal override object vmethod_4(Type type_0)
			{
				return this.string_0;
			}

			// Token: 0x060002A3 RID: 675 RVA: 0x00013614 File Offset: 0x00011814
			internal override bool vmethod_5(Class11.Class22 class22_0)
			{
				bool flag = class22_0.vmethod_0();
				bool result;
				if (flag)
				{
					result = ((Class11.Class28)class22_0).vmethod_5(this);
				}
				else
				{
					string text = this.string_0;
					object obj = class22_0.vmethod_4(null);
					result = (text == obj);
				}
				return result;
			}

			// Token: 0x060002A4 RID: 676 RVA: 0x00013654 File Offset: 0x00011854
			internal override bool vmethod_6(Class11.Class22 class22_0)
			{
				bool flag = !class22_0.vmethod_0();
				bool result;
				if (flag)
				{
					string text = this.string_0;
					object obj = class22_0.vmethod_4(null);
					result = (text != obj);
				}
				else
				{
					result = ((Class11.Class28)class22_0).vmethod_6(this);
				}
				return result;
			}

			// Token: 0x060002A5 RID: 677 RVA: 0x000057CC File Offset: 0x000039CC
			internal override Class11.Class22 vmethod_8()
			{
				return this;
			}

			// Token: 0x04000078 RID: 120
			public string string_0;
		}

		// Token: 0x0200003C RID: 60
		internal class Class36
		{
			// Token: 0x060002A6 RID: 678 RVA: 0x0001369C File Offset: 0x0001189C
			public int method_0()
			{
				return this.list_0.Count;
			}

			// Token: 0x060002A7 RID: 679 RVA: 0x000028E9 File Offset: 0x00000AE9
			public void method_1()
			{
				this.list_0.Clear();
			}

			// Token: 0x060002A8 RID: 680 RVA: 0x000028F8 File Offset: 0x00000AF8
			public void method_2(Class11.Class22 class22_0)
			{
				this.list_0.Add(class22_0);
			}

			// Token: 0x060002A9 RID: 681 RVA: 0x000136BC File Offset: 0x000118BC
			public Class11.Class22 method_3()
			{
				return this.list_0[this.list_0.Count - 1];
			}

			// Token: 0x060002AA RID: 682 RVA: 0x000136E8 File Offset: 0x000118E8
			public Class11.Class22 method_4()
			{
				Class11.Class22 result = this.method_3();
				bool flag = this.list_0.Count != 0;
				if (flag)
				{
					this.list_0.RemoveAt(this.list_0.Count - 1);
				}
				return result;
			}

			// Token: 0x04000079 RID: 121
			private List<Class11.Class22> list_0 = new List<Class11.Class22>();
		}

		// Token: 0x0200003D RID: 61
		internal enum Enum5
		{

		}

		// Token: 0x0200003E RID: 62
		[CompilerGenerated]
		[Serializable]
		private sealed class Class37<T>
		{
			// Token: 0x060002AD RID: 685 RVA: 0x000126A0 File Offset: 0x000108A0
			internal int method_0(Class11.Class15 x, Class11.Class15 y)
			{
				return x.class16_0.int_0.CompareTo(y.class16_0.int_0);
			}

			// Token: 0x060002AE RID: 686 RVA: 0x00013730 File Offset: 0x00011930
			internal static bool smethod_0()
			{
				return Class11.Class37<T>.object_0 == null;
			}

			// Token: 0x060002AF RID: 687 RVA: 0x0001374C File Offset: 0x0001194C
			internal static object smethod_1()
			{
				return Class11.Class37<T>.object_0;
			}

			// Token: 0x0400007B RID: 123
			public static readonly Class11.Class37<T> _003C_003E9 = new Class11.Class37<T>();

			// Token: 0x0400007C RID: 124
			public static Comparison<Class11.Class15> _003C_003E9__45_0;

			// Token: 0x0400007D RID: 125
			internal static object object_0;
		}
	}
}
