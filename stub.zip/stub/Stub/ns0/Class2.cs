﻿using System;
using System.Management;
using Microsoft.VisualBasic.CompilerServices;

namespace ns0
{
	// Token: 0x02000040 RID: 64
	internal class Class2
	{
		// Token: 0x060002B4 RID: 692 RVA: 0x00013764 File Offset: 0x00011964
		public bool VM_Detected()
		{
			using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("Select * from Win32_ComputerSystem"))
			{
				using (ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get())
				{
					foreach (ManagementBaseObject managementBaseObject in managementObjectCollection)
					{
						string text = managementBaseObject["Manufacturer"].ToString().ToLower();
						bool flag = (Operators.CompareString(text, "microsoft corporation", false) == 0 && managementBaseObject["Model"].ToString().ToUpperInvariant().Contains("VIRTUAL")) || text.Contains("vmware") || Operators.CompareString(managementBaseObject["Model"].ToString(), "VirtualBox", false) == 0;
						if (flag)
						{
							return true;
						}
					}
				}
			}
			return false;
		}
	}
}
