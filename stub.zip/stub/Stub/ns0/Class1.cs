﻿using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.ApplicationServices;
using Microsoft.VisualBasic.CompilerServices;

namespace ns0
{
	// Token: 0x0200000F RID: 15
	[StandardModule]
	[HideModuleName]
	[GeneratedCode("MyTemplate", "11.0.0.0")]
	internal sealed class Class1
	{
		// Token: 0x17000001 RID: 1
		// (get) Token: 0x0600000A RID: 10 RVA: 0x00002244 File Offset: 0x00000444
		[HelpKeyword("My.Computer")]
		internal static Class0 Class0_0
		{
			get
			{
				return Class1.threadSafeObjectProvider_0.method_0();
			}
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x0600000B RID: 11 RVA: 0x00002250 File Offset: 0x00000450
		[HelpKeyword("My.Application")]
		internal static Form0 Form0_0
		{
			get
			{
				return Class1.threadSafeObjectProvider_1.method_0();
			}
		}

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x0600000C RID: 12 RVA: 0x0000225C File Offset: 0x0000045C
		[HelpKeyword("My.User")]
		internal static User User_0
		{
			get
			{
				return Class1.threadSafeObjectProvider_2.method_0();
			}
		}

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x0600000D RID: 13 RVA: 0x00002268 File Offset: 0x00000468
		[HelpKeyword("My.Forms")]
		internal static Class1.MyForms MyForms_0
		{
			get
			{
				return Class1.threadSafeObjectProvider_3.method_0();
			}
		}

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x0600000E RID: 14 RVA: 0x00002274 File Offset: 0x00000474
		[HelpKeyword("My.WebServices")]
		internal static Class1.MyWebServices MyWebServices_0
		{
			get
			{
				return Class1.threadSafeObjectProvider_4.method_0();
			}
		}

		// Token: 0x04000002 RID: 2
		private static readonly Class1.ThreadSafeObjectProvider<Class0> threadSafeObjectProvider_0 = new Class1.ThreadSafeObjectProvider<Class0>();

		// Token: 0x04000003 RID: 3
		private static readonly Class1.ThreadSafeObjectProvider<Form0> threadSafeObjectProvider_1 = new Class1.ThreadSafeObjectProvider<Form0>();

		// Token: 0x04000004 RID: 4
		private static readonly Class1.ThreadSafeObjectProvider<User> threadSafeObjectProvider_2 = new Class1.ThreadSafeObjectProvider<User>();

		// Token: 0x04000005 RID: 5
		private static Class1.ThreadSafeObjectProvider<Class1.MyForms> threadSafeObjectProvider_3 = new Class1.ThreadSafeObjectProvider<Class1.MyForms>();

		// Token: 0x04000006 RID: 6
		private static readonly Class1.ThreadSafeObjectProvider<Class1.MyWebServices> threadSafeObjectProvider_4 = new Class1.ThreadSafeObjectProvider<Class1.MyWebServices>();

		// Token: 0x02000010 RID: 16
		[EditorBrowsable(EditorBrowsableState.Never)]
		[MyGroupCollection("System.Windows.Forms.Form", "Create__Instance__", "Dispose__Instance__", "My.MyProject.Forms")]
		internal sealed class MyForms
		{
			// Token: 0x17000006 RID: 6
			// (get) Token: 0x06000011 RID: 17 RVA: 0x00002DD0 File Offset: 0x00000FD0
			// (set) Token: 0x06000012 RID: 18 RVA: 0x00002DFC File Offset: 0x00000FFC
			public GForm2 _o_program
			{
				get
				{
					this.gform2_0 = Class1.MyForms.smethod_0<GForm2>(this.gform2_0);
					return this.gform2_0;
				}
				set
				{
					bool flag = value != this.gform2_0;
					if (flag)
					{
						bool flag2 = value != null;
						if (flag2)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.method_0<GForm2>(ref this.gform2_0);
					}
				}
			}

			// Token: 0x17000007 RID: 7
			// (get) Token: 0x06000013 RID: 19 RVA: 0x00002E40 File Offset: 0x00001040
			// (set) Token: 0x06000014 RID: 20 RVA: 0x00002E6C File Offset: 0x0000106C
			public GForm0 empty
			{
				get
				{
					this.gform0_0 = Class1.MyForms.smethod_0<GForm0>(this.gform0_0);
					return this.gform0_0;
				}
				set
				{
					bool flag = value != this.gform0_0;
					if (flag)
					{
						bool flag2 = value != null;
						if (flag2)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.method_0<GForm0>(ref this.gform0_0);
					}
				}
			}

			// Token: 0x17000008 RID: 8
			// (get) Token: 0x06000015 RID: 21 RVA: 0x00002EB0 File Offset: 0x000010B0
			// (set) Token: 0x06000016 RID: 22 RVA: 0x00002EDC File Offset: 0x000010DC
			public GForm1 loader
			{
				get
				{
					this.gform1_0 = Class1.MyForms.smethod_0<GForm1>(this.gform1_0);
					return this.gform1_0;
				}
				set
				{
					bool flag = value != this.gform1_0;
					if (flag)
					{
						bool flag2 = value != null;
						if (flag2)
						{
							throw new ArgumentException("Property can only be set to Nothing");
						}
						this.method_0<GForm1>(ref this.gform1_0);
					}
				}
			}

			// Token: 0x06000017 RID: 23 RVA: 0x00002F20 File Offset: 0x00001120
			private static T smethod_0<T>(T gparam_0) where T : Form, new()
			{
				bool flag = gparam_0 == null || gparam_0.IsDisposed;
				if (flag)
				{
					bool flag2 = Class1.MyForms.hashtable_0 != null;
					if (flag2)
					{
						bool flag3 = Class1.MyForms.hashtable_0.ContainsKey(typeof(T));
						if (flag3)
						{
							throw new InvalidOperationException(Utils.GetResourceString("WinForms_RecursiveFormCreate", new string[0]));
						}
					}
					else
					{
						Class1.MyForms.hashtable_0 = new Hashtable();
					}
					Class1.MyForms.hashtable_0.Add(typeof(T), null);
					TargetInvocationException ex2 = null;
					object obj;
					TargetInvocationException ex3;
					bool flag4;
					TargetInvocationException ex4;
					bool flag5;
					try
					{
						return Activator.CreateInstance<T>();
					}
					catch when (delegate
					{
						// Failed to create a 'catch-when' expression
						ex3 = (obj as TargetInvocationException);
						if (ex3 == null)
						{
							flag4 = false;
						}
						else
						{
							ex4 = ex3;
							TargetInvocationException ex = ex4;
							flag5 = delegate
							{
								ex2 = ex;
								return delegate
								{
									ProjectData.SetProjectError(ex2);
									return ex2.InnerException != null;
								}();
							}();
							flag4 = (flag5 > false);
						}
						endfilter(flag4);
					})
					{
						string resourceString = Utils.GetResourceString("WinForms_SeeInnerException", new string[]
						{
							CS$<>8__locals2.CS$<>8__locals1.ex2.InnerException.Message
						});
						throw new InvalidOperationException(resourceString, CS$<>8__locals2.CS$<>8__locals1.ex2.InnerException);
					}
					finally
					{
						Class1.MyForms.hashtable_0.Remove(typeof(T));
					}
				}
				return gparam_0;
			}

			// Token: 0x06000018 RID: 24 RVA: 0x000022B5 File Offset: 0x000004B5
			private void method_0<T>(ref T gparam_0) where T : Form
			{
				gparam_0.Dispose();
				gparam_0 = default(T);
			}

			// Token: 0x06000019 RID: 25 RVA: 0x000022CC File Offset: 0x000004CC
			[EditorBrowsable(EditorBrowsableState.Never)]
			public MyForms()
			{
			}

			// Token: 0x0600001A RID: 26 RVA: 0x0000308C File Offset: 0x0000128C
			[EditorBrowsable(EditorBrowsableState.Never)]
			public override bool Equals(object obj)
			{
				return base.Equals(RuntimeHelpers.GetObjectValue(obj));
			}

			// Token: 0x0600001B RID: 27 RVA: 0x000030AC File Offset: 0x000012AC
			[EditorBrowsable(EditorBrowsableState.Never)]
			public override int GetHashCode()
			{
				return base.GetHashCode();
			}

			// Token: 0x0600001C RID: 28 RVA: 0x000030C4 File Offset: 0x000012C4
			[EditorBrowsable(EditorBrowsableState.Never)]
			internal Type method_1()
			{
				return typeof(Class1.MyForms);
			}

			// Token: 0x0600001D RID: 29 RVA: 0x000030E0 File Offset: 0x000012E0
			[EditorBrowsable(EditorBrowsableState.Never)]
			public override string ToString()
			{
				return base.ToString();
			}

			// Token: 0x04000007 RID: 7
			[ThreadStatic]
			private static Hashtable hashtable_0;

			// Token: 0x04000008 RID: 8
			[EditorBrowsable(EditorBrowsableState.Never)]
			public GForm2 gform2_0;

			// Token: 0x04000009 RID: 9
			[EditorBrowsable(EditorBrowsableState.Never)]
			public GForm0 gform0_0;

			// Token: 0x0400000A RID: 10
			[EditorBrowsable(EditorBrowsableState.Never)]
			public GForm1 gform1_0;
		}

		// Token: 0x02000013 RID: 19
		[EditorBrowsable(EditorBrowsableState.Never)]
		[MyGroupCollection("System.Web.Services.Protocols.SoapHttpClientProtocol", "Create__Instance__", "Dispose__Instance__", "")]
		internal sealed class MyWebServices
		{
			// Token: 0x06000022 RID: 34 RVA: 0x0000308C File Offset: 0x0000128C
			[EditorBrowsable(EditorBrowsableState.Never)]
			public override bool Equals(object obj)
			{
				return base.Equals(RuntimeHelpers.GetObjectValue(obj));
			}

			// Token: 0x06000023 RID: 35 RVA: 0x000030AC File Offset: 0x000012AC
			[EditorBrowsable(EditorBrowsableState.Never)]
			public override int GetHashCode()
			{
				return base.GetHashCode();
			}

			// Token: 0x06000024 RID: 36 RVA: 0x00003160 File Offset: 0x00001360
			[EditorBrowsable(EditorBrowsableState.Never)]
			internal Type method_0()
			{
				return typeof(Class1.MyWebServices);
			}

			// Token: 0x06000025 RID: 37 RVA: 0x000030E0 File Offset: 0x000012E0
			[EditorBrowsable(EditorBrowsableState.Never)]
			public override string ToString()
			{
				return base.ToString();
			}

			// Token: 0x06000026 RID: 38 RVA: 0x0000317C File Offset: 0x0000137C
			private static T smethod_0<T>(T gparam_0) where T : new()
			{
				bool flag = gparam_0 == null;
				T result;
				if (flag)
				{
					result = Activator.CreateInstance<T>();
				}
				else
				{
					result = gparam_0;
				}
				return result;
			}

			// Token: 0x06000027 RID: 39 RVA: 0x000022D6 File Offset: 0x000004D6
			private void method_1<T>(ref T gparam_0)
			{
				gparam_0 = default(T);
			}

			// Token: 0x06000028 RID: 40 RVA: 0x000022CC File Offset: 0x000004CC
			[EditorBrowsable(EditorBrowsableState.Never)]
			public MyWebServices()
			{
			}
		}

		// Token: 0x02000014 RID: 20
		[EditorBrowsable(EditorBrowsableState.Never)]
		[ComVisible(false)]
		internal sealed class ThreadSafeObjectProvider<T> where T : new()
		{
			// Token: 0x06000029 RID: 41 RVA: 0x000031A8 File Offset: 0x000013A8
			internal T method_0()
			{
				bool flag = Class1.ThreadSafeObjectProvider<T>.gparam_0 == null;
				if (flag)
				{
					Class1.ThreadSafeObjectProvider<T>.gparam_0 = Activator.CreateInstance<T>();
				}
				return Class1.ThreadSafeObjectProvider<T>.gparam_0;
			}

			// Token: 0x0600002A RID: 42 RVA: 0x000022CC File Offset: 0x000004CC
			[EditorBrowsable(EditorBrowsableState.Never)]
			public ThreadSafeObjectProvider()
			{
			}

			// Token: 0x0600002B RID: 43 RVA: 0x000031DC File Offset: 0x000013DC
			internal static bool smethod_0()
			{
				return Class1.ThreadSafeObjectProvider<T>.object_0 == null;
			}

			// Token: 0x0600002C RID: 44 RVA: 0x000031F8 File Offset: 0x000013F8
			internal static object smethod_1()
			{
				return Class1.ThreadSafeObjectProvider<T>.object_0;
			}

			// Token: 0x0400000E RID: 14
			[ThreadStatic]
			[CompilerGenerated]
			private static T gparam_0;

			// Token: 0x0400000F RID: 15
			internal static object object_0;
		}
	}
}
