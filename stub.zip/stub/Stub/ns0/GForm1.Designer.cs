﻿namespace ns0
{
	// Token: 0x02000058 RID: 88
	[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
	public partial class GForm1 : global::System.Windows.Forms.Form
	{
		// Token: 0x0600039C RID: 924 RVA: 0x00017464 File Offset: 0x00015664
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.idisposable_0 != null;
				if (flag)
				{
					this.idisposable_0.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x040000B2 RID: 178
		private global::System.IDisposable idisposable_0;
	}
}
