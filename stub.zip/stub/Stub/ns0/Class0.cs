﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using Microsoft.VisualBasic.Devices;

namespace ns0
{
	// Token: 0x0200000E RID: 14
	[EditorBrowsable(EditorBrowsableState.Never)]
	[GeneratedCode("MyTemplate", "11.0.0.0")]
	internal class Class0 : Computer
	{
		// Token: 0x06000009 RID: 9 RVA: 0x0000223A File Offset: 0x0000043A
		[EditorBrowsable(EditorBrowsableState.Never)]
		public Class0()
		{
		}
	}
}
