﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using Microsoft.VisualBasic.CompilerServices;

namespace ns0
{
	// Token: 0x02000057 RID: 87
	[DesignerGenerated]
	public partial class GForm0 : Form
	{
		// Token: 0x17000009 RID: 9
		// (get) Token: 0x06000395 RID: 917 RVA: 0x00017068 File Offset: 0x00015268
		// (set) Token: 0x06000396 RID: 918 RVA: 0x00002B82 File Offset: 0x00000D82
		internal virtual Label g1 { get; set; }

		// Token: 0x06000397 RID: 919 RVA: 0x00002B8C File Offset: 0x00000D8C
		public GForm0()
		{
			base.FormClosing += this.GForm0_FormClosing;
			this.method_0();
		}

		// Token: 0x06000399 RID: 921 RVA: 0x000170D0 File Offset: 0x000152D0
		private void method_0()
		{
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(GForm0));
			this.g1 = new Label();
			base.SuspendLayout();
			this.g1.Dock = DockStyle.Fill;
			this.g1.Font = new Font("Lucida Console", 48f, FontStyle.Regular, GraphicsUnit.Point, 204);
			this.g1.ForeColor = Color.Red;
			this.g1.Location = new Point(0, 0);
			this.g1.Name = "g1";
			this.g1.Size = new Size(874, 408);
			this.g1.TabIndex = 1;
			this.g1.Text = ":3";
			this.g1.TextAlign = ContentAlignment.MiddleCenter;
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.Black;
			base.ClientSize = new Size(874, 408);
			base.Controls.Add(this.g1);
			base.FormBorderStyle = FormBorderStyle.None;
			base.Icon = (Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "empty";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = FormStartPosition.CenterScreen;
			base.TopMost = true;
			base.WindowState = FormWindowState.Maximized;
			base.ResumeLayout(false);
		}

		// Token: 0x0600039A RID: 922 RVA: 0x00002BB0 File Offset: 0x00000DB0
		private void GForm0_FormClosing(object sender, FormClosingEventArgs e)
		{
			e.Cancel = true;
		}

		// Token: 0x040000B1 RID: 177
		[CompilerGenerated]
		[AccessedThroughProperty("g1")]
		private Label label_0;
	}
}
