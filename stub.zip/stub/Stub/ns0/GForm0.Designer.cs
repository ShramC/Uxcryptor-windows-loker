﻿namespace ns0
{
	// Token: 0x02000057 RID: 87
	[global::Microsoft.VisualBasic.CompilerServices.DesignerGenerated]
	public partial class GForm0 : global::System.Windows.Forms.Form
	{
		// Token: 0x06000398 RID: 920 RVA: 0x00017080 File Offset: 0x00015280
		protected override void Dispose(bool disposing)
		{
			try
			{
				bool flag = disposing && this.idisposable_0 != null;
				if (flag)
				{
					this.idisposable_0.Dispose();
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x040000B0 RID: 176
		private global::System.IDisposable idisposable_0;
	}
}
