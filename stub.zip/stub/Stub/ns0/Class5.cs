﻿using System;
using System.Reflection;

namespace ns0
{
	// Token: 0x02000043 RID: 67
	internal class Class5
	{
		// Token: 0x060002BC RID: 700 RVA: 0x00013898 File Offset: 0x00011A98
		internal static void smethod_0(int typemdt)
		{
			Type type = Class5.module_0.ResolveType(33554432 + typemdt);
			FieldInfo[] fields = type.GetFields();
			FieldInfo[] array = fields;
			foreach (FieldInfo fieldInfo in array)
			{
				MethodInfo method = (MethodInfo)Class5.module_0.ResolveMethod(fieldInfo.MetadataToken + 100663296);
				fieldInfo.SetValue(null, (MulticastDelegate)Delegate.CreateDelegate(type, method));
			}
		}

		// Token: 0x060002BD RID: 701 RVA: 0x0001278C File Offset: 0x0001098C
		public bool SandBox_Detected()
		{
			return false;
		}

		// Token: 0x04000080 RID: 128
		internal static Module module_0 = typeof(Class5).Assembly.ManifestModule;

		// Token: 0x02000044 RID: 68
		// (Invoke) Token: 0x060002C1 RID: 705
		internal delegate void Delegate0(object o);
	}
}
