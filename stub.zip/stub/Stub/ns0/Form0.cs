﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Windows.Forms;
using Microsoft.VisualBasic.ApplicationServices;

namespace ns0
{
	// Token: 0x02000056 RID: 86
	[GeneratedCode("MyTemplate", "11.0.0.0")]
	[EditorBrowsable(EditorBrowsableState.Never)]
	internal class Form0 : WindowsFormsApplicationBase
	{
		// Token: 0x06000392 RID: 914 RVA: 0x0001702C File Offset: 0x0001522C
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		[STAThread]
		internal static void Main(string[] args)
		{
			try
			{
				Application.SetCompatibleTextRenderingDefault(WindowsFormsApplicationBase.UseCompatibleTextRendering);
			}
			finally
			{
			}
			Class1.Form0_0.Run(args);
		}

		// Token: 0x06000393 RID: 915 RVA: 0x00002B43 File Offset: 0x00000D43
		public Form0() : base(AuthenticationMode.Windows)
		{
			base.IsSingleInstance = true;
			base.EnableVisualStyles = false;
			base.SaveMySettingsOnExit = false;
			base.ShutdownStyle = ShutdownMode.AfterMainFormCloses;
		}

		// Token: 0x06000394 RID: 916 RVA: 0x00002B6E File Offset: 0x00000D6E
		protected override void OnCreateMainForm()
		{
			base.MainForm = Class1.MyForms_0.loader;
		}
	}
}
