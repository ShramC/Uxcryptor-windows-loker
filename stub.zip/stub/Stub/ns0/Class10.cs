﻿using System;

namespace ns0
{
	// Token: 0x02000015 RID: 21
	internal class Class10
	{
		// Token: 0x04000010 RID: 16
		private static bool bool_0;
	}
}
