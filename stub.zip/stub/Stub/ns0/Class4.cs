﻿using System;

namespace ns0
{
	// Token: 0x02000042 RID: 66
	internal sealed class Class4
	{
		// Token: 0x060002B9 RID: 697 RVA: 0x0001278C File Offset: 0x0001098C
		public bool SandBox_Detected()
		{
			return false;
		}

		// Token: 0x060002BA RID: 698 RVA: 0x0001278C File Offset: 0x0001098C
		public bool AnyRun_Detected()
		{
			return false;
		}
	}
}
