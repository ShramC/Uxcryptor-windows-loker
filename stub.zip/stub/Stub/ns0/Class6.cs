﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace ns0
{
	// Token: 0x02000045 RID: 69
	internal class Class6
	{
		// Token: 0x060002C4 RID: 708 RVA: 0x00013914 File Offset: 0x00011B14
		static Class6()
		{
			Class6.uint_0 = new uint[]
			{
				3614090360U,
				3905402710U,
				606105819U,
				3250441966U,
				4118548399U,
				1200080426U,
				2821735955U,
				4249261313U,
				1770035416U,
				2336552879U,
				4294925233U,
				2304563134U,
				1804603682U,
				4254626195U,
				2792965006U,
				1236535329U,
				4129170786U,
				3225465664U,
				643717713U,
				3921069994U,
				3593408605U,
				38016083U,
				3634488961U,
				3889429448U,
				568446438U,
				3275163606U,
				4107603335U,
				1163531501U,
				2850285829U,
				4243563512U,
				1735328473U,
				2368359562U,
				4294588738U,
				2272392833U,
				1839030562U,
				4259657740U,
				2763975236U,
				1272893353U,
				4139469664U,
				3200236656U,
				681279174U,
				3936430074U,
				3572445317U,
				76029189U,
				3654602809U,
				3873151461U,
				530742520U,
				3299628645U,
				4096336452U,
				1126891415U,
				2878612391U,
				4237533241U,
				1700485571U,
				2399980690U,
				4293915773U,
				2240044497U,
				1873313359U,
				4264355552U,
				2734768916U,
				1309151649U,
				4149444226U,
				3174756917U,
				718787259U,
				3951481745U
			};
			Class6.bool_4 = false;
			Class6.bool_0 = false;
			Class6.object_2 = null;
			Class6.dictionary_0 = null;
			Class6.object_0 = new object();
			Class6.int_4 = 0;
			Class6.object_1 = new object();
			Class6.list_0 = null;
			Class6.list_1 = null;
			Class6.byte_1 = new byte[0];
			Class6.byte_0 = new byte[0];
			Class6.intptr_3 = IntPtr.Zero;
			Class6.intptr_2 = IntPtr.Zero;
			Class6.string_0 = new string[0];
			Class6.int_5 = new int[0];
			Class6.int_2 = 1;
			Class6.bool_3 = false;
			Class6.sortedList_0 = new SortedList();
			Class6.int_3 = 0;
			Class6.long_1 = 0L;
			Class6.delegate2_0 = null;
			Class6.delegate2_1 = null;
			Class6.long_0 = 0L;
			Class6.int_1 = 0;
			Class6.bool_2 = false;
			Class6.bool_6 = false;
			Class6.int_0 = 0;
			Class6.intptr_1 = IntPtr.Zero;
			Class6.bool_1 = false;
			Class6.hashtable_0 = new Hashtable();
			Class6.delegate4_0 = null;
			Class6.delegate5_0 = null;
			Class6.delegate6_0 = null;
			Class6.delegate7_0 = null;
			Class6.delegate8_0 = null;
			Class6.delegate9_0 = null;
			Class6.intptr_0 = IntPtr.Zero;
			Class6.string_1 = Encoding.Unicode.GetString(new byte[]
			{
				134,
				123,
				241,
				8,
				24,
				98,
				77,
				199
			});
			try
			{
				RSACryptoServiceProvider.UseMachineKeyStore = true;
			}
			catch
			{
			}
		}

		// Token: 0x060002C5 RID: 709 RVA: 0x00002951 File Offset: 0x00000B51
		private void method_0()
		{
		}

		// Token: 0x060002C6 RID: 710 RVA: 0x00013AA8 File Offset: 0x00011CA8
		internal static byte[] smethod_0(object object_3)
		{
			uint[] array = new uint[16];
			uint num = (uint)((448 - ((Array)object_3).Length * 8 % 512 + 512) % 512);
			bool flag = num == 0U;
			if (flag)
			{
				num = 512U;
			}
			uint num2 = (uint)((long)((Array)object_3).Length + (long)((ulong)(num / 8U)) + 8L);
			ulong num3 = (ulong)((long)((Array)object_3).Length * 8L);
			byte[] array2 = new byte[num2];
			for (int i = 0; i < ((Array)object_3).Length; i++)
			{
				array2[i] = ((byte[])object_3)[i];
			}
			byte[] array3 = array2;
			int length = ((Array)object_3).Length;
			array3[length] |= 128;
			for (int j = 8; j > 0; j--)
			{
				array2[(int)(checked((IntPtr)(unchecked((ulong)num2 - (ulong)((long)j)))))] = (byte)(num3 >> (8 - j) * 8 & 255UL);
			}
			uint num4 = (uint)(array2.Length * 8 / 32);
			uint num5 = 1732584193U;
			uint num6 = 4023233417U;
			uint num7 = 2562383102U;
			uint num8 = 271733878U;
			for (uint num9 = 0U; num9 < num4 / 16U; num9 += 1U)
			{
				uint num10 = num9 << 6;
				for (uint num11 = 0U; num11 < 61U; num11 += 4U)
				{
					array[(int)(num11 >> 2)] = (uint)((int)array2[(int)(num10 + (num11 + 3U))] << 24 | (int)array2[(int)(num10 + (num11 + 2U))] << 16 | (int)array2[(int)(num10 + (num11 + 1U))] << 8 | (int)array2[(int)(num10 + num11)]);
				}
				uint num12 = num5;
				uint num13 = num6;
				uint num14 = num7;
				uint num15 = num8;
				Class6.smethod_1(ref num5, num6, num7, num8, 0U, 7, 1U, array);
				Class6.smethod_1(ref num8, num5, num6, num7, 1U, 12, 2U, array);
				Class6.smethod_1(ref num7, num8, num5, num6, 2U, 17, 3U, array);
				Class6.smethod_1(ref num6, num7, num8, num5, 3U, 22, 4U, array);
				Class6.smethod_1(ref num5, num6, num7, num8, 4U, 7, 5U, array);
				Class6.smethod_1(ref num8, num5, num6, num7, 5U, 12, 6U, array);
				Class6.smethod_1(ref num7, num8, num5, num6, 6U, 17, 7U, array);
				Class6.smethod_1(ref num6, num7, num8, num5, 7U, 22, 8U, array);
				Class6.smethod_1(ref num5, num6, num7, num8, 8U, 7, 9U, array);
				Class6.smethod_1(ref num8, num5, num6, num7, 9U, 12, 10U, array);
				Class6.smethod_1(ref num7, num8, num5, num6, 10U, 17, 11U, array);
				Class6.smethod_1(ref num6, num7, num8, num5, 11U, 22, 12U, array);
				Class6.smethod_1(ref num5, num6, num7, num8, 12U, 7, 13U, array);
				Class6.smethod_1(ref num8, num5, num6, num7, 13U, 12, 14U, array);
				Class6.smethod_1(ref num7, num8, num5, num6, 14U, 17, 15U, array);
				Class6.smethod_1(ref num6, num7, num8, num5, 15U, 22, 16U, array);
				Class6.smethod_2(ref num5, num6, num7, num8, 1U, 5, 17U, array);
				Class6.smethod_2(ref num8, num5, num6, num7, 6U, 9, 18U, array);
				Class6.smethod_2(ref num7, num8, num5, num6, 11U, 14, 19U, array);
				Class6.smethod_2(ref num6, num7, num8, num5, 0U, 20, 20U, array);
				Class6.smethod_2(ref num5, num6, num7, num8, 5U, 5, 21U, array);
				Class6.smethod_2(ref num8, num5, num6, num7, 10U, 9, 22U, array);
				Class6.smethod_2(ref num7, num8, num5, num6, 15U, 14, 23U, array);
				Class6.smethod_2(ref num6, num7, num8, num5, 4U, 20, 24U, array);
				Class6.smethod_2(ref num5, num6, num7, num8, 9U, 5, 25U, array);
				Class6.smethod_2(ref num8, num5, num6, num7, 14U, 9, 26U, array);
				Class6.smethod_2(ref num7, num8, num5, num6, 3U, 14, 27U, array);
				Class6.smethod_2(ref num6, num7, num8, num5, 8U, 20, 28U, array);
				Class6.smethod_2(ref num5, num6, num7, num8, 13U, 5, 29U, array);
				Class6.smethod_2(ref num8, num5, num6, num7, 2U, 9, 30U, array);
				Class6.smethod_2(ref num7, num8, num5, num6, 7U, 14, 31U, array);
				Class6.smethod_2(ref num6, num7, num8, num5, 12U, 20, 32U, array);
				Class6.smethod_3(ref num5, num6, num7, num8, 5U, 4, 33U, array);
				Class6.smethod_3(ref num8, num5, num6, num7, 8U, 11, 34U, array);
				Class6.smethod_3(ref num7, num8, num5, num6, 11U, 16, 35U, array);
				Class6.smethod_3(ref num6, num7, num8, num5, 14U, 23, 36U, array);
				Class6.smethod_3(ref num5, num6, num7, num8, 1U, 4, 37U, array);
				Class6.smethod_3(ref num8, num5, num6, num7, 4U, 11, 38U, array);
				Class6.smethod_3(ref num7, num8, num5, num6, 7U, 16, 39U, array);
				Class6.smethod_3(ref num6, num7, num8, num5, 10U, 23, 40U, array);
				Class6.smethod_3(ref num5, num6, num7, num8, 13U, 4, 41U, array);
				Class6.smethod_3(ref num8, num5, num6, num7, 0U, 11, 42U, array);
				Class6.smethod_3(ref num7, num8, num5, num6, 3U, 16, 43U, array);
				Class6.smethod_3(ref num6, num7, num8, num5, 6U, 23, 44U, array);
				Class6.smethod_3(ref num5, num6, num7, num8, 9U, 4, 45U, array);
				Class6.smethod_3(ref num8, num5, num6, num7, 12U, 11, 46U, array);
				Class6.smethod_3(ref num7, num8, num5, num6, 15U, 16, 47U, array);
				Class6.smethod_3(ref num6, num7, num8, num5, 2U, 23, 48U, array);
				Class6.smethod_4(ref num5, num6, num7, num8, 0U, 6, 49U, array);
				Class6.smethod_4(ref num8, num5, num6, num7, 7U, 10, 50U, array);
				Class6.smethod_4(ref num7, num8, num5, num6, 14U, 15, 51U, array);
				Class6.smethod_4(ref num6, num7, num8, num5, 5U, 21, 52U, array);
				Class6.smethod_4(ref num5, num6, num7, num8, 12U, 6, 53U, array);
				Class6.smethod_4(ref num8, num5, num6, num7, 3U, 10, 54U, array);
				Class6.smethod_4(ref num7, num8, num5, num6, 10U, 15, 55U, array);
				Class6.smethod_4(ref num6, num7, num8, num5, 1U, 21, 56U, array);
				Class6.smethod_4(ref num5, num6, num7, num8, 8U, 6, 57U, array);
				Class6.smethod_4(ref num8, num5, num6, num7, 15U, 10, 58U, array);
				Class6.smethod_4(ref num7, num8, num5, num6, 6U, 15, 59U, array);
				Class6.smethod_4(ref num6, num7, num8, num5, 13U, 21, 60U, array);
				Class6.smethod_4(ref num5, num6, num7, num8, 4U, 6, 61U, array);
				Class6.smethod_4(ref num8, num5, num6, num7, 11U, 10, 62U, array);
				Class6.smethod_4(ref num7, num8, num5, num6, 2U, 15, 63U, array);
				Class6.smethod_4(ref num6, num7, num8, num5, 9U, 21, 64U, array);
				num5 += num12;
				num6 += num13;
				num7 += num14;
				num8 += num15;
			}
			byte[] array4 = new byte[16];
			Array.Copy(BitConverter.GetBytes(num5), 0, array4, 0, 4);
			Array.Copy(BitConverter.GetBytes(num6), 0, array4, 4, 4);
			Array.Copy(BitConverter.GetBytes(num7), 0, array4, 8, 4);
			Array.Copy(BitConverter.GetBytes(num8), 0, array4, 12, 4);
			return array4;
		}

		// Token: 0x060002C7 RID: 711 RVA: 0x00002954 File Offset: 0x00000B54
		private static void smethod_1(ref uint uint_1, uint uint_2, uint uint_3, uint uint_4, uint uint_5, ushort ushort_0, uint uint_6, object object_3)
		{
			uint_1 = uint_2 + Class6.smethod_5(uint_1 + ((uint_2 & uint_3) | (~uint_2 & uint_4)) + ((uint[])object_3)[(int)uint_5] + Class6.uint_0[(int)(uint_6 - 1U)], ushort_0);
		}

		// Token: 0x060002C8 RID: 712 RVA: 0x00002983 File Offset: 0x00000B83
		private static void smethod_2(ref uint uint_1, uint uint_2, uint uint_3, uint uint_4, uint uint_5, ushort ushort_0, uint uint_6, object object_3)
		{
			uint_1 = uint_2 + Class6.smethod_5(uint_1 + ((uint_2 & uint_4) | (uint_3 & ~uint_4)) + ((uint[])object_3)[(int)uint_5] + Class6.uint_0[(int)(uint_6 - 1U)], ushort_0);
		}

		// Token: 0x060002C9 RID: 713 RVA: 0x000029B2 File Offset: 0x00000BB2
		private static void smethod_3(ref uint uint_1, uint uint_2, uint uint_3, uint uint_4, uint uint_5, ushort ushort_0, uint uint_6, object object_3)
		{
			uint_1 = uint_2 + Class6.smethod_5(uint_1 + (uint_2 ^ uint_3 ^ uint_4) + ((uint[])object_3)[(int)uint_5] + Class6.uint_0[(int)(uint_6 - 1U)], ushort_0);
		}

		// Token: 0x060002CA RID: 714 RVA: 0x000029DE File Offset: 0x00000BDE
		private static void smethod_4(ref uint uint_1, uint uint_2, uint uint_3, uint uint_4, uint uint_5, ushort ushort_0, uint uint_6, object object_3)
		{
			uint_1 = uint_2 + Class6.smethod_5(uint_1 + (uint_3 ^ (uint_2 | ~uint_4)) + ((uint[])object_3)[(int)uint_5] + Class6.uint_0[(int)(uint_6 - 1U)], ushort_0);
		}

		// Token: 0x060002CB RID: 715 RVA: 0x000141D0 File Offset: 0x000123D0
		private static uint smethod_5(uint uint_1, ushort ushort_0)
		{
			return uint_1 >> (int)(32 - ushort_0) | uint_1 << (int)ushort_0;
		}

		// Token: 0x060002CC RID: 716 RVA: 0x000141F4 File Offset: 0x000123F4
		internal static bool smethod_6()
		{
			bool flag = !Class6.bool_4;
			if (flag)
			{
				Class6.smethod_8();
				Class6.bool_4 = true;
			}
			return Class6.bool_0;
		}

		// Token: 0x060002CD RID: 717 RVA: 0x000022CC File Offset: 0x000004CC
		internal Class6()
		{
		}

		// Token: 0x060002CE RID: 718 RVA: 0x00014228 File Offset: 0x00012428
		private void method_1(byte[] byte_2, byte[] byte_3, byte[] byte_4)
		{
			int num = byte_4.Length % 4;
			int num2 = byte_4.Length / 4;
			byte[] array = new byte[byte_4.Length];
			int num3 = byte_2.Length / 4;
			uint num4 = 0U;
			bool flag = num > 0;
			if (flag)
			{
				num2++;
			}
			for (int i = 0; i < num2; i++)
			{
				int num5 = i % num3;
				int num6 = i * 4;
				uint num7 = (uint)(num5 * 4);
				uint num8 = (uint)((int)byte_2[(int)(num7 + 3U)] << 24 | (int)byte_2[(int)(num7 + 2U)] << 16 | (int)byte_2[(int)(num7 + 1U)] << 8 | (int)byte_2[(int)num7]);
				uint num9 = 255U;
				int num10 = 0;
				bool flag2 = i == num2 - 1 && num > 0;
				uint num11;
				if (flag2)
				{
					num11 = 0U;
					num4 += num8;
					for (int j = 0; j < num; j++)
					{
						bool flag3 = j > 0;
						if (flag3)
						{
							num11 <<= 8;
						}
						num11 |= (uint)byte_4[byte_4.Length - (1 + j)];
					}
				}
				else
				{
					num4 += num8;
					num7 = (uint)num6;
					num11 = (uint)((int)byte_4[(int)(num7 + 3U)] << 24 | (int)byte_4[(int)(num7 + 2U)] << 16 | (int)byte_4[(int)(num7 + 1U)] << 8 | (int)byte_4[(int)num7]);
				}
				uint num12 = num4;
				uint num13 = num12;
				num13 ^= num13 << 17;
				num13 += 594440812U;
				num13 ^= num13 >> 3;
				num13 += 727323298U;
				num13 ^= num13 << 4;
				num13 += 2650447031U;
				num13 = 3206817792U - num13;
				num4 = num12 + (uint)num13;
				bool flag4 = i == num2 - 1 && num > 0;
				if (flag4)
				{
					uint num14 = num4 ^ num11;
					for (int k = 0; k < num; k++)
					{
						bool flag5 = k > 0;
						if (flag5)
						{
							num9 <<= 8;
							num10 += 8;
						}
						array[num6 + k] = (byte)((num14 & num9) >> num10);
					}
				}
				else
				{
					uint num15 = num4 ^ num11;
					array[num6] = (byte)(num15 & 255U);
					array[num6 + 1] = (byte)((num15 & 65280U) >> 8);
					array[num6 + 2] = (byte)((num15 & 16711680U) >> 16);
					array[num6 + 3] = (byte)((num15 & 4278190080U) >> 24);
				}
			}
			Class6.byte_1 = array;
		}

		// Token: 0x060002CF RID: 719 RVA: 0x00014464 File Offset: 0x00012664
		internal static SymmetricAlgorithm smethod_7()
		{
			bool flag = Class6.smethod_6();
			SymmetricAlgorithm result;
			if (flag)
			{
				result = new AesCryptoServiceProvider();
			}
			else
			{
				try
				{
					result = new RijndaelManaged();
				}
				catch
				{
					result = (SymmetricAlgorithm)Activator.CreateInstance("System.Core, Version=3.5.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089", "System.Security.Cryptography.AesCryptoServiceProvider").Unwrap();
				}
			}
			return result;
		}

		// Token: 0x060002D0 RID: 720 RVA: 0x000144C0 File Offset: 0x000126C0
		internal static void smethod_8()
		{
			try
			{
				Class6.bool_0 = CryptoConfig.AllowOnlyFipsAlgorithms;
			}
			catch
			{
			}
		}

		// Token: 0x060002D1 RID: 721 RVA: 0x000144F4 File Offset: 0x000126F4
		internal static byte[] smethod_9(byte[] byte_2)
		{
			bool flag = !Class6.smethod_6();
			byte[] result;
			if (flag)
			{
				result = new MD5CryptoServiceProvider().ComputeHash(byte_2);
			}
			else
			{
				result = Class6.smethod_0(byte_2);
			}
			return result;
		}

		// Token: 0x060002D2 RID: 722 RVA: 0x00014528 File Offset: 0x00012728
		internal static void smethod_10(HashAlgorithm hashAlgorithm_0, Stream stream_0, uint uint_1, byte[] byte_2)
		{
			while (uint_1 > 0U)
			{
				int num = (uint_1 > (uint)byte_2.Length) ? byte_2.Length : ((int)uint_1);
				stream_0.Read(byte_2, 0, num);
				Class6.smethod_11(hashAlgorithm_0, byte_2, 0, num);
				uint_1 -= (uint)num;
			}
		}

		// Token: 0x060002D3 RID: 723 RVA: 0x00002A0B File Offset: 0x00000C0B
		internal static void smethod_11(HashAlgorithm hashAlgorithm_0, byte[] byte_2, int int_6, int int_7)
		{
			hashAlgorithm_0.TransformBlock(byte_2, int_6, int_7, byte_2, int_6);
		}

		// Token: 0x060002D4 RID: 724 RVA: 0x00014568 File Offset: 0x00012768
		internal static uint smethod_12(uint uint_1, int int_6, long long_2, BinaryReader binaryReader_0)
		{
			int num = 0;
			uint num3;
			uint num4;
			for (;;)
			{
				bool flag = num < int_6;
				if (!flag)
				{
					goto IL_5E;
				}
				binaryReader_0.BaseStream.Position = long_2 + (long)(num * 40 + 8);
				uint num2 = binaryReader_0.ReadUInt32();
				num3 = binaryReader_0.ReadUInt32();
				binaryReader_0.ReadUInt32();
				num4 = binaryReader_0.ReadUInt32();
				bool flag2 = num3 <= uint_1 && uint_1 < num3 + num2;
				if (flag2)
				{
					break;
				}
				num++;
			}
			return num4 + uint_1 - num3;
			IL_5E:
			return 0U;
		}

		// Token: 0x060002D5 RID: 725 RVA: 0x00002A1A File Offset: 0x00000C1A
		private static void smethod_13(object object_3, int int_6)
		{
			Class11.smethod_2(0, new object[]
			{
				object_3,
				int_6
			}, null);
		}

		// Token: 0x060002D6 RID: 726 RVA: 0x000145E8 File Offset: 0x000127E8
		internal static string smethod_14(string string_2)
		{
			"{11111-22222-50001-00000}".Trim();
			byte[] array = Convert.FromBase64String(string_2);
			return Encoding.Unicode.GetString(array, 0, array.Length);
		}

		// Token: 0x060002D7 RID: 727 RVA: 0x0001461C File Offset: 0x0001281C
		internal static uint smethod_15(IntPtr intptr_4, IntPtr intptr_5, IntPtr intptr_6, [MarshalAs(UnmanagedType.U4)] uint uint_1, IntPtr intptr_7, ref uint uint_2)
		{
			IntPtr ptr = intptr_6;
			bool flag = Class6.bool_5;
			if (flag)
			{
				ptr = intptr_5;
			}
			long num = (IntPtr.Size != 4) ? Marshal.ReadInt64(ptr, IntPtr.Size * 2) : ((long)Marshal.ReadInt32(ptr, IntPtr.Size * 2));
			object obj = Class6.hashtable_0[num];
			bool flag2 = obj != null;
			uint result;
			if (flag2)
			{
				Class6.Struct0 @struct = (Class6.Struct0)obj;
				IntPtr intPtr = Marshal.AllocCoTaskMem(@struct.byte_0.Length);
				Marshal.Copy(@struct.byte_0, 0, intPtr, @struct.byte_0.Length);
				bool flag3 = @struct.bool_0;
				if (flag3)
				{
					intptr_7 = intPtr;
					uint_2 = (uint)@struct.byte_0.Length;
					Class6.smethod_24(intptr_7, @struct.byte_0.Length, 64, ref Class6.int_0);
					result = 0U;
				}
				else
				{
					Marshal.WriteIntPtr(ptr, IntPtr.Size * 2, intPtr);
					Marshal.WriteInt32(ptr, IntPtr.Size * 3, @struct.byte_0.Length);
					uint num2 = 0U;
					bool flag4 = uint_1 == 216669565U && !Class6.bool_1;
					if (flag4)
					{
						Class6.bool_1 = true;
					}
					else
					{
						num2 = Class6.delegate2_0(intptr_4, intptr_5, intptr_6, uint_1, intptr_7, ref uint_2);
					}
					result = num2;
				}
			}
			else
			{
				result = Class6.delegate2_0(intptr_4, intptr_5, intptr_6, uint_1, intptr_7, ref uint_2);
			}
			return result;
		}

		// Token: 0x060002D8 RID: 728 RVA: 0x00014770 File Offset: 0x00012970
		private static int smethod_16()
		{
			return 5;
		}

		// Token: 0x060002D9 RID: 729 RVA: 0x00014784 File Offset: 0x00012984
		private static void smethod_17()
		{
			try
			{
				RSACryptoServiceProvider.UseMachineKeyStore = true;
			}
			catch
			{
			}
		}

		// Token: 0x060002DA RID: 730 RVA: 0x000147B4 File Offset: 0x000129B4
		private static Delegate smethod_18(IntPtr intptr_4, Type type_0)
		{
			return (Delegate)typeof(Marshal).GetMethod("GetDelegateForFunctionPointer", new Type[]
			{
				typeof(IntPtr),
				typeof(Type)
			}).Invoke(null, new object[]
			{
				intptr_4,
				type_0
			});
		}

		// Token: 0x060002DB RID: 731 RVA: 0x00014818 File Offset: 0x00012A18
		internal unsafe static void smethod_19()
		{
			bool flag = Class6.bool_3;
			if (!flag)
			{
				Class6.bool_3 = true;
				long num = 0L;
				Marshal.ReadIntPtr(new IntPtr((void*)(&num)), 0);
				Marshal.ReadInt32(new IntPtr((void*)(&num)), 0);
				Marshal.ReadInt64(new IntPtr((void*)(&num)), 0);
				Marshal.WriteIntPtr(new IntPtr((void*)(&num)), 0, IntPtr.Zero);
				Marshal.WriteInt32(new IntPtr((void*)(&num)), 0, 0);
				Marshal.WriteInt64(new IntPtr((void*)(&num)), 0, 0L);
				Marshal.Copy(new byte[1], 0, Marshal.AllocCoTaskMem(8), 1);
				Class6.smethod_17();
				bool flag2 = IntPtr.Size == 4 && Type.GetType("System.Reflection.ReflectionContext", false) != null;
				if (flag2)
				{
					foreach (object obj in Process.GetCurrentProcess().Modules)
					{
						ProcessModule processModule = (ProcessModule)obj;
						bool flag3 = processModule.ModuleName.ToLower() == "clrjit.dll";
						if (flag3)
						{
							Version v = new Version(processModule.FileVersionInfo.ProductMajorPart, processModule.FileVersionInfo.ProductMinorPart, processModule.FileVersionInfo.ProductBuildPart, processModule.FileVersionInfo.ProductPrivatePart);
							Version v2 = new Version(4, 0, 30319, 17020);
							Version v3 = new Version(4, 0, 30319, 17921);
							bool flag4 = v >= v2 && v < v3;
							if (flag4)
							{
								Class6.bool_5 = true;
								break;
							}
						}
					}
				}
				Class6.Class9 @class = new Class6.Class9(Class6.assembly_0.GetManifestResourceStream("\u0095\u008a1a\u008d3\u008de\u0097v6\u0090\u0092\u0095q\u009dkm.2v\u009digp\u008e\u008c09w2l\u008f\u008aqbt"));
				@class.method_0().Position = 0L;
				byte[] array = @class.method_1((int)@class.method_0().Length);
				byte[] array2 = new byte[32];
				array2[0] = 169;
				array2[0] = 72;
				array2[0] = 145;
				array2[0] = 64;
				array2[0] = 199;
				array2[1] = 168;
				array2[1] = 125;
				array2[1] = 128;
				array2[2] = 85;
				array2[2] = 109;
				array2[2] = 39;
				array2[3] = 92;
				array2[3] = 39;
				array2[3] = 168;
				array2[3] = 226;
				array2[4] = 108;
				array2[4] = 41;
				array2[4] = 215;
				array2[5] = 155;
				array2[5] = 95;
				array2[5] = 253;
				array2[6] = 132;
				array2[6] = 72;
				array2[6] = 122;
				array2[6] = 165;
				array2[6] = 159;
				array2[7] = 146;
				array2[7] = 104;
				array2[7] = 142;
				array2[7] = 156;
				array2[7] = 228;
				array2[8] = 154;
				array2[8] = 168;
				array2[8] = 100;
				array2[8] = 133;
				array2[8] = 86;
				array2[9] = 95;
				array2[9] = 209;
				array2[9] = 129;
				array2[9] = 162;
				array2[9] = 39;
				array2[10] = 125;
				array2[10] = 104;
				array2[10] = 161;
				array2[10] = 172;
				array2[11] = 99;
				array2[11] = 159;
				array2[11] = 210;
				array2[11] = 150;
				array2[11] = 128;
				array2[11] = 137;
				array2[12] = 119;
				array2[12] = 120;
				array2[12] = 98;
				array2[12] = 127;
				array2[12] = 129;
				array2[13] = 196;
				array2[13] = 168;
				array2[13] = 118;
				array2[13] = 130;
				array2[14] = 108;
				array2[14] = 154;
				array2[14] = 35;
				array2[15] = 156;
				array2[15] = 139;
				array2[15] = 140;
				array2[15] = 115;
				array2[15] = 28;
				array2[15] = 4;
				array2[16] = 140;
				array2[16] = 132;
				array2[16] = 172;
				array2[16] = 114;
				array2[16] = 121;
				array2[17] = 160;
				array2[17] = 125;
				array2[17] = 82;
				array2[17] = 117;
				array2[17] = 77;
				array2[17] = 13;
				array2[18] = 135;
				array2[18] = 162;
				array2[18] = 156;
				array2[18] = 174;
				array2[18] = 134;
				array2[18] = 91;
				array2[19] = 132;
				array2[19] = 139;
				array2[19] = 164;
				array2[19] = 172;
				array2[19] = 174;
				array2[20] = 160;
				array2[20] = 118;
				array2[20] = 124;
				array2[20] = 21;
				array2[21] = 198;
				array2[21] = 104;
				array2[21] = 103;
				array2[22] = 98;
				array2[22] = 162;
				array2[22] = 41;
				array2[22] = 130;
				array2[22] = 172;
				array2[22] = 82;
				array2[23] = 141;
				array2[23] = 100;
				array2[23] = 104;
				array2[23] = 68;
				array2[24] = 128;
				array2[24] = 168;
				array2[24] = 110;
				array2[24] = 205;
				array2[25] = 90;
				array2[25] = 94;
				array2[25] = 89;
				array2[25] = 160;
				array2[25] = 57;
				array2[25] = 119;
				array2[26] = 213;
				array2[26] = 105;
				array2[26] = 154;
				array2[26] = 154;
				array2[26] = 55;
				array2[26] = 95;
				array2[27] = 102;
				array2[27] = 169;
				array2[27] = 213;
				array2[28] = 145;
				array2[28] = 133;
				array2[28] = 82;
				array2[29] = 224;
				array2[29] = 93;
				array2[29] = 128;
				array2[29] = 170;
				array2[30] = 129;
				array2[30] = 116;
				array2[30] = 172;
				array2[31] = 68;
				array2[31] = 151;
				array2[31] = 39;
				byte[] array3 = array2;
				byte[] array4 = new byte[16];
				array4[0] = 169;
				array4[0] = 127;
				array4[0] = 88;
				array4[0] = 109;
				array4[0] = 108;
				array4[0] = 13;
				array4[1] = 88;
				array4[1] = 110;
				array4[1] = 41;
				array4[2] = 109;
				array4[2] = 70;
				array4[2] = 39;
				array4[2] = 74;
				array4[3] = 112;
				array4[3] = 90;
				array4[3] = 98;
				array4[4] = 86;
				array4[4] = 116;
				array4[4] = 95;
				array4[4] = 103;
				array4[4] = 104;
				array4[4] = 210;
				array4[5] = 83;
				array4[5] = 165;
				array4[5] = 160;
				array4[5] = 86;
				array4[6] = 104;
				array4[6] = 142;
				array4[6] = 156;
				array4[6] = 39;
				array4[7] = 154;
				array4[7] = 168;
				array4[7] = 122;
				array4[8] = 114;
				array4[8] = 108;
				array4[8] = 121;
				array4[8] = 32;
				array4[9] = 168;
				array4[9] = 85;
				array4[9] = 174;
				array4[10] = 98;
				array4[10] = 125;
				array4[10] = 91;
				array4[10] = 175;
				array4[10] = 156;
				array4[10] = 208;
				array4[11] = 102;
				array4[11] = 218;
				array4[11] = 126;
				array4[11] = 38;
				array4[11] = 210;
				array4[12] = 177;
				array4[12] = 176;
				array4[12] = 125;
				array4[12] = 161;
				array4[12] = 204;
				array4[13] = 96;
				array4[13] = 139;
				array4[13] = 125;
				array4[13] = 103;
				array4[13] = 82;
				array4[13] = 217;
				array4[14] = 143;
				array4[14] = 156;
				array4[14] = 112;
				array4[14] = 121;
				array4[14] = 208;
				array4[15] = 140;
				array4[15] = 115;
				array4[15] = 95;
				array4[15] = 239;
				byte[] array5 = array4;
				Array.Reverse(array5);
				byte[] publicKeyToken = Class6.assembly_0.GetName().GetPublicKeyToken();
				bool flag5 = publicKeyToken != null && publicKeyToken.Length != 0;
				if (flag5)
				{
					array5[1] = publicKeyToken[0];
					array5[3] = publicKeyToken[1];
					array5[5] = publicKeyToken[2];
					array5[7] = publicKeyToken[3];
					array5[9] = publicKeyToken[4];
					array5[11] = publicKeyToken[5];
					array5[13] = publicKeyToken[6];
					array5[15] = publicKeyToken[7];
					Array.Clear(publicKeyToken, 0, publicKeyToken.Length);
				}
				for (int i = 0; i < array5.Length; i++)
				{
					byte[] array6 = array3;
					int num2 = i;
					array6[num2] ^= array5[i];
				}
				byte[] array7 = array;
				int num3 = array7.Length % 4;
				int num4 = array7.Length / 4;
				byte[] array8 = new byte[array7.Length];
				int num5 = array3.Length / 4;
				uint num6 = 0U;
				bool flag6 = num3 > 0;
				if (flag6)
				{
					num4++;
				}
				for (int j = 0; j < num4; j++)
				{
					int num7 = j % num5;
					int num8 = j * 4;
					uint num9 = (uint)(num7 * 4);
					uint num10 = (uint)((int)array3[(int)(num9 + 3U)] << 24 | (int)array3[(int)(num9 + 2U)] << 16 | (int)array3[(int)(num9 + 1U)] << 8 | (int)array3[(int)num9]);
					uint num11 = 255U;
					int num12 = 0;
					bool flag7 = j == num4 - 1 && num3 > 0;
					uint num13;
					if (flag7)
					{
						num6 += num10;
						num13 = 0U;
						for (int k = 0; k < num3; k++)
						{
							bool flag8 = k > 0;
							if (flag8)
							{
								num13 <<= 8;
							}
							num13 |= (uint)array7[array7.Length - (1 + k)];
						}
					}
					else
					{
						num9 = (uint)num8;
						num6 += num10;
						num13 = (uint)((int)array7[(int)(num9 + 3U)] << 24 | (int)array7[(int)(num9 + 2U)] << 16 | (int)array7[(int)(num9 + 1U)] << 8 | (int)array7[(int)num9]);
					}
					num6 = num6;
					uint num14 = num6;
					uint num15 = num6;
					num15 ^= num15 << 17;
					num15 += 594440812U;
					num15 ^= num15 >> 3;
					num15 += 727323298U;
					num15 ^= num15 << 4;
					num15 += 2650447031U;
					num15 = 3206817792U - num15;
					num6 = num14 + (uint)num15;
					bool flag9 = j == num4 - 1 && num3 > 0;
					if (flag9)
					{
						uint num16 = num6 ^ num13;
						for (int l = 0; l < num3; l++)
						{
							bool flag10 = l > 0;
							if (flag10)
							{
								num11 <<= 8;
								num12 += 8;
							}
							array8[num8 + l] = (byte)((num16 & num11) >> num12);
						}
					}
					else
					{
						uint num17 = num6 ^ num13;
						array8[num8] = (byte)(num17 & 255U);
						array8[num8 + 1] = (byte)((num17 & 65280U) >> 8);
						array8[num8 + 2] = (byte)((num17 & 16711680U) >> 16);
						array8[num8 + 3] = (byte)((num17 & 4278190080U) >> 24);
					}
				}
				byte[] array9 = array8;
				int num18 = array9.Length / 8;
				byte[] array10;
				byte* ptr;
				if ((array10 = array9) == null || array10.Length == 0)
				{
					ptr = null;
				}
				else
				{
					ptr = &array10[0];
				}
				for (int m = 0; m < num18; m++)
				{
					*(long*)(ptr + m * 8) ^= 1867892290L;
				}
				array10 = null;
				@class = new Class6.Class9(new MemoryStream(array9));
				@class.method_0().Position = 0L;
				long num19 = Marshal.GetHINSTANCE(Class6.assembly_0.GetModules()[0]).ToInt64();
				int int_ = 0;
				int num20 = 0;
				bool flag11 = Class6.assembly_0.Location == null || Class6.assembly_0.Location.Length == 0;
				if (flag11)
				{
					num20 = 7680;
				}
				@class.method_3();
				@class.method_3();
				int num21 = @class.method_3();
				int num22 = @class.method_3();
				bool flag12 = num22 == 4;
				if (flag12)
				{
					SymmetricAlgorithm symmetricAlgorithm = Class6.smethod_7();
					symmetricAlgorithm.Mode = CipherMode.CBC;
					ICryptoTransform transform = symmetricAlgorithm.CreateDecryptor(array3, array5);
					Array.Clear(array3, 0, array3.Length);
					MemoryStream memoryStream = new MemoryStream();
					CryptoStream cryptoStream = new CryptoStream(memoryStream, transform, CryptoStreamMode.Write);
					cryptoStream.Write(array, 0, array.Length);
					cryptoStream.FlushFinalBlock();
					array9 = memoryStream.ToArray();
					Array.Clear(array5, 0, array5.Length);
					memoryStream.Close();
					cryptoStream.Close();
					@class.method_4();
					num21 = @class.method_3();
					num22 = @class.method_3();
				}
				bool flag13 = num22 == 1;
				if (flag13)
				{
					IntPtr intptr_ = IntPtr.Zero;
					intptr_ = Class6.smethod_25(56U, 1, (uint)Process.GetCurrentProcess().Id);
					bool flag14 = IntPtr.Size == 4;
					if (flag14)
					{
						Class6.int_3 = Marshal.GetHINSTANCE(Class6.assembly_0.GetModules()[0]).ToInt32();
					}
					Class6.long_1 = Marshal.GetHINSTANCE(Class6.assembly_0.GetModules()[0]).ToInt64();
					IntPtr zero = IntPtr.Zero;
					for (int n = 0; n < num21; n++)
					{
						IntPtr intPtr = new IntPtr(Class6.long_1 + (long)@class.method_3() - (long)num20);
						bool flag15 = Class6.smethod_24(intPtr, 4, 4, ref int_) == 0;
						if (flag15)
						{
							Class6.smethod_24(intPtr, 4, 8, ref int_);
						}
						bool flag16 = IntPtr.Size == 4;
						if (flag16)
						{
							Class6.smethod_23(intptr_, intPtr, BitConverter.GetBytes(@class.method_3()), 4U, out zero);
						}
						else
						{
							Class6.smethod_23(intptr_, intPtr, BitConverter.GetBytes(@class.method_3()), 4U, out zero);
						}
						Class6.smethod_24(intPtr, 4, int_, ref int_);
					}
					while (@class.method_0().Position < @class.method_0().Length - 1L)
					{
						int num23 = @class.method_3();
						IntPtr intptr_2 = new IntPtr(Class6.long_1 + (long)num23 - (long)num20);
						int num24 = @class.method_3();
						bool flag17 = Class6.smethod_24(intptr_2, num24 * 4, 4, ref int_) == 0;
						if (flag17)
						{
							Class6.smethod_24(intptr_2, num24 * 4, 8, ref int_);
						}
						for (int num25 = 0; num25 < num24; num25++)
						{
							Marshal.WriteInt32(new IntPtr(intptr_2.ToInt64() + (long)(num25 * 4)), @class.method_3());
						}
						Class6.smethod_24(intptr_2, num24 * 4, int_, ref int_);
					}
					Class6.smethod_26(intptr_);
				}
				else
				{
					for (int num26 = 0; num26 < num21; num26++)
					{
						IntPtr intPtr2 = new IntPtr(num19 + (long)@class.method_3() - (long)num20);
						bool flag18 = Class6.smethod_24(intPtr2, 4, 4, ref int_) == 0;
						if (flag18)
						{
							Class6.smethod_24(intPtr2, 4, 8, ref int_);
						}
						Marshal.WriteInt32(intPtr2, @class.method_3());
						Class6.smethod_24(intPtr2, 4, int_, ref int_);
					}
					Class6.hashtable_0 = new Hashtable(@class.method_3() + 1);
					Class6.Struct0 @struct = new Class6.Struct0
					{
						byte_0 = new byte[]
						{
							42
						},
						bool_0 = false
					};
					Class6.hashtable_0.Add(0L, @struct);
					while (@class.method_0().Position < @class.method_0().Length - 1L)
					{
						int num27 = @class.method_3() - num20;
						int num28 = @class.method_3();
						bool flag19 = false;
						bool flag20 = num28 >= 1879048192;
						if (flag20)
						{
							flag19 = true;
						}
						int num29 = @class.method_3();
						byte[] array11 = @class.method_1(num29);
						Class6.Struct0 struct2 = new Class6.Struct0
						{
							byte_0 = array11,
							bool_0 = flag19
						};
						Class6.hashtable_0.Add(num19 + (long)num27, struct2);
					}
					Class6.long_0 = Marshal.GetHINSTANCE(typeof(Class6).Assembly.GetModules()[0]).ToInt64();
					bool flag21 = IntPtr.Size == 4;
					if (flag21)
					{
						Class6.int_1 = Convert.ToInt32(Class6.long_0);
					}
					byte[] bytes = new byte[]
					{
						109,
						115,
						99,
						111,
						114,
						106,
						105,
						116,
						46,
						100,
						108,
						108
					};
					string @string = Encoding.UTF8.GetString(bytes);
					IntPtr intPtr3 = Class6.LoadLibrary(@string);
					bool flag22 = intPtr3 == IntPtr.Zero;
					if (flag22)
					{
						bytes = new byte[]
						{
							99,
							108,
							114,
							106,
							105,
							116,
							46,
							100,
							108,
							108
						};
						@string = Encoding.UTF8.GetString(bytes);
						intPtr3 = Class6.LoadLibrary(@string);
					}
					byte[] bytes2 = new byte[]
					{
						103,
						101,
						116,
						74,
						105,
						116
					};
					string string2 = Encoding.UTF8.GetString(bytes2);
					IntPtr ptr2 = ((Class6.Delegate3)Class6.smethod_18(Class6.GetProcAddress(intPtr3, string2), typeof(Class6.Delegate3)))();
					long value = 0L;
					value = ((IntPtr.Size != 4) ? Marshal.ReadInt64(ptr2) : ((long)Marshal.ReadInt32(ptr2)));
					Marshal.ReadIntPtr(ptr2, 0);
					Class6.Delegate2 @delegate;
					if ((@delegate = Class6.<>O.<0>__smethod_15) == null)
					{
						@delegate = (Class6.<>O.<0>__smethod_15 = new Class6.Delegate2(Class6.smethod_15));
					}
					Class6.delegate2_1 = @delegate;
					IntPtr intPtr4 = IntPtr.Zero;
					intPtr4 = Marshal.GetFunctionPointerForDelegate(Class6.delegate2_1);
					long num30 = 0L;
					num30 = ((IntPtr.Size != 4) ? Marshal.ReadInt64(new IntPtr(value)) : ((long)Marshal.ReadInt32(new IntPtr(value))));
					Process currentProcess = Process.GetCurrentProcess();
					try
					{
						foreach (object obj2 in currentProcess.Modules)
						{
							ProcessModule processModule2 = (ProcessModule)obj2;
							bool flag23 = processModule2.ModuleName == @string && (num30 < processModule2.BaseAddress.ToInt64() || num30 > processModule2.BaseAddress.ToInt64() + (long)processModule2.ModuleMemorySize) && typeof(Class6).Assembly.EntryPoint != null;
							if (flag23)
							{
								return;
							}
						}
					}
					catch
					{
					}
					try
					{
						foreach (object obj3 in currentProcess.Modules)
						{
							ProcessModule processModule3 = (ProcessModule)obj3;
							bool flag24 = processModule3.BaseAddress.ToInt64() == Class6.long_0;
							if (flag24)
							{
								break;
							}
						}
					}
					catch
					{
					}
					Class6.delegate2_0 = null;
					try
					{
						Class6.delegate2_0 = (Class6.Delegate2)Class6.smethod_18(new IntPtr(num30), typeof(Class6.Delegate2));
					}
					catch
					{
						try
						{
							Delegate delegate2 = Class6.smethod_18(new IntPtr(num30), typeof(Class6.Delegate2));
							Class6.delegate2_0 = (Class6.Delegate2)Delegate.CreateDelegate(typeof(Class6.Delegate2), delegate2.Method);
						}
						catch
						{
						}
					}
					int int_2 = 0;
					bool flag25 = typeof(Class6).Assembly.EntryPoint != null && typeof(Class6).Assembly.EntryPoint.GetParameters().Length == 2 && typeof(Class6).Assembly.Location != null && typeof(Class6).Assembly.Location.Length > 0;
					if (!flag25)
					{
						try
						{
							object value2 = typeof(Class6).Assembly.ManifestModule.ModuleHandle.GetType().GetField("m_ptr", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).GetValue(typeof(Class6).Assembly.ManifestModule.ModuleHandle);
							bool flag26 = value2 is IntPtr;
							if (flag26)
							{
								Class6.intptr_1 = (IntPtr)value2;
							}
							bool flag27 = value2.GetType().ToString() == "System.Reflection.RuntimeModule";
							if (flag27)
							{
								Class6.intptr_1 = (IntPtr)value2.GetType().GetField("m_pData", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).GetValue(value2);
							}
							MemoryStream memoryStream2 = new MemoryStream();
							memoryStream2.Write(new byte[IntPtr.Size], 0, IntPtr.Size);
							bool flag28 = IntPtr.Size == 4;
							if (flag28)
							{
								memoryStream2.Write(BitConverter.GetBytes(Class6.intptr_1.ToInt32()), 0, 4);
							}
							else
							{
								memoryStream2.Write(BitConverter.GetBytes(Class6.intptr_1.ToInt64()), 0, 8);
							}
							memoryStream2.Write(new byte[IntPtr.Size], 0, IntPtr.Size);
							memoryStream2.Write(new byte[IntPtr.Size], 0, IntPtr.Size);
							memoryStream2.Position = 0L;
							byte[] array12 = memoryStream2.ToArray();
							memoryStream2.Close();
							uint num31 = 0U;
							try
							{
								byte* value3;
								if ((array10 = array12) == null || array10.Length == 0)
								{
									value3 = null;
								}
								else
								{
									value3 = &array10[0];
								}
								Class6.delegate2_1(new IntPtr((void*)value3), new IntPtr((void*)value3), new IntPtr((void*)value3), 216669565U, new IntPtr((void*)value3), ref num31);
							}
							finally
							{
								array10 = null;
							}
						}
						catch
						{
						}
						RuntimeHelpers.PrepareDelegate(Class6.delegate2_0);
						RuntimeHelpers.PrepareMethod(Class6.delegate2_0.Method.MethodHandle);
						RuntimeHelpers.PrepareDelegate(Class6.delegate2_1);
						RuntimeHelpers.PrepareMethod(Class6.delegate2_1.Method.MethodHandle);
						byte[] array13;
						if (IntPtr.Size == 4)
						{
							RuntimeHelpers.InitializeArray(array13 = new byte[30], fieldof(<PrivateImplementationDetails>.D5B7247C497788CF0031CEB06E3DF77A45FEF59F1E49633DC7159816D64759B5).FieldHandle);
						}
						else
						{
							RuntimeHelpers.InitializeArray(array13 = new byte[40], fieldof(<PrivateImplementationDetails>.0E448EF5E5E60630BDDB19388CB6378436E3C65D03DD66DA7C6EBFF563BD857A).FieldHandle);
						}
						byte[] array14 = array13;
						IntPtr intPtr5 = Class6.smethod_22(IntPtr.Zero, (uint)array14.Length, 4096U, 64U);
						byte[] array15 = array14;
						bool flag29 = IntPtr.Size == 4;
						byte[] bytes3;
						byte[] bytes4;
						byte[] bytes5;
						if (flag29)
						{
							bytes3 = BitConverter.GetBytes(Class6.intptr_1.ToInt32());
							bytes4 = BitConverter.GetBytes(intPtr4.ToInt32());
							bytes5 = BitConverter.GetBytes(Convert.ToInt32(num30));
						}
						else
						{
							bytes3 = BitConverter.GetBytes(Class6.intptr_1.ToInt64());
							bytes4 = BitConverter.GetBytes(intPtr4.ToInt64());
							bytes5 = BitConverter.GetBytes(num30);
						}
						bool flag30 = IntPtr.Size == 4;
						if (flag30)
						{
							array15[9] = bytes3[0];
							array15[10] = bytes3[1];
							array15[11] = bytes3[2];
							array15[12] = bytes3[3];
							array15[16] = bytes5[0];
							array15[17] = bytes5[1];
							array15[18] = bytes5[2];
							array15[19] = bytes5[3];
							array15[23] = bytes4[0];
							array15[24] = bytes4[1];
							array15[25] = bytes4[2];
							array15[26] = bytes4[3];
						}
						else
						{
							array15[2] = bytes3[0];
							array15[3] = bytes3[1];
							array15[4] = bytes3[2];
							array15[5] = bytes3[3];
							array15[6] = bytes3[4];
							array15[7] = bytes3[5];
							array15[8] = bytes3[6];
							array15[9] = bytes3[7];
							array15[18] = bytes5[0];
							array15[19] = bytes5[1];
							array15[20] = bytes5[2];
							array15[21] = bytes5[3];
							array15[22] = bytes5[4];
							array15[23] = bytes5[5];
							array15[24] = bytes5[6];
							array15[25] = bytes5[7];
							array15[30] = bytes4[0];
							array15[31] = bytes4[1];
							array15[32] = bytes4[2];
							array15[33] = bytes4[3];
							array15[34] = bytes4[4];
							array15[35] = bytes4[5];
							array15[36] = bytes4[6];
							array15[37] = bytes4[7];
						}
						Marshal.Copy(array15, 0, intPtr5, array15.Length);
						Class6.bool_2 = false;
						Class6.smethod_24(new IntPtr(value), IntPtr.Size, 64, ref int_2);
						Marshal.WriteIntPtr(new IntPtr(value), intPtr5);
						Class6.smethod_24(new IntPtr(value), IntPtr.Size, int_2, ref int_2);
					}
				}
			}
		}

		// Token: 0x060002DC RID: 732 RVA: 0x000160EC File Offset: 0x000142EC
		internal static object smethod_20(Assembly assembly_1)
		{
			try
			{
				bool flag = File.Exists(assembly_1.Location);
				if (flag)
				{
					return assembly_1.Location;
				}
			}
			catch
			{
			}
			try
			{
				bool flag2 = File.Exists(assembly_1.GetName().CodeBase.ToString().Replace("file:///", ""));
				if (flag2)
				{
					return assembly_1.GetName().CodeBase.ToString().Replace("file:///", "");
				}
			}
			catch
			{
			}
			try
			{
				bool flag3 = File.Exists(assembly_1.GetType().GetProperty("Location").GetValue(assembly_1, new object[0]).ToString());
				if (flag3)
				{
					return assembly_1.GetType().GetProperty("Location").GetValue(assembly_1, new object[0]).ToString();
				}
			}
			catch
			{
			}
			return "";
		}

		// Token: 0x060002DD RID: 733
		[DllImport("kernel32")]
		public static extern IntPtr LoadLibrary(string string_2);

		// Token: 0x060002DE RID: 734
		[DllImport("kernel32", CharSet = CharSet.Ansi)]
		public static extern IntPtr GetProcAddress(IntPtr intptr_4, string string_2);

		// Token: 0x060002DF RID: 735 RVA: 0x00016200 File Offset: 0x00014400
		private static IntPtr smethod_21(IntPtr intptr_4, string string_2, uint uint_1)
		{
			bool flag = Class6.delegate4_0 == null;
			if (flag)
			{
				Class6.delegate4_0 = (Class6.Delegate4)Marshal.GetDelegateForFunctionPointer(Class6.GetProcAddress(Class6.smethod_27(), "Find ".Trim() + "ResourceA"), typeof(Class6.Delegate4));
			}
			return Class6.delegate4_0(intptr_4, string_2, uint_1);
		}

		// Token: 0x060002E0 RID: 736 RVA: 0x00016264 File Offset: 0x00014464
		private static IntPtr smethod_22(IntPtr intptr_4, uint uint_1, uint uint_2, uint uint_3)
		{
			bool flag = Class6.delegate5_0 == null;
			if (flag)
			{
				Class6.delegate5_0 = (Class6.Delegate5)Marshal.GetDelegateForFunctionPointer(Class6.GetProcAddress(Class6.smethod_27(), "Virtual ".Trim() + "Alloc"), typeof(Class6.Delegate5));
			}
			return Class6.delegate5_0(intptr_4, uint_1, uint_2, uint_3);
		}

		// Token: 0x060002E1 RID: 737 RVA: 0x000162CC File Offset: 0x000144CC
		private static int smethod_23(IntPtr intptr_4, IntPtr intptr_5, [In] [Out] byte[] byte_2, uint uint_1, out IntPtr intptr_6)
		{
			bool flag = Class6.delegate6_0 == null;
			if (flag)
			{
				Class6.delegate6_0 = (Class6.Delegate6)Marshal.GetDelegateForFunctionPointer(Class6.GetProcAddress(Class6.smethod_27(), "Write ".Trim() + "Process ".Trim() + "Memory"), typeof(Class6.Delegate6));
			}
			return Class6.delegate6_0(intptr_4, intptr_5, byte_2, uint_1, out intptr_6);
		}

		// Token: 0x060002E2 RID: 738 RVA: 0x00016340 File Offset: 0x00014540
		private static int smethod_24(IntPtr intptr_4, int int_6, int int_7, ref int int_8)
		{
			bool flag = Class6.delegate7_0 == null;
			if (flag)
			{
				Class6.delegate7_0 = (Class6.Delegate7)Marshal.GetDelegateForFunctionPointer(Class6.GetProcAddress(Class6.smethod_27(), "Virtual ".Trim() + "Protect"), typeof(Class6.Delegate7));
			}
			return Class6.delegate7_0(intptr_4, int_6, int_7, ref int_8);
		}

		// Token: 0x060002E3 RID: 739 RVA: 0x000163A8 File Offset: 0x000145A8
		private static IntPtr smethod_25(uint uint_1, int int_6, uint uint_2)
		{
			bool flag = Class6.delegate8_0 == null;
			if (flag)
			{
				Class6.delegate8_0 = (Class6.Delegate8)Marshal.GetDelegateForFunctionPointer(Class6.GetProcAddress(Class6.smethod_27(), "Open ".Trim() + "Process"), typeof(Class6.Delegate8));
			}
			return Class6.delegate8_0(uint_1, int_6, uint_2);
		}

		// Token: 0x060002E4 RID: 740 RVA: 0x0001640C File Offset: 0x0001460C
		private static int smethod_26(IntPtr intptr_4)
		{
			bool flag = Class6.delegate9_0 == null;
			if (flag)
			{
				Class6.delegate9_0 = (Class6.Delegate9)Marshal.GetDelegateForFunctionPointer(Class6.GetProcAddress(Class6.smethod_27(), "Close ".Trim() + "Handle"), typeof(Class6.Delegate9));
			}
			return Class6.delegate9_0(intptr_4);
		}

		// Token: 0x060002E5 RID: 741 RVA: 0x00016470 File Offset: 0x00014670
		private static IntPtr smethod_27()
		{
			bool flag = Class6.intptr_0 == IntPtr.Zero;
			if (flag)
			{
				Class6.intptr_0 = Class6.LoadLibrary("kernel ".Trim() + "32.dll");
			}
			return Class6.intptr_0;
		}

		// Token: 0x060002E6 RID: 742 RVA: 0x000164BC File Offset: 0x000146BC
		private static byte[] smethod_28(string string_2)
		{
			byte[] result;
			using (FileStream fileStream = new FileStream(string_2, FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				int num = 0;
				int i = (int)fileStream.Length;
				byte[] array = new byte[i];
				while (i > 0)
				{
					int num2 = fileStream.Read(array, num, i);
					num += num2;
					i -= num2;
				}
				result = array;
			}
			return result;
		}

		// Token: 0x060002E7 RID: 743 RVA: 0x0001652C File Offset: 0x0001472C
		internal static byte[] smethod_29(MemoryStream memoryStream_0)
		{
			return memoryStream_0.ToArray();
		}

		// Token: 0x060002E8 RID: 744 RVA: 0x00016544 File Offset: 0x00014744
		private static byte[] smethod_30(byte[] byte_2)
		{
			Stream stream = new MemoryStream();
			SymmetricAlgorithm symmetricAlgorithm = Class6.smethod_7();
			symmetricAlgorithm.Key = new byte[]
			{
				105,
				76,
				70,
				88,
				60,
				78,
				108,
				143,
				158,
				7,
				141,
				194,
				24,
				202,
				152,
				85,
				169,
				88,
				247,
				75,
				115,
				106,
				121,
				73,
				15,
				11,
				240,
				98,
				59,
				69,
				94,
				178
			};
			symmetricAlgorithm.IV = new byte[]
			{
				121,
				103,
				52,
				190,
				196,
				220,
				74,
				126,
				100,
				188,
				95,
				128,
				47,
				51,
				100,
				173
			};
			CryptoStream cryptoStream = new CryptoStream(stream, symmetricAlgorithm.CreateDecryptor(), CryptoStreamMode.Write);
			cryptoStream.Write(byte_2, 0, byte_2.Length);
			cryptoStream.Close();
			return Class6.smethod_29((MemoryStream)stream);
		}

		// Token: 0x060002E9 RID: 745 RVA: 0x000165C0 File Offset: 0x000147C0
		internal static bool smethod_32(string string_2, string string_3)
		{
			bool flag = string_2 == string_3;
			bool result;
			if (flag)
			{
				result = true;
			}
			else
			{
				bool flag2 = string_2 != null && string_3 != null;
				if (flag2)
				{
					bool flag3 = false;
					bool flag4 = false;
					int num = 0;
					int num2 = 0;
					bool flag5 = string_2.StartsWith(Class6.string_1);
					if (flag5)
					{
						flag3 = true;
						num = (int)(string_2[4] | (int)string_2[5] << 8 | (int)string_2[6] << 16 | (int)string_2[7] << 24);
					}
					bool flag6 = string_3.StartsWith(Class6.string_1);
					if (flag6)
					{
						flag4 = true;
						num2 = (int)(string_3[4] | (int)string_3[5] << 8 | (int)string_3[6] << 16 | (int)string_3[7] << 24);
					}
					bool flag7 = !flag3 && !flag4;
					if (flag7)
					{
						result = false;
					}
					else
					{
						bool flag8 = !flag3;
						if (flag8)
						{
						}
						bool flag9 = !flag4;
						if (flag9)
						{
						}
						result = (num == num2);
					}
				}
				else
				{
					result = false;
				}
			}
			return result;
		}

		// Token: 0x060002EA RID: 746 RVA: 0x000166B8 File Offset: 0x000148B8
		private byte[] method_2()
		{
			return null;
		}

		// Token: 0x060002EB RID: 747 RVA: 0x000166B8 File Offset: 0x000148B8
		private byte[] method_3()
		{
			return null;
		}

		// Token: 0x060002EC RID: 748 RVA: 0x000166CC File Offset: 0x000148CC
		private byte[] method_4()
		{
			int length = "{11111-22222-20001-00001}".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x060002ED RID: 749 RVA: 0x000166F8 File Offset: 0x000148F8
		private byte[] method_5()
		{
			int length = "{11111-22222-20001-00002}".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x060002EE RID: 750 RVA: 0x000166B8 File Offset: 0x000148B8
		private byte[] method_6()
		{
			return null;
		}

		// Token: 0x060002EF RID: 751 RVA: 0x000166B8 File Offset: 0x000148B8
		private byte[] method_7()
		{
			return null;
		}

		// Token: 0x060002F0 RID: 752 RVA: 0x00016724 File Offset: 0x00014924
		internal byte[] method_8()
		{
			int length = "{11111-22222-40001-00001}".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x060002F1 RID: 753 RVA: 0x00016750 File Offset: 0x00014950
		internal byte[] method_9()
		{
			int length = "{11111-22222-40001-00002}".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x060002F2 RID: 754 RVA: 0x0001677C File Offset: 0x0001497C
		internal byte[] method_10()
		{
			int length = "{11111-22222-50001-00001}".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x060002F3 RID: 755 RVA: 0x000167A8 File Offset: 0x000149A8
		internal byte[] method_11()
		{
			int length = "{11111-22222-50001-00002}".Length;
			return new byte[]
			{
				1,
				2
			};
		}

		// Token: 0x060002F4 RID: 756 RVA: 0x000167D4 File Offset: 0x000149D4
		internal static object smethod_33(Class6.Class9 class9_0)
		{
			return class9_0.method_0();
		}

		// Token: 0x060002F5 RID: 757 RVA: 0x00002A38 File Offset: 0x00000C38
		internal static void smethod_34(Stream stream_0, long long_2)
		{
			stream_0.Position = long_2;
		}

		// Token: 0x060002F6 RID: 758 RVA: 0x000167EC File Offset: 0x000149EC
		internal static long smethod_35(Stream stream_0)
		{
			return stream_0.Length;
		}

		// Token: 0x060002F7 RID: 759 RVA: 0x00016804 File Offset: 0x00014A04
		internal static object smethod_36(Class6.Class9 class9_0, int int_6)
		{
			return class9_0.method_1(int_6);
		}

		// Token: 0x060002F8 RID: 760 RVA: 0x00002A43 File Offset: 0x00000C43
		internal static void smethod_37(Class6.Class9 class9_0)
		{
			class9_0.method_4();
		}

		// Token: 0x060002F9 RID: 761 RVA: 0x00002A4D File Offset: 0x00000C4D
		internal static void smethod_38(Array array_0)
		{
			Array.Reverse(array_0);
		}

		// Token: 0x060002FA RID: 762 RVA: 0x00016820 File Offset: 0x00014A20
		internal static object smethod_39(Assembly assembly_1)
		{
			return assembly_1.GetName();
		}

		// Token: 0x060002FB RID: 763 RVA: 0x00016838 File Offset: 0x00014A38
		internal static object smethod_40(AssemblyName assemblyName_0)
		{
			return assemblyName_0.GetPublicKeyToken();
		}

		// Token: 0x060002FC RID: 764 RVA: 0x00016850 File Offset: 0x00014A50
		internal static object smethod_41()
		{
			return Class6.smethod_7();
		}

		// Token: 0x060002FD RID: 765 RVA: 0x00002A57 File Offset: 0x00000C57
		internal static void smethod_42(SymmetricAlgorithm symmetricAlgorithm_0, CipherMode cipherMode_0)
		{
			symmetricAlgorithm_0.Mode = cipherMode_0;
		}

		// Token: 0x060002FE RID: 766 RVA: 0x00016868 File Offset: 0x00014A68
		internal static object smethod_43(SymmetricAlgorithm symmetricAlgorithm_0, byte[] byte_2, byte[] byte_3)
		{
			return symmetricAlgorithm_0.CreateDecryptor(byte_2, byte_3);
		}

		// Token: 0x060002FF RID: 767 RVA: 0x00016884 File Offset: 0x00014A84
		internal static object smethod_44()
		{
			return new MemoryStream();
		}

		// Token: 0x06000300 RID: 768 RVA: 0x00002A62 File Offset: 0x00000C62
		internal static void smethod_45(Stream stream_0, byte[] byte_2, int int_6, int int_7)
		{
			stream_0.Write(byte_2, int_6, int_7);
		}

		// Token: 0x06000301 RID: 769 RVA: 0x00002A6F File Offset: 0x00000C6F
		internal static void smethod_46(CryptoStream cryptoStream_0)
		{
			cryptoStream_0.FlushFinalBlock();
		}

		// Token: 0x06000302 RID: 770 RVA: 0x0001689C File Offset: 0x00014A9C
		internal static object smethod_47(MemoryStream memoryStream_0)
		{
			return Class6.smethod_29(memoryStream_0);
		}

		// Token: 0x06000303 RID: 771 RVA: 0x00002A79 File Offset: 0x00000C79
		internal static void smethod_48(Stream stream_0)
		{
			stream_0.Close();
		}

		// Token: 0x06000304 RID: 772 RVA: 0x000168B4 File Offset: 0x00014AB4
		internal static object smethod_49(Assembly assembly_1)
		{
			return assembly_1.EntryPoint;
		}

		// Token: 0x06000305 RID: 773 RVA: 0x000168CC File Offset: 0x00014ACC
		internal static bool smethod_50(MethodInfo methodInfo_0, MethodInfo methodInfo_1)
		{
			return methodInfo_0 == methodInfo_1;
		}

		// Token: 0x06000306 RID: 774 RVA: 0x000057E0 File Offset: 0x000039E0
		internal static bool smethod_51()
		{
			return true;
		}

		// Token: 0x06000307 RID: 775 RVA: 0x000168E8 File Offset: 0x00014AE8
		internal static object smethod_52()
		{
			return null;
		}

		// Token: 0x06000308 RID: 776 RVA: 0x000168FC File Offset: 0x00014AFC
		private static int Y49()
		{
			return 1;
		}

		// Token: 0x06000309 RID: 777 RVA: 0x00016910 File Offset: 0x00014B10
		internal static IntPtr smethod_53(IntPtr intptr_4, int int_6)
		{
			return Marshal.ReadIntPtr(intptr_4, int_6);
		}

		// Token: 0x0600030A RID: 778 RVA: 0x0001692C File Offset: 0x00014B2C
		internal static int smethod_54(IntPtr intptr_4, int int_6)
		{
			return Marshal.ReadInt32(intptr_4, int_6);
		}

		// Token: 0x0600030B RID: 779 RVA: 0x00016948 File Offset: 0x00014B48
		internal static long smethod_55(IntPtr intptr_4, int int_6)
		{
			return Marshal.ReadInt64(intptr_4, int_6);
		}

		// Token: 0x0600030C RID: 780 RVA: 0x00002A83 File Offset: 0x00000C83
		internal static void smethod_56(IntPtr intptr_4, int int_6, IntPtr intptr_5)
		{
			Marshal.WriteIntPtr(intptr_4, int_6, intptr_5);
		}

		// Token: 0x0600030D RID: 781 RVA: 0x00002A8F File Offset: 0x00000C8F
		internal static void smethod_57(IntPtr intptr_4, int int_6, int int_7)
		{
			Marshal.WriteInt32(intptr_4, int_6, int_7);
		}

		// Token: 0x0600030E RID: 782 RVA: 0x00002A9B File Offset: 0x00000C9B
		internal static void smethod_58(IntPtr intptr_4, int int_6, long long_2)
		{
			Marshal.WriteInt64(intptr_4, int_6, long_2);
		}

		// Token: 0x0600030F RID: 783 RVA: 0x00016964 File Offset: 0x00014B64
		internal static IntPtr smethod_59(int int_6)
		{
			return Marshal.AllocCoTaskMem(int_6);
		}

		// Token: 0x06000310 RID: 784 RVA: 0x00002AA7 File Offset: 0x00000CA7
		internal static void smethod_60(byte[] byte_2, int int_6, IntPtr intptr_4, int int_7)
		{
			Marshal.Copy(byte_2, int_6, intptr_4, int_7);
		}

		// Token: 0x06000311 RID: 785 RVA: 0x00002AB4 File Offset: 0x00000CB4
		internal static void smethod_61()
		{
			Class6.smethod_17();
		}

		// Token: 0x06000312 RID: 786 RVA: 0x0001697C File Offset: 0x00014B7C
		internal static object smethod_62()
		{
			return Process.GetCurrentProcess();
		}

		// Token: 0x06000313 RID: 787 RVA: 0x00016994 File Offset: 0x00014B94
		internal static object smethod_63(Process process_0)
		{
			return process_0.MainModule;
		}

		// Token: 0x06000314 RID: 788 RVA: 0x000169AC File Offset: 0x00014BAC
		internal static IntPtr smethod_64(ProcessModule processModule_0)
		{
			return processModule_0.BaseAddress;
		}

		// Token: 0x06000315 RID: 789 RVA: 0x000169C4 File Offset: 0x00014BC4
		internal static IntPtr smethod_65(IntPtr intptr_4, string string_2, uint uint_1)
		{
			return Class6.smethod_21(intptr_4, string_2, uint_1);
		}

		// Token: 0x06000316 RID: 790 RVA: 0x000169E0 File Offset: 0x00014BE0
		internal static bool smethod_66(IntPtr intptr_4, IntPtr intptr_5)
		{
			return intptr_4 != intptr_5;
		}

		// Token: 0x06000317 RID: 791 RVA: 0x000169FC File Offset: 0x00014BFC
		internal static int smethod_68()
		{
			return IntPtr.Size;
		}

		// Token: 0x06000318 RID: 792 RVA: 0x00016A14 File Offset: 0x00014C14
		internal static Type smethod_69(string string_2, bool bool_7)
		{
			return Type.GetType(string_2, bool_7);
		}

		// Token: 0x06000319 RID: 793 RVA: 0x00016A30 File Offset: 0x00014C30
		internal static bool smethod_70(Type type_0, Type type_1)
		{
			return type_0 != type_1;
		}

		// Token: 0x0600031A RID: 794 RVA: 0x00016A4C File Offset: 0x00014C4C
		internal static object smethod_71(Process process_0)
		{
			return process_0.Modules;
		}

		// Token: 0x0600031B RID: 795 RVA: 0x00016A64 File Offset: 0x00014C64
		internal static object smethod_72(ReadOnlyCollectionBase readOnlyCollectionBase_0)
		{
			return readOnlyCollectionBase_0.GetEnumerator();
		}

		// Token: 0x0600031C RID: 796 RVA: 0x00016A7C File Offset: 0x00014C7C
		internal static object smethod_73(IEnumerator ienumerator_0)
		{
			return ienumerator_0.Current;
		}

		// Token: 0x0600031D RID: 797 RVA: 0x00016A94 File Offset: 0x00014C94
		internal static object smethod_74(ProcessModule processModule_0)
		{
			return processModule_0.ModuleName;
		}

		// Token: 0x0600031E RID: 798 RVA: 0x00016AAC File Offset: 0x00014CAC
		internal static object smethod_75(string string_2)
		{
			return string_2.ToLower();
		}

		// Token: 0x0600031F RID: 799 RVA: 0x00016AC4 File Offset: 0x00014CC4
		internal static bool smethod_76(string string_2, string string_3)
		{
			return string_2 == string_3;
		}

		// Token: 0x06000320 RID: 800 RVA: 0x00016AE0 File Offset: 0x00014CE0
		internal static object smethod_77(ProcessModule processModule_0)
		{
			return processModule_0.FileVersionInfo;
		}

		// Token: 0x06000321 RID: 801 RVA: 0x00016AF8 File Offset: 0x00014CF8
		internal static int smethod_78(FileVersionInfo fileVersionInfo_0)
		{
			return fileVersionInfo_0.ProductMajorPart;
		}

		// Token: 0x06000322 RID: 802 RVA: 0x00016B10 File Offset: 0x00014D10
		internal static int smethod_79(FileVersionInfo fileVersionInfo_0)
		{
			return fileVersionInfo_0.ProductMinorPart;
		}

		// Token: 0x06000323 RID: 803 RVA: 0x00016B28 File Offset: 0x00014D28
		internal static int smethod_80(FileVersionInfo fileVersionInfo_0)
		{
			return fileVersionInfo_0.ProductBuildPart;
		}

		// Token: 0x06000324 RID: 804 RVA: 0x00016B40 File Offset: 0x00014D40
		internal static int smethod_81(FileVersionInfo fileVersionInfo_0)
		{
			return fileVersionInfo_0.ProductPrivatePart;
		}

		// Token: 0x06000325 RID: 805 RVA: 0x00016B58 File Offset: 0x00014D58
		internal static bool smethod_82(Version version_0, Version version_1)
		{
			return version_0 >= version_1;
		}

		// Token: 0x06000326 RID: 806 RVA: 0x00016B74 File Offset: 0x00014D74
		internal static bool smethod_83(Version version_0, Version version_1)
		{
			return version_0 < version_1;
		}

		// Token: 0x06000327 RID: 807 RVA: 0x00016B90 File Offset: 0x00014D90
		internal static bool smethod_84(IEnumerator ienumerator_0)
		{
			return ienumerator_0.MoveNext();
		}

		// Token: 0x06000328 RID: 808 RVA: 0x00002ABD File Offset: 0x00000CBD
		internal static void smethod_85(IDisposable idisposable_0)
		{
			idisposable_0.Dispose();
		}

		// Token: 0x06000329 RID: 809 RVA: 0x00016BA8 File Offset: 0x00014DA8
		internal static object smethod_86(Assembly assembly_1, string string_2)
		{
			return assembly_1.GetManifestResourceStream(string_2);
		}

		// Token: 0x0600032A RID: 810 RVA: 0x000167D4 File Offset: 0x000149D4
		internal static object smethod_87(Class6.Class9 class9_0)
		{
			return class9_0.method_0();
		}

		// Token: 0x0600032B RID: 811 RVA: 0x00002A38 File Offset: 0x00000C38
		internal static void smethod_88(Stream stream_0, long long_2)
		{
			stream_0.Position = long_2;
		}

		// Token: 0x0600032C RID: 812 RVA: 0x000167EC File Offset: 0x000149EC
		internal static long smethod_89(Stream stream_0)
		{
			return stream_0.Length;
		}

		// Token: 0x0600032D RID: 813 RVA: 0x00016804 File Offset: 0x00014A04
		internal static object smethod_90(Class6.Class9 class9_0, int int_6)
		{
			return class9_0.method_1(int_6);
		}

		// Token: 0x0600032E RID: 814 RVA: 0x00002A4D File Offset: 0x00000C4D
		internal static void smethod_91(Array array_0)
		{
			Array.Reverse(array_0);
		}

		// Token: 0x0600032F RID: 815 RVA: 0x00016820 File Offset: 0x00014A20
		internal static object smethod_92(Assembly assembly_1)
		{
			return assembly_1.GetName();
		}

		// Token: 0x06000330 RID: 816 RVA: 0x00016838 File Offset: 0x00014A38
		internal static object smethod_93(AssemblyName assemblyName_0)
		{
			return assemblyName_0.GetPublicKeyToken();
		}

		// Token: 0x06000331 RID: 817 RVA: 0x00002AC7 File Offset: 0x00000CC7
		internal static void smethod_94(Array array_0, int int_6, int int_7)
		{
			Array.Clear(array_0, int_6, int_7);
		}

		// Token: 0x06000332 RID: 818 RVA: 0x00016BC4 File Offset: 0x00014DC4
		internal static object smethod_95(Assembly assembly_1)
		{
			return assembly_1.GetModules();
		}

		// Token: 0x06000333 RID: 819 RVA: 0x00016BDC File Offset: 0x00014DDC
		internal static IntPtr smethod_96(Module module_0)
		{
			return Marshal.GetHINSTANCE(module_0);
		}

		// Token: 0x06000334 RID: 820 RVA: 0x00016BF4 File Offset: 0x00014DF4
		internal static object smethod_97(Assembly assembly_1)
		{
			return assembly_1.Location;
		}

		// Token: 0x06000335 RID: 821 RVA: 0x00016C0C File Offset: 0x00014E0C
		internal static int smethod_98(string string_2)
		{
			return string_2.Length;
		}

		// Token: 0x06000336 RID: 822 RVA: 0x00016C24 File Offset: 0x00014E24
		internal static int smethod_99(Class6.Class9 class9_0)
		{
			return class9_0.method_3();
		}

		// Token: 0x06000337 RID: 823 RVA: 0x00016850 File Offset: 0x00014A50
		internal static object smethod_100()
		{
			return Class6.smethod_7();
		}

		// Token: 0x06000338 RID: 824 RVA: 0x00002A57 File Offset: 0x00000C57
		internal static void smethod_101(SymmetricAlgorithm symmetricAlgorithm_0, CipherMode cipherMode_0)
		{
			symmetricAlgorithm_0.Mode = cipherMode_0;
		}

		// Token: 0x06000339 RID: 825 RVA: 0x00016868 File Offset: 0x00014A68
		internal static object smethod_102(SymmetricAlgorithm symmetricAlgorithm_0, byte[] byte_2, byte[] byte_3)
		{
			return symmetricAlgorithm_0.CreateDecryptor(byte_2, byte_3);
		}

		// Token: 0x0600033A RID: 826 RVA: 0x00002A62 File Offset: 0x00000C62
		internal static void smethod_103(Stream stream_0, byte[] byte_2, int int_6, int int_7)
		{
			stream_0.Write(byte_2, int_6, int_7);
		}

		// Token: 0x0600033B RID: 827 RVA: 0x00002A6F File Offset: 0x00000C6F
		internal static void smethod_104(CryptoStream cryptoStream_0)
		{
			cryptoStream_0.FlushFinalBlock();
		}

		// Token: 0x0600033C RID: 828 RVA: 0x00016C3C File Offset: 0x00014E3C
		internal static object smethod_105(MemoryStream memoryStream_0)
		{
			return memoryStream_0.ToArray();
		}

		// Token: 0x0600033D RID: 829 RVA: 0x00002A79 File Offset: 0x00000C79
		internal static void smethod_106(Stream stream_0)
		{
			stream_0.Close();
		}

		// Token: 0x0600033E RID: 830 RVA: 0x00002A43 File Offset: 0x00000C43
		internal static void smethod_107(Class6.Class9 class9_0)
		{
			class9_0.method_4();
		}

		// Token: 0x0600033F RID: 831 RVA: 0x00016C54 File Offset: 0x00014E54
		internal static int smethod_108(Process process_0)
		{
			return process_0.Id;
		}

		// Token: 0x06000340 RID: 832 RVA: 0x00016C6C File Offset: 0x00014E6C
		internal static IntPtr smethod_109(uint uint_1, int int_6, uint uint_2)
		{
			return Class6.smethod_25(uint_1, int_6, uint_2);
		}

		// Token: 0x06000341 RID: 833 RVA: 0x00016C88 File Offset: 0x00014E88
		internal static object smethod_110(int int_6)
		{
			return BitConverter.GetBytes(int_6);
		}

		// Token: 0x06000342 RID: 834 RVA: 0x00016CA0 File Offset: 0x00014EA0
		internal static long smethod_111(Stream stream_0)
		{
			return stream_0.Position;
		}

		// Token: 0x06000343 RID: 835 RVA: 0x00002AD3 File Offset: 0x00000CD3
		internal static void smethod_112(IntPtr intptr_4, int int_6)
		{
			Marshal.WriteInt32(intptr_4, int_6);
		}

		// Token: 0x06000344 RID: 836 RVA: 0x00016CB8 File Offset: 0x00014EB8
		internal static int smethod_113(IntPtr intptr_4)
		{
			return Class6.smethod_26(intptr_4);
		}

		// Token: 0x06000345 RID: 837 RVA: 0x00002ADE File Offset: 0x00000CDE
		internal static void smethod_114(Hashtable hashtable_1, object object_3, object object_4)
		{
			hashtable_1.Add(object_3, object_4);
		}

		// Token: 0x06000346 RID: 838 RVA: 0x00016CD0 File Offset: 0x00014ED0
		internal static Type smethod_115(RuntimeTypeHandle runtimeTypeHandle_0)
		{
			return Type.GetTypeFromHandle(runtimeTypeHandle_0);
		}

		// Token: 0x06000347 RID: 839 RVA: 0x00016CE8 File Offset: 0x00014EE8
		internal static int smethod_116(long long_2)
		{
			return Convert.ToInt32(long_2);
		}

		// Token: 0x06000348 RID: 840 RVA: 0x00016D00 File Offset: 0x00014F00
		internal static object smethod_117()
		{
			return Encoding.UTF8;
		}

		// Token: 0x06000349 RID: 841 RVA: 0x00016D18 File Offset: 0x00014F18
		internal static object smethod_118(Encoding encoding_0, byte[] byte_2)
		{
			return encoding_0.GetString(byte_2);
		}

		// Token: 0x0600034A RID: 842 RVA: 0x00016D34 File Offset: 0x00014F34
		internal static bool smethod_119(IntPtr intptr_4, IntPtr intptr_5)
		{
			return intptr_4 == intptr_5;
		}

		// Token: 0x0600034B RID: 843 RVA: 0x00016D50 File Offset: 0x00014F50
		internal static object smethod_120(IntPtr intptr_4, Type type_0)
		{
			return Class6.smethod_18(intptr_4, type_0);
		}

		// Token: 0x0600034C RID: 844 RVA: 0x00016D6C File Offset: 0x00014F6C
		internal static int smethod_122(IntPtr intptr_4)
		{
			return Marshal.ReadInt32(intptr_4);
		}

		// Token: 0x0600034D RID: 845 RVA: 0x00016D84 File Offset: 0x00014F84
		internal static long smethod_123(IntPtr intptr_4)
		{
			return Marshal.ReadInt64(intptr_4);
		}

		// Token: 0x0600034E RID: 846 RVA: 0x00016D9C File Offset: 0x00014F9C
		internal static IntPtr smethod_124(Delegate delegate_0)
		{
			return Marshal.GetFunctionPointerForDelegate(delegate_0);
		}

		// Token: 0x0600034F RID: 847 RVA: 0x00016DB4 File Offset: 0x00014FB4
		internal static int smethod_125(ProcessModule processModule_0)
		{
			return processModule_0.ModuleMemorySize;
		}

		// Token: 0x06000350 RID: 848 RVA: 0x000168B4 File Offset: 0x00014AB4
		internal static object smethod_126(Assembly assembly_1)
		{
			return assembly_1.EntryPoint;
		}

		// Token: 0x06000351 RID: 849 RVA: 0x00016DCC File Offset: 0x00014FCC
		internal static bool smethod_127(MethodInfo methodInfo_0, MethodInfo methodInfo_1)
		{
			return methodInfo_0 != methodInfo_1;
		}

		// Token: 0x06000352 RID: 850 RVA: 0x00016DE8 File Offset: 0x00014FE8
		internal static object smethod_128(Delegate delegate_0)
		{
			return delegate_0.Method;
		}

		// Token: 0x06000353 RID: 851 RVA: 0x00016E00 File Offset: 0x00015000
		internal static object smethod_129(Type type_0, MethodInfo methodInfo_0)
		{
			return Delegate.CreateDelegate(type_0, methodInfo_0);
		}

		// Token: 0x06000354 RID: 852 RVA: 0x00016E1C File Offset: 0x0001501C
		internal static object smethod_130(MethodBase methodBase_0)
		{
			return methodBase_0.GetParameters();
		}

		// Token: 0x06000355 RID: 853 RVA: 0x00016E34 File Offset: 0x00015034
		internal static object smethod_131(Assembly assembly_1)
		{
			return assembly_1.ManifestModule;
		}

		// Token: 0x06000356 RID: 854 RVA: 0x00016E4C File Offset: 0x0001504C
		internal static ModuleHandle smethod_132(Module module_0)
		{
			return module_0.ModuleHandle;
		}

		// Token: 0x06000357 RID: 855 RVA: 0x00016E64 File Offset: 0x00015064
		internal static Type smethod_133(object object_3)
		{
			return object_3.GetType();
		}

		// Token: 0x06000358 RID: 856 RVA: 0x00016E7C File Offset: 0x0001507C
		internal static object smethod_134(FieldInfo fieldInfo_0, object object_3)
		{
			return fieldInfo_0.GetValue(object_3);
		}

		// Token: 0x06000359 RID: 857 RVA: 0x00016E98 File Offset: 0x00015098
		internal static object smethod_135(long long_2)
		{
			return BitConverter.GetBytes(long_2);
		}

		// Token: 0x0600035A RID: 858 RVA: 0x00002AEA File Offset: 0x00000CEA
		internal static void smethod_136(Delegate delegate_0)
		{
			RuntimeHelpers.PrepareDelegate(delegate_0);
		}

		// Token: 0x0600035B RID: 859 RVA: 0x00016EB0 File Offset: 0x000150B0
		internal static RuntimeMethodHandle smethod_137(MethodBase methodBase_0)
		{
			return methodBase_0.MethodHandle;
		}

		// Token: 0x0600035C RID: 860 RVA: 0x00002AF4 File Offset: 0x00000CF4
		internal static void smethod_138(RuntimeMethodHandle runtimeMethodHandle_0)
		{
			RuntimeHelpers.PrepareMethod(runtimeMethodHandle_0);
		}

		// Token: 0x0600035D RID: 861 RVA: 0x00002AFE File Offset: 0x00000CFE
		internal static void smethod_139(Array array_0, RuntimeFieldHandle runtimeFieldHandle_0)
		{
			RuntimeHelpers.InitializeArray(array_0, runtimeFieldHandle_0);
		}

		// Token: 0x0600035E RID: 862 RVA: 0x00016EC8 File Offset: 0x000150C8
		internal static IntPtr smethod_140(IntPtr intptr_4, uint uint_1, uint uint_2, uint uint_3)
		{
			return Class6.smethod_22(intptr_4, uint_1, uint_2, uint_3);
		}

		// Token: 0x0600035F RID: 863 RVA: 0x00002B09 File Offset: 0x00000D09
		internal static void smethod_141(IntPtr intptr_4, IntPtr intptr_5)
		{
			Marshal.WriteIntPtr(intptr_4, intptr_5);
		}

		// Token: 0x06000360 RID: 864 RVA: 0x000057E0 File Offset: 0x000039E0
		internal static bool smethod_142()
		{
			return true;
		}

		// Token: 0x06000361 RID: 865 RVA: 0x000168E8 File Offset: 0x00014AE8
		internal static object smethod_143()
		{
			return null;
		}

		// Token: 0x04000081 RID: 129
		private static bool bool_0;

		// Token: 0x04000082 RID: 130
		private static string[] string_0;

		// Token: 0x04000083 RID: 131
		private static int int_0;

		// Token: 0x04000084 RID: 132
		private static Class6.Delegate6 delegate6_0;

		// Token: 0x04000085 RID: 133
		private static Class6.Delegate7 delegate7_0;

		// Token: 0x04000086 RID: 134
		private static byte[] byte_0;

		// Token: 0x04000087 RID: 135
		private static int int_1;

		// Token: 0x04000088 RID: 136
		private static int int_2;

		// Token: 0x04000089 RID: 137
		private static List<string> list_0;

		// Token: 0x0400008A RID: 138
		private static Class6.Delegate4 delegate4_0;

		// Token: 0x0400008B RID: 139
		private static uint[] uint_0;

		// Token: 0x0400008C RID: 140
		private static int int_3;

		// Token: 0x0400008D RID: 141
		[Class6.Attribute0(typeof(Class6.Attribute0.Class7<object>[]))]
		private static bool bool_1;

		// Token: 0x0400008E RID: 142
		private static Dictionary<int, int> dictionary_0;

		// Token: 0x0400008F RID: 143
		private static byte[] byte_1;

		// Token: 0x04000090 RID: 144
		private static string string_1;

		// Token: 0x04000091 RID: 145
		private static bool bool_2;

		// Token: 0x04000092 RID: 146
		private static object object_0;

		// Token: 0x04000093 RID: 147
		private static bool bool_3;

		// Token: 0x04000094 RID: 148
		private static object object_1;

		// Token: 0x04000095 RID: 149
		private static bool bool_4;

		// Token: 0x04000096 RID: 150
		private static bool bool_5 = false;

		// Token: 0x04000097 RID: 151
		private static Class6.Delegate9 delegate9_0;

		// Token: 0x04000098 RID: 152
		internal static Class6.Delegate2 delegate2_0;

		// Token: 0x04000099 RID: 153
		private static IntPtr intptr_0;

		// Token: 0x0400009A RID: 154
		internal static Class6.Delegate2 delegate2_1;

		// Token: 0x0400009B RID: 155
		private static SortedList sortedList_0;

		// Token: 0x0400009C RID: 156
		private static IntPtr intptr_1;

		// Token: 0x0400009D RID: 157
		private static long long_0;

		// Token: 0x0400009E RID: 158
		private static IntPtr intptr_2;

		// Token: 0x0400009F RID: 159
		private static List<int> list_1;

		// Token: 0x040000A0 RID: 160
		private static int int_4;

		// Token: 0x040000A1 RID: 161
		internal static object object_2;

		// Token: 0x040000A2 RID: 162
		internal static Assembly assembly_0 = typeof(Class6).Assembly;

		// Token: 0x040000A3 RID: 163
		private static bool bool_6;

		// Token: 0x040000A4 RID: 164
		private static IntPtr intptr_3;

		// Token: 0x040000A5 RID: 165
		internal static Hashtable hashtable_0;

		// Token: 0x040000A6 RID: 166
		private static Class6.Delegate5 delegate5_0;

		// Token: 0x040000A7 RID: 167
		private static Class6.Delegate8 delegate8_0;

		// Token: 0x040000A8 RID: 168
		private static int[] int_5;

		// Token: 0x040000A9 RID: 169
		private static long long_1;

		// Token: 0x02000046 RID: 70
		// (Invoke) Token: 0x06000363 RID: 867
		private delegate void Delegate1(object o);

		// Token: 0x02000047 RID: 71
		internal class Attribute0 : Attribute
		{
			// Token: 0x06000366 RID: 870 RVA: 0x00002B14 File Offset: 0x00000D14
			public Attribute0(object object_0)
			{
			}

			// Token: 0x02000048 RID: 72
			internal class Class7<T>
			{
				// Token: 0x06000367 RID: 871 RVA: 0x00016EE4 File Offset: 0x000150E4
				internal static bool smethod_0()
				{
					return Class6.Attribute0.Class7<T>.object_0 == null;
				}

				// Token: 0x06000368 RID: 872 RVA: 0x00016F00 File Offset: 0x00015100
				internal static object smethod_1()
				{
					return Class6.Attribute0.Class7<T>.object_0;
				}

				// Token: 0x040000AA RID: 170
				private static object object_0;
			}
		}

		// Token: 0x02000049 RID: 73
		internal class Class8
		{
			// Token: 0x0600036A RID: 874 RVA: 0x00016F18 File Offset: 0x00015118
			internal static string smethod_0(string string_0, string string_1)
			{
				byte[] bytes = Encoding.Unicode.GetBytes(string_0);
				byte[] key = new byte[]
				{
					82,
					102,
					104,
					110,
					32,
					77,
					24,
					34,
					118,
					181,
					51,
					17,
					18,
					51,
					12,
					109,
					10,
					32,
					77,
					24,
					34,
					158,
					161,
					41,
					97,
					28,
					118,
					181,
					5,
					25,
					1,
					88
				};
				byte[] iv = Class6.smethod_9(Encoding.Unicode.GetBytes(string_1));
				MemoryStream memoryStream = new MemoryStream();
				SymmetricAlgorithm symmetricAlgorithm = Class6.smethod_7();
				symmetricAlgorithm.Key = key;
				symmetricAlgorithm.IV = iv;
				CryptoStream cryptoStream = new CryptoStream(memoryStream, symmetricAlgorithm.CreateEncryptor(), CryptoStreamMode.Write);
				cryptoStream.Write(bytes, 0, bytes.Length);
				cryptoStream.Close();
				return Convert.ToBase64String(memoryStream.ToArray());
			}
		}

		// Token: 0x0200004A RID: 74
		// (Invoke) Token: 0x0600036D RID: 877
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		internal delegate uint Delegate2(IntPtr classthis, IntPtr comp, IntPtr info, [MarshalAs(UnmanagedType.U4)] uint flags, IntPtr nativeEntry, ref uint nativeSizeOfCode);

		// Token: 0x0200004B RID: 75
		// (Invoke) Token: 0x06000371 RID: 881
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr Delegate3();

		// Token: 0x0200004C RID: 76
		internal struct Struct0
		{
			// Token: 0x040000AB RID: 171
			internal bool bool_0;

			// Token: 0x040000AC RID: 172
			internal byte[] byte_0;
		}

		// Token: 0x0200004D RID: 77
		internal class Class9
		{
			// Token: 0x06000374 RID: 884 RVA: 0x00002B1E File Offset: 0x00000D1E
			public Class9(Stream stream_0)
			{
				this.binaryReader_0 = new BinaryReader(stream_0);
			}

			// Token: 0x06000375 RID: 885 RVA: 0x00016FAC File Offset: 0x000151AC
			internal Stream method_0()
			{
				return this.binaryReader_0.BaseStream;
			}

			// Token: 0x06000376 RID: 886 RVA: 0x00016FCC File Offset: 0x000151CC
			internal byte[] method_1(int int_0)
			{
				return this.binaryReader_0.ReadBytes(int_0);
			}

			// Token: 0x06000377 RID: 887 RVA: 0x00016FEC File Offset: 0x000151EC
			internal int method_2(byte[] byte_0, int int_0, int int_1)
			{
				return this.binaryReader_0.Read(byte_0, int_0, int_1);
			}

			// Token: 0x06000378 RID: 888 RVA: 0x0001700C File Offset: 0x0001520C
			internal int method_3()
			{
				return this.binaryReader_0.ReadInt32();
			}

			// Token: 0x06000379 RID: 889 RVA: 0x00002B34 File Offset: 0x00000D34
			internal void method_4()
			{
				this.binaryReader_0.Close();
			}

			// Token: 0x040000AD RID: 173
			private BinaryReader binaryReader_0;
		}

		// Token: 0x0200004E RID: 78
		// (Invoke) Token: 0x0600037B RID: 891
		private delegate IntPtr Delegate4(IntPtr hModule, string lpName, uint lpType);

		// Token: 0x0200004F RID: 79
		// (Invoke) Token: 0x0600037F RID: 895
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr Delegate5(IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);

		// Token: 0x02000050 RID: 80
		// (Invoke) Token: 0x06000383 RID: 899
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int Delegate6(IntPtr hProcess, IntPtr lpBaseAddress, [In] [Out] byte[] buffer, uint size, out IntPtr lpNumberOfBytesWritten);

		// Token: 0x02000051 RID: 81
		// (Invoke) Token: 0x06000387 RID: 903
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int Delegate7(IntPtr lpAddress, int dwSize, int flNewProtect, ref int lpflOldProtect);

		// Token: 0x02000052 RID: 82
		// (Invoke) Token: 0x0600038B RID: 907
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate IntPtr Delegate8(uint dwDesiredAccess, int bInheritHandle, uint dwProcessId);

		// Token: 0x02000053 RID: 83
		// (Invoke) Token: 0x0600038F RID: 911
		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		private delegate int Delegate9(IntPtr ptr);

		// Token: 0x02000054 RID: 84
		[Flags]
		private enum Enum0
		{

		}

		// Token: 0x02000055 RID: 85
		[CompilerGenerated]
		private static class <>O
		{
			// Token: 0x040000AF RID: 175
			public static Class6.Delegate2 <0>__smethod_15;
		}
	}
}
