﻿using System;

namespace ns0
{
	// Token: 0x02000041 RID: 65
	internal class Class3
	{
		// Token: 0x060002B6 RID: 694 RVA: 0x00013880 File Offset: 0x00011A80
		public object VM_Detected()
		{
			return false;
		}

		// Token: 0x060002B7 RID: 695 RVA: 0x00013880 File Offset: 0x00011A80
		public object AnyRun_Detected()
		{
			return false;
		}
	}
}
