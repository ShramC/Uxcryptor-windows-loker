﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;

// Token: 0x02000002 RID: 2
// (Invoke) Token: 0x06000004 RID: 4
[DebuggerDisplay("<generated method>", Type = "<generated method>")]
[CompilerGenerated]
internal delegate void VB$AnonymousDelegate_0();
