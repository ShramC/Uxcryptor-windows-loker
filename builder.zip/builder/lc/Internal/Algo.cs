﻿using System;

namespace NET.Internal
{
	// Token: 0x0200000C RID: 12
	internal class Algo
	{
		// Token: 0x0600002E RID: 46 RVA: 0x00002323 File Offset: 0x00000523
		public bool VM_Detected()
		{
			return false;
		}
	}
}
