﻿using System;
using System.Runtime.InteropServices;

namespace NET.Internal
{
	// Token: 0x02000010 RID: 16
	internal sealed class Proxy
	{
		// Token: 0x06000041 RID: 65
		[DllImport("kernel32.dll")]
		private static extern IntPtr GetModuleHandle(string asset);

		// Token: 0x06000042 RID: 66 RVA: 0x0000462C File Offset: 0x0000282C
		public object SandBox_Detected()
		{
			string[] array = new string[]
			{
				"SbieDll.dll",
				"SxIn.dll",
				"Sf2.dll",
				"snxhk.dll",
				"cmdvrt32.dll"
			};
			checked
			{
				int num = array.Length - 1;
				for (int i = 0; i <= num; i++)
				{
					if (Proxy.GetModuleHandle(array[i]).ToInt32() != 0)
					{
						return true;
					}
				}
				return false;
			}
		}
	}
}
