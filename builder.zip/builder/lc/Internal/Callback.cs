﻿using System;
using System.IO;
using Microsoft.VisualBasic.CompilerServices;

namespace NET.Internal
{
	// Token: 0x0200000D RID: 13
	internal class Callback
	{
		// Token: 0x06000030 RID: 48 RVA: 0x000038B8 File Offset: 0x00001AB8
		public object AnyRun_Detected()
		{
			string[] array = new string[]
			{
				"Acrobat Reader DC.lnk",
				"CCleaner.lnk",
				"FileZilla Client.lnk",
				"Firefox.lnk",
				"Google Chrome.lnk",
				"Opera.lnk",
				"Skype.lnk",
				"VLC Media player.lnk"
			};
			checked
			{
				int num = array.Length - 1;
				for (int i = 0; i <= num; i++)
				{
					if (!File.Exists(Environment.ExpandEnvironmentVariables("%systemdrive%") + "\\Users\\Public\\Desktop\\" + array[i]))
					{
						return false;
					}
				}
				if (Operators.CompareString(Environment.UserName.ToLower(), "admin", false) == 0 && Environment.MachineName.Contains("USER-PC"))
				{
					return true;
				}
				return false;
			}
		}
	}
}
