﻿using System;
using System.Reflection;

namespace NET.Internal
{
	// Token: 0x02000014 RID: 20
	internal class Tokenizer
	{
		// Token: 0x060000A8 RID: 168 RVA: 0x00007428 File Offset: 0x00005628
		internal static void CreateIndexer(int typemdt)
		{
			Type type = Tokenizer.m_Property.ResolveType(33554432 + typemdt);
			foreach (FieldInfo fieldInfo in type.GetFields())
			{
				MethodInfo method = (MethodInfo)Tokenizer.m_Property.ResolveMethod(fieldInfo.MetadataToken + 100663296);
				fieldInfo.SetValue(null, (MulticastDelegate)Delegate.CreateDelegate(type, method));
			}
		}

		// Token: 0x04000049 RID: 73
		internal static Module m_Property = typeof(Tokenizer).Assembly.ManifestModule;

		// Token: 0x02000015 RID: 21
		// (Invoke) Token: 0x060000AC RID: 172
		internal delegate void Mapping(object o);
	}
}
